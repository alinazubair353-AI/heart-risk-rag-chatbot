"""Create the 6 synthetic lab reports required by Task 2 (all fictional - no real patients) plus ground truth.

  2 digital PDFs with different layouts, 2 scanned images (clean + rotated/noisy), 2 CSV files (wide + long).
Run:  python scripts/make_test_reports.py"""
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
try:
    import pymupdf as fitz  # PyMuPDF (used here only to WRITE the synthetic PDFs)
except ImportError:
    import fitz
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np

from backend import config

OUT = config.TEST_REPORT_DIR
OUT.mkdir(parents=True, exist_ok=True)


def font(size):
    for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/dejavu/DejaVuSans.ttf", "C:/Windows/Fonts/arial.ttf",
              "/Library/Fonts/Arial.ttf"):
        if Path(p).exists():
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


GT = {}

# ---- digital PDF 1: simple "Test  Value  Unit  Range" table layout
p1 = [("Patient Age", "52"), ("Sex", "Male"), ("Total Cholesterol", "248 mg/dL  (<200)"), ("LDL Cholesterol", "172 mg/dL  (<100)"),
      ("HDL Cholesterol", "38 mg/dL  (>40)"), ("Triglycerides", "190 mg/dL  (<150)"), ("Fasting Glucose", "112 mg/dL  (70-99)"),
      ("Blood Pressure", "142/90 mmHg")]
doc = fitz.open(); page = doc.new_page()
page.insert_text((60, 70), "CITY LAB - Lipid & Glucose Report (SYNTHETIC)", fontsize=15)
y = 120
for k, v in p1:
    page.insert_text((60, y), k, fontsize=11); page.insert_text((260, y), v, fontsize=11); y += 24
doc.save(OUT / "report_digital_1.pdf"); doc.close()
GT["report_digital_1.pdf"] = {"type": "pdf", "age": 52, "sex": "male", "total_chol": 248, "ldl": 172, "hdl": 38, "triglycerides": 190,
                              "fasting_glucose": 112, "systolic_bp": 142, "diastolic_bp": 90}

# ---- digital PDF 2: different layout, label: value lines, SI units (mmol/L)
p2 = ["Wellness Clinic Laboratory (SYNTHETIC)", "Age: 61   Gender: Female", "Chol, total: 6.3 mmol/L", "LDL-C: 4.1 mmol/L",
      "HDL-C: 1.2 mmol/L", "TG: 2.4 mmol/L", "Glucose, fasting: 7.4 mmol/L", "HbA1c: 6.8 %", "BP: 150/95 mmHg"]
doc = fitz.open(); page = doc.new_page(); y = 80
for line in p2:
    page.insert_text((70, y), line, fontsize=12); y += 26
doc.save(OUT / "report_digital_2.pdf"); doc.close()
GT["report_digital_2.pdf"] = {"type": "pdf", "age": 61, "sex": "female", "total_chol": round(6.3 * 38.67, 1), "ldl": round(4.1 * 38.67, 1),
                              "hdl": round(1.2 * 38.67, 1), "triglycerides": round(2.4 * 88.57, 1), "fasting_glucose": round(7.4 * 18.02, 1),
                              "hba1c": 6.8, "systolic_bp": 150, "diastolic_bp": 95}


def make_image(lines, path, rotate=0.0, noise=0.0, size=(900, 620), fs=26):
    img = Image.new("RGB", size, "white"); d = ImageDraw.Draw(img); y = 40
    for ln in lines:
        d.text((50, y), ln, fill="black", font=font(fs)); y += 52
    if rotate:
        img = img.rotate(rotate, expand=True, fillcolor="white")
    if noise:
        a = np.array(img).astype(float); rng = np.random.default_rng(1)
        a += rng.normal(0, noise, a.shape); img = Image.fromarray(np.clip(a, 0, 255).astype("uint8")).filter(ImageFilter.GaussianBlur(0.6))
    img.save(path)


# ---- scanned image 1: clean
L1 = ["Age: 47    Sex: Male", "Total Cholesterol: 231 mg/dL", "LDL Cholesterol: 148 mg/dL", "HDL Cholesterol: 44 mg/dL",
      "Triglycerides: 205 mg/dL", "Fasting Glucose: 104 mg/dL", "Blood Pressure: 134/86 mmHg"]
make_image(L1, OUT / "scan_clean.png")
GT["scan_clean.png"] = {"type": "ocr", "age": 47, "sex": "male", "total_chol": 231, "ldl": 148, "hdl": 44, "triglycerides": 205,
                        "fasting_glucose": 104, "systolic_bp": 134, "diastolic_bp": 86}
# ---- scanned image 2: rotated 3 degrees + noise
L2 = ["Age: 58    Sex: Female", "Total Cholesterol: 262 mg/dL", "LDL Cholesterol: 181 mg/dL", "HDL Cholesterol: 47 mg/dL",
      "Triglycerides: 168 mg/dL", "Fasting Glucose: 131 mg/dL", "HbA1c: 6.9 %"]
make_image(L2, OUT / "scan_rotated_noisy.png", rotate=3, noise=18)
GT["scan_rotated_noisy.png"] = {"type": "ocr", "age": 58, "sex": "female", "total_chol": 262, "ldl": 181, "hdl": 47, "triglycerides": 168,
                                "fasting_glucose": 131, "hba1c": 6.9}

# ---- CSV 1 wide format (units in header), CSV 2 long format
(OUT / "labs_wide.csv").write_text("age,sex,bmi,Total Cholesterol (mg/dL),LDL (mg/dL),HDL (mg/dL),Triglycerides (mg/dL),Fasting Glucose (mg/dL),Systolic BP (mmHg),Diastolic BP (mmHg)\n"
                                   "55,male,31.2,255,170,36,240,118,148,92\n")
GT["labs_wide.csv"] = {"type": "csv", "age": 55, "sex": "male", "bmi": 31.2, "total_chol": 255, "ldl": 170, "hdl": 36, "triglycerides": 240,
                       "fasting_glucose": 118, "systolic_bp": 148, "diastolic_bp": 92}
(OUT / "labs_long.csv").write_text("test,value,unit\nAge,39,years\nTotal Cholesterol,4.6,mmol/L\nLDL Cholesterol,2.6,mmol/L\nHDL Cholesterol,1.5,mmol/L\n"
                                   "Triglycerides,1.1,mmol/L\nFasting Glucose,5.1,mmol/L\nHbA1c,5.3,%\n")
GT["labs_long.csv"] = {"type": "csv", "age": 39, "total_chol": round(4.6 * 38.67, 1), "ldl": round(2.6 * 38.67, 1), "hdl": round(1.5 * 38.67, 1),
                       "triglycerides": round(1.1 * 88.57, 1), "fasting_glucose": round(5.1 * 18.02, 1), "hba1c": 5.3}

(OUT / "ground_truth.json").write_text(json.dumps(GT, indent=2))
print("wrote", len(GT), "synthetic reports to", OUT)
