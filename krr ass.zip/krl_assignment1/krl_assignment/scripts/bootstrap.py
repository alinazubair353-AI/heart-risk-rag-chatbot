"""One-command setup (works offline): builds everything the app needs.

Run:  python scripts/bootstrap.py [--full-train]
Steps: ontology -> knowledge-graph triples -> KG figure -> synthetic demo dataset (if no dataset present) ->
       train/calibrate/explain models -> synthetic test reports -> vector index -> evaluation tables."""
import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def run(title, *cmd):
    print(f"\n=== {title}")
    subprocess.run([sys.executable, *cmd], cwd=ROOT, check=True)


ap = argparse.ArgumentParser(); ap.add_argument("--full-train", action="store_true", help="larger hyper-parameter grids"); ap.add_argument("--skip-eval", action="store_true")
a = ap.parse_args()
run("1/8 OWL ontology", "-m", "backend.knowledge.build_ontology")
run("2/8 Knowledge-graph triples", "-m", "backend.knowledge.build_triples")
run("3/8 SPARQL queries + KG figure", "-m", "backend.knowledge.queries")
run("4/8 Synthetic demo dataset (only used if you have not added real datasets)", "-m", "backend.ml.synthetic")
run("5/8 Train / tune / calibrate / SHAP", "-m", "backend.ml.train", *(["--full"] if a.full_train else []))
run("6/8 Synthetic test reports", "scripts/make_test_reports.py")
run("7/8 Vector index (chunking + embeddings + FAISS)", "-m", "backend.rag.ingest")
if not a.skip_eval:
    run("8/8 Evaluation", "evaluation/make_profiles.py")
    run("   extraction accuracy", "evaluation/extraction_accuracy.py")
    run("   system evaluation", "evaluation/run_eval.py")
print("\nDone. Start the backend:  uvicorn backend.main:app --port 8000\n      Start the frontend: streamlit run frontend/app.py --server.port 8501")
