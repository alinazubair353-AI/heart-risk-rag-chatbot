"""ONLINE step - run once while you still have internet. After this the project works fully offline.

  1. saves the sentence-transformers embedding model into models/embedding/ (needs: pip install sentence-transformers)
  2. pulls the local LLM with Ollama (needs Ollama installed: https://ollama.com)
Datasets and guideline PDFs must be downloaded by hand (see data/datasets/README.md and data/guidelines/)."""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
model = sys.argv[1] if len(sys.argv) > 1 else "sentence-transformers/all-MiniLM-L6-v2"
llm = sys.argv[2] if len(sys.argv) > 2 else "llama3.2:3b"
try:
    from sentence_transformers import SentenceTransformer
    SentenceTransformer(model).save(str(ROOT / "models" / "embedding"))
    print("embedding model saved to models/embedding  (re-run: python -m backend.rag.ingest)")
except ImportError:
    print("pip install sentence-transformers   # then run this script again")
try:
    subprocess.run(["ollama", "pull", llm], check=True)
except FileNotFoundError:
    print("Ollama not found. Install it from https://ollama.com, then run:  ollama pull", llm)
