#!/usr/bin/env bash
# Start the FastAPI backend (API docs at http://localhost:8000/docs)
cd "$(dirname "$0")" && python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
