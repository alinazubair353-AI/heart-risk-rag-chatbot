"""Automated tests (pytest). Run:  pytest -q      (Task 3 requires >= 10 rule/engine tests; there are more here)."""
import json
import shutil
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from backend import config, safety
from backend.extraction import normaliser as N
from backend.extraction.lifestyle_parser import regex_extract
from backend.extraction.record_builder import build_record
from backend.knowledge import queries as kg
from backend.rag import ingest, prompt
from backend.reasoning.engine import run_rules, trace_line
from backend.reasoning.rules import R
from backend.schemas import LabValue, PatientRecord


def ids(facts):
    return {f["id"] for f in run_rules(facts)["fired"]}


# ------------------------------------------------------------------ rules (Task 3)
def test_rule_count_and_metadata():
    assert len(R) >= 20
    for r in R:
        assert r.id and r.name and r.condition and r.conclusion and r.source and 1 <= r.severity <= 5


@pytest.mark.parametrize("sbp,dbp,rule", [(110, 70, "R01"), (125, 75, "R02"), (135, 75, "R03"), (128, 85, "R03"), (145, 85, "R04"), (125, 95, "R04"), (190, 100, "R05")])
def test_bp_categories(sbp, dbp, rule):
    assert ids({"sbp": sbp, "dbp": dbp}) & {"R01", "R02", "R03", "R04", "R05"} == {rule}


@pytest.mark.parametrize("ldl,rule", [(99, "R06"), (100, "R07"), (129, "R07"), (130, "R08"), (159, "R08"), (160, "R09"), (189, "R09"), (190, "R10")])
def test_ldl_categories(ldl, rule):
    assert ids({"ldl": ldl}) & {"R06", "R07", "R08", "R09", "R10"} == {rule}


def test_hdl_threshold_depends_on_sex():
    assert "R11" in ids({"hdl": 45, "sex": "female"})
    assert "R11" not in ids({"hdl": 45, "sex": "male"})


def test_glucose_categories():
    assert "R16" in ids({"glu": 90}) and "R17" in ids({"glu": 100}) and "R17" in ids({"glu": 125}) and "R18" in ids({"glu": 126})


def test_combined_smoker_ldl_age_rule_and_trace_format():
    res = run_rules({"ldl": 172, "smoker": True, "age": 52})
    f = next(x for x in res["fired"] if x["id"] == "R23")
    assert res["risk_category"] == "High"
    assert "LDL = 172" in f["trace"] and "Smoking = True" in f["trace"] and "source: ESC-2021-Prevention" in f["trace"]
    assert f["trace"].startswith("R23 fired because")


def test_rule_not_fired_when_age_not_over_45():
    assert "R23" not in ids({"ldl": 172, "smoker": True, "age": 45})


def test_diabetes_plus_hypertension_is_very_high():
    assert run_rules({"diabetes": True, "hypertension": True})["risk_category"] == "Very high"


def test_missing_data_does_not_invent_findings():
    res = run_rules({})
    assert res["fired"] == [] and res["risk_category"] == "Insufficient data"


@pytest.mark.parametrize("symptom,rule", [("chest_pain_at_rest", "R32"), ("pain_radiating_to_arm_jaw", "R33"), ("syncope", "R34"), ("stroke_signs", "R35")])
def test_red_flag_rules_bypass_chatbot(symptom, rule):
    res = run_rules({"symptoms": [symptom]})
    assert rule in {f["id"] for f in res["fired"]} and res["red_flag"] and res["urgent_message"]


def test_exertional_chest_pain_is_not_bypass():
    res = run_rules({"symptoms": ["chest_pain"]})
    assert not res["red_flag"] and "R36" in {f["id"] for f in res["fired"]}


# ------------------------------------------------------------------ extraction (Task 2)
def test_cholesterol_unit_conversion_factor():
    v, u, _ = N.convert_value("ldl", 4.0, "mmol/L")
    assert u == "mg/dL" and v == pytest.approx(4.0 * 38.67, abs=0.1)


def test_glucose_unit_conversion_factor():
    v, _, _ = N.convert_value("fasting_glucose", 6.0, "mmol/L")
    assert v == pytest.approx(6.0 * 18.02, abs=0.1)


def test_synonyms_recognised():
    for txt in ("Chol 210 mg/dL", "T. Cholesterol: 210 mg/dL", "Total Cholesterol 210 mg/dL"):
        labs, _ = N.parse_lab_text(txt, "t")
        assert labs["total_chol"].value == 210, txt


def test_implausible_value_rejected_with_warning():
    labs, warns = N.parse_lab_text("LDL 9999 mg/dL", "t")
    assert "ldl" not in labs and warns


def test_multiple_values_in_one_sentence_and_bp():
    labs, _ = N.parse_lab_text("My LDL is 172 mg/dL, HDL 38, blood pressure 142/90", "typed")
    assert labs["ldl"].value == 172 and labs["hdl"].value == 38 and labs["systolic_bp"].value == 142 and labs["diastolic_bp"].value == 90


def test_non_hdl_not_mistaken_for_hdl():
    labs, _ = N.parse_lab_text("Non-HDL 200 mg/dL", "t")
    assert "hdl" not in labs


def test_regex_fallback_lifestyle():
    f, prov = regex_extract("I am 52 years old male, I smoke about 10 cigarettes a day, rarely exercise and sleep 5 hours. My father had a heart attack.")
    assert f["age"] == 52 and f["smoker"] is True and f["cigarettes_per_day"] == 10 and f["sleep_hours"] == 5.0
    assert f["activity"] == "sedentary" and f["family_heart_disease"] is True and "typed text" in prov["age"]["source"]


def test_negated_smoking_and_diabetes():
    f, _ = regex_extract("I don't smoke and I do not have diabetes.")
    assert f["smoker"] is False and f["diabetes"] is False


def test_missing_values_are_flagged_not_invented():
    rec, _, _ = build_record("t", [], "I am 40 years old", use_llm=False)
    assert rec.age == 40 and "ldl" in rec.missing_fields and "ldl" not in rec.labs


def test_csv_and_pdf_extraction_if_samples_exist():
    d = config.TEST_REPORT_DIR
    if not (d / "labs_wide.csv").exists():
        pytest.skip("run scripts/make_test_reports.py first")
    rec, _, errs = build_record("t", [("labs_wide.csv", (d / "labs_wide.csv").read_bytes()), ("report_digital_2.pdf", (d / "report_digital_2.pdf").read_bytes())], "", use_llm=False)
    assert not errs and rec.labs["ldl"].value == 170 and rec.labs["hba1c"].value == 6.8
    assert "labs_wide.csv" in rec.labs["ldl"].source


# ------------------------------------------------------------------ safety (Task 8)
def test_prescription_refused():
    assert safety.is_prescription_request("How many mg of atorvastatin should I take?")
    assert not safety.is_prescription_request("What foods lower cholesterol?")


def test_out_of_scope_refused():
    assert safety.is_out_of_scope("Who won the cricket match yesterday?")
    assert not safety.is_out_of_scope("What foods should I avoid to reduce my LDL?")


def test_red_flag_text_detection_and_negation():
    assert safety.detect_red_flags("I have crushing chest pain right now")
    assert not safety.detect_red_flags("I had chest pain last year but no pain now")


def test_disclaimer_always_added_and_missing_data_warning():
    assert safety.DISCLAIMER[:30] in safety.with_disclaimer("Eat more vegetables.")
    assert safety.missing_data_warning(["age", "sex", "ldl", "hdl", "total_chol", "triglycerides", "systolic_bp", "diastolic_bp"])


def test_citation_verification():
    passages = [{"doc": "AHA-Diet-2021", "page": 6}]
    ok, bad = safety.verify_citations("Limit fried food [AHA-Diet-2021, p.6] and more [Fake-Doc, p.9].", passages, [])
    assert ok and bad


# ------------------------------------------------------------------ knowledge graph / ontology (Task 1)
def test_knowledge_graph_has_60_plus_sourced_triples():
    assert kg.count_facts() >= 60
    rows = kg.run_query(kg.QUERIES["Q4 Number of facts contributed by each guideline"])
    assert sum(int(r["facts"]) for r in rows) >= 60


def test_five_sparql_queries_return_rows():
    assert len(kg.QUERIES) >= 5
    for name in kg.QUERIES:
        assert kg.run_query(name), name


def test_ontology_structure():
    from backend.knowledge.build_ontology import load_ontology
    o = load_ontology()
    names = {c.name for c in o.classes()}
    assert {"Patient", "LabTest", "LifestyleFactor", "RiskFactor", "Condition", "Symptom", "Guideline", "HighLDL"} <= names
    assert len(list(o.object_properties())) >= 8 and len(list(o.data_properties())) >= 6
    assert len(o.HighLDL.equivalent_to) >= 1


def test_patient_inserted_into_ontology_and_removed():
    from backend.knowledge.build_ontology import add_patient, remove_patient, classify_patient, load_ontology
    rec = PatientRecord(patient_id="pytest1", age=50, sex="male", labs={"ldl": LabValue(value=172, unit="mg/dL")})
    add_patient(rec)
    assert "HighLDL" in classify_patient(rec) and any(i.name.endswith("pytest1") for i in load_ontology().individuals())
    remove_patient("pytest1")
    assert not any(i.name.endswith("pytest1") for i in load_ontology().individuals())


# ------------------------------------------------------------------ RAG (Task 5)
def test_chunking_size_overlap_and_metadata():
    blocks = [{"doc": "D", "page": 3, "section": "S", "text": " ".join(f"w{i}" for i in range(600))}]
    ch = ingest.chunk_blocks(blocks, 300, 60)
    assert len(ch) >= 3 and all(c["doc"] == "D" and c["page"] == 3 and c["section"] == "S" for c in ch)
    assert set(ch[0]["text"].split()[-30:]) & set(ch[1]["text"].split()[:60])          # overlap exists
    assert all(c["tokens_est"] <= 330 for c in ch)


def test_history_trimmed_to_budget():
    hist = [{"role": "user", "content": "x" * 3000}] * 5
    assert sum(len(m["content"]) for m in prompt.trim_history(hist, 6000)) <= 6000


def test_prompt_contains_all_evidence_blocks():
    from backend.schemas import PatientRecord
    rec = PatientRecord(patient_id="p", age=50, labs={"ldl": LabValue(value=170, unit="mg/dL")})
    eng = run_rules({"ldl": 170, "age": 50})
    msgs = prompt.build_messages("q?", rec, eng, {"available": True, "probability": 0.7, "band": "High", "shap": [{"feature": "ldl", "shap": 0.1}]},
                                 [{"doc": "D", "page": 1, "section": "s", "text": "t"}], [{"source": "D", "text": "fact"}])
    body = msgs[-1]["content"] + msgs[0]["content"]
    for token in ("PATIENT FACTS", "RULE TRACE", "MODEL RISK ESTIMATE", "GUIDELINE PASSAGES", "KNOWLEDGE-GRAPH FACTS", "do not cover this", "cite"):
        assert token.lower() in body.lower(), token


# ------------------------------------------------------------------ API (Task 6)
@pytest.fixture(scope="module")
def client():
    from fastapi.testclient import TestClient
    from backend.main import app
    with TestClient(app) as c:
        yield c


def test_health_endpoint(client):
    j = client.get("/health").json()
    assert {"status", "model", "index", "ontology", "llm"} <= set(j)


def test_full_flow_and_session_deletion(client):
    r = client.post("/upload", data={"lifestyle_text": "I am 52 years old male, I smoke 10 cigarettes a day. My LDL is 172 mg/dL, blood pressure 142/90.", "use_llm": "false"})
    assert r.status_code == 200
    sid = r.json()["session_id"]
    risk = client.post("/risk", json={"session_id": sid}).json()
    assert risk["disclaimer"] and any(f["id"] == "R23" for f in risk["fired_rules"])
    chat = client.post("/chat", json={"session_id": sid, "question": "What foods should I avoid to reduce my LDL?"}).json()
    assert chat["answer"] and safety.DISCLAIMER[:30] in chat["answer"]
    assert client.delete(f"/session/{sid}").status_code == 200
    assert client.post("/risk", json={"session_id": sid}).status_code == 404


def test_emergency_bypasses_chatbot(client):
    sid = client.post("/upload", data={"lifestyle_text": "I am 55 years old and I have chest pain at rest.", "use_llm": "false"}).json()["session_id"]
    out = client.post("/chat", json={"session_id": sid, "question": "What should I eat?"}).json()
    assert "red_flag_bypass" in out["safety_flags"] and "URGENT" in out["answer"]
    client.delete(f"/session/{sid}")


def test_error_codes(client):
    assert client.post("/upload", data={"lifestyle_text": ""}).status_code == 422
    assert client.post("/upload", files={"files": ("x.exe", b"abc")}).status_code == 415
    assert client.post("/chat", json={"session_id": "nope", "question": "hi"}).status_code == 404


def test_uploaded_files_are_not_kept(client):
    import tempfile, glob
    before = set(glob.glob(f"{tempfile.gettempdir()}/krl_upload_*"))
    d = config.TEST_REPORT_DIR / "labs_long.csv"
    if not d.exists():
        pytest.skip("sample reports missing")
    sid = client.post("/upload", files={"files": ("labs_long.csv", d.read_bytes())}).json()["session_id"]
    assert set(glob.glob(f"{tempfile.gettempdir()}/krl_upload_*")) == before
    client.delete(f"/session/{sid}")
