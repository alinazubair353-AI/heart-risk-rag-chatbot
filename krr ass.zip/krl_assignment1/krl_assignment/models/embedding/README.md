Save a sentence-transformers model here for semantic retrieval (done once while online):
    python scripts/download_assets.py            # all-MiniLM-L6-v2
Then rebuild the index:  python -m backend.rag.ingest
Without a model the app uses a TF-IDF fallback (still fully offline).
