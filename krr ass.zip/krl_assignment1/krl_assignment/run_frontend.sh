#!/usr/bin/env bash
# Start the Streamlit frontend at http://localhost:8501
cd "$(dirname "$0")" && python -m streamlit run frontend/app.py --server.port 8501 --server.address localhost
