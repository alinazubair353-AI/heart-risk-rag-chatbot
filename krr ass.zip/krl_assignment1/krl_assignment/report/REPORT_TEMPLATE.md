# Report template (12-20 pages, PDF) - fill in with your own words and results

**Title page:** Offline RAG Chatbot for Heart Disease Risk Prediction - Knowledge Representation and Learning, Assignment 1.
Name: ____  Roll number: ____  Instructor: Adeel Ahmed.  Hardware (CPU/RAM/GPU) and LLM used: ____

## Required sections, in this order
1. **Abstract** (150-200 words)
2. **Introduction and objectives**
3. **System architecture** - labelled diagram of the 7 stages (Overview page of the app has one; redraw and label it)
4. **Task 1 Ontology and KG** - ontology diagram (Protege or `evaluation/results/kg_graph.png`), design decisions, table of the 6 SPARQL queries + outputs (`python -m backend.knowledge.queries`)
5. **Task 2 Extraction** - methods per file type, unit factors (38.67, 18.02, 88.57), accuracy table per type (`evaluation/results/extraction_accuracy.json`), limitations (be honest about test difficulty)
6. **Task 3 Rules** - rule table (`GET /rules`), example traces, red-flag handling, pytest output
7. **Task 4 ML** - dataset descriptions (size, features, balance, limitations, source/licence/date), model table, confusion matrices, why recall matters for screening, calibration curves, SHAP plots (`backend/ml/models/plots/`), **hybrid experiment result and discussion**
8. **Task 5 RAG** - corpus list with sources/licences/dates, chunking, embedding model, prompt (appendix), configuration comparison and why
9. **Task 6 API + UI** - endpoint table, screenshots of every section
10. **Task 7 Evaluation** - test-set design (24 profiles), all metrics, ablation table (a)-(d), >= 3 failure examples with causes (e.g. P12 contradictory smoking input is not flagged; rules fire only on stated values)
11. **Task 8 Ethics and limitations** - prediction limits, dataset bias (age/sex/ethnicity/geography), privacy measures, over-reliance, emergencies/out-of-scope
12. **Conclusion and future work**
13. **References** (IEEE or APA) - every library, model, dataset, guideline
14. **Appendix A:** sample prompts.  **B:** sample conversations (low risk, high risk, emergency).  **C: AI-assistant declaration**

## Appendix C - AI assistant declaration (required by the brief)
State: which assistant you used, what you asked (e.g. "generated the initial project scaffold from the assignment PDF"), which parts of the code
came from it, and **how you verified** them (tests you ran, files you read and modified, results you checked against the official guidelines). Be specific.

## Demo video (8-10 min, MP4)
Show: offline mode (Wi-Fi off), low-risk demo, high-risk demo (extracted values -> rules/trace -> risk dashboard + SHAP -> cited chat answer -> follow-up question),
emergency demo (bypass message), the Learning section adding a document, then *Clear session*.
