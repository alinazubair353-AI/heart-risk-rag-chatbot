"""Prompt builder (Task 5): assembles patient facts, rule trace, risk score and retrieved passages into a grounded prompt."""
from typing import Dict, List, Optional

from backend import config
from backend.safety import DISCLAIMER

SYSTEM = f"""You are a cautious cardiovascular-health education assistant for an offline university prototype.
RULES YOU MUST FOLLOW:
1. Answer ONLY from the EVIDENCE sections below (patient facts, rule trace, risk estimate, guideline passages, graph facts). Do not use outside knowledge.
2. Cite the source for every recommendation or guideline statement, using exactly the labels shown, for example [WHO-CVD-FactSheet, p.2]. Graph facts are cited as [DOCUMENT-ID].
3. If the evidence does not contain the answer, say exactly: "The provided guidelines do not cover this."
4. Never give a diagnosis. Never recommend, name for use, or dose any medicine. If asked, say a physician must decide.
5. Mention the rules that fired and the model risk estimate when they are relevant to the question, and say the risk estimate is a screening-style probability, not a diagnosis.
6. Be concise (under 220 words), in plain language, and finish with this disclaimer: "{DISCLAIMER}"
"""

NO_CONTEXT_SYSTEM = (
    "You are a cardiovascular-health education assistant. Answer briefly from your own knowledge. Never diagnose and never "
    "recommend or dose medicines. End with a one-line disclaimer that this is not medical advice.")


def patient_facts_text(record) -> str:
    L = [f"age={record.age}, sex={record.sex}, BMI={record.bmi}"]
    for k, v in record.labs.items():
        L.append(f"{k}={v.value} {v.unit} (source: {v.source}, confidence {v.confidence})")
    ls = record.lifestyle.model_dump(exclude_none=True)
    hs = record.history.model_dump(exclude_none=True)
    if ls: L.append("lifestyle: " + ", ".join(f"{k}={v}" for k, v in ls.items()))
    if hs: L.append("history: " + ", ".join(f"{k}={v}" for k, v in hs.items()))
    if record.symptoms: L.append("symptoms: " + ", ".join(record.symptoms))
    if record.missing_fields: L.append("missing (do not guess): " + ", ".join(record.missing_fields))
    return "\n".join(L)


def trim_history(history: List[Dict[str, str]], max_chars: int = config.MAX_HISTORY_CHARS) -> List[Dict[str, str]]:
    """Keep the most recent turns that fit in the context budget."""
    kept, total = [], 0
    for m in reversed(history):
        total += len(m["content"])
        if total > max_chars:
            break
        kept.append(m)
    return list(reversed(kept))


def build_messages(question: str, record=None, engine: Optional[dict] = None, risk: Optional[dict] = None,
                   passages: Optional[List[dict]] = None, graph_facts: Optional[List[dict]] = None,
                   history: Optional[List[Dict[str, str]]] = None, config_name: str = "full") -> List[Dict[str, str]]:
    if config_name == "llm_only":
        msgs = [{"role": "system", "content": NO_CONTEXT_SYSTEM}]
        msgs += trim_history(history or [])
        return msgs + [{"role": "user", "content": question}]
    parts = []
    if record is not None and config_name in ("rag_rules", "full"):
        parts.append("## PATIENT FACTS\n" + patient_facts_text(record))
    if engine and config_name in ("rag_rules", "full"):
        parts.append("## RULE TRACE (symbolic reasoning)\n" + ("\n".join(engine["trace"]) or "No rules fired.") +
                     f"\nRule-based risk category: {engine['risk_category']}")
    if risk and risk.get("available") and config_name == "full":
        top = ", ".join(f"{s['feature']} ({s['shap']:+.2f})" for s in risk["shap"][:4])
        parts.append(f"## MODEL RISK ESTIMATE\nCalibrated probability of heart disease: {risk['probability']:.0%} ({risk['band']}). "
                     f"Top SHAP contributors: {top}.")
    if passages:
        parts.append("## GUIDELINE PASSAGES\n" + "\n".join(f"[{p['doc']}, p.{p['page']}] ({p['section']}) {p['text']}" for p in passages))
    if graph_facts:
        parts.append("## KNOWLEDGE-GRAPH FACTS\n" + "\n".join(f"[{g['source']}] {g['text']}" for g in graph_facts))
    evidence = "\n\n".join(parts) if parts else "## EVIDENCE\n(none available)"
    msgs = [{"role": "system", "content": SYSTEM}]
    msgs += trim_history(history or [])
    msgs.append({"role": "user", "content": f"{evidence}\n\n## QUESTION\n{question}"})
    return msgs
