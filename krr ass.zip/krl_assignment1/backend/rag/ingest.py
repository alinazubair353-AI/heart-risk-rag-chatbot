"""Ingestion (Task 5): extract text -> clean -> chunk (300-500 tokens, 50-80 overlap) -> embed locally -> FAISS.

Run:  python -m backend.rag.ingest [--chunk 300] [--overlap 60]

Chunking is done PER PAGE so every chunk keeps an exact (document, page, section) citation. Token counts are
estimated as words x 1.33 (no tokenizer download needed, so ingestion works offline).
Embedding backend:
  * sentence-transformers model saved in models/embedding/ (all-MiniLM-L6-v2 or bge-small-en)  [preferred]
  * otherwise TF-IDF vectors (dense; SVD-compressed only for very large vocabularies)  [offline fallback]"""
import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Optional

import joblib
import numpy as np

from backend import config

TOKENS_PER_WORD = 1.33


# ----------------------------------------------------------------------------------------------- reading
def _clean(text: str) -> str:
    text = text.replace("\u00ad", "").replace("\r", "")
    text = re.sub(r"-\n(?=[a-z])", "", text)              # re-join hyphenated line breaks
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _guess_heading(line: str) -> bool:
    s = line.strip()
    return 3 < len(s) < 80 and not s.endswith((".", ",", ";")) and (s.isupper() or s.istitle() or s.startswith("#"))


def read_txt(path: Path) -> List[dict]:
    raw = path.read_text(errors="ignore")
    parts = re.split(r"\[\[PAGE\s+(\d+)\]\]", raw)
    pages = []
    if len(parts) == 1:
        pages = [(1, parts[0])]
    else:
        pages = [(int(parts[i]), parts[i + 1]) for i in range(1, len(parts) - 1, 2)]
    return _pages_to_blocks(path.stem, pages)


def read_pdf(path: Path) -> List[dict]:
    import pdfplumber
    pages = []
    with pdfplumber.open(str(path)) as pdf:
        for i, p in enumerate(pdf.pages, 1):
            pages.append((i, p.extract_text() or ""))
    return _pages_to_blocks(path.stem, pages)


def _pages_to_blocks(doc: str, pages) -> List[dict]:
    """Split every page into (section, text) blocks, keeping the current section title."""
    blocks, section = [], "Introduction"
    for page, text in pages:
        buf: List[str] = []
        for line in _clean(text).splitlines():
            if line.startswith("# "):
                continue                                   # document title line
            if line.startswith("## ") or (_guess_heading(line) and not line.startswith("Source:")):
                if buf:
                    blocks.append({"doc": doc, "page": page, "section": section, "text": " ".join(buf)}); buf = []
                section = line.lstrip("# ").strip()
            else:
                buf.append(line.strip())
        if buf:
            blocks.append({"doc": doc, "page": page, "section": section, "text": " ".join(buf)})
    return [b for b in blocks if len(b["text"].split()) >= 8]


def read_documents(folder: Path = config.GUIDE_DIR) -> List[dict]:
    blocks = []
    for p in sorted(folder.iterdir()):
        if p.suffix.lower() in (".txt", ".md"):
            blocks += read_txt(p)
        elif p.suffix.lower() == ".pdf":
            try:
                blocks += read_pdf(p)
            except Exception as e:  # noqa: BLE001
                print(f"[ingest] skipped {p.name}: {e}")
    return blocks


# ----------------------------------------------------------------------------------------------- chunking
def chunk_blocks(blocks: List[dict], chunk_tokens: int = 300, overlap_tokens: int = 60) -> List[dict]:
    """Sliding word window; a block shorter than the window becomes a single chunk."""
    size = max(20, int(chunk_tokens / TOKENS_PER_WORD))
    ov = min(int(overlap_tokens / TOKENS_PER_WORD), size // 2)
    chunks = []
    for b in blocks:
        words = b["text"].split()
        start = 0
        while start < len(words):
            piece = words[start:start + size]
            if len(piece) >= 8 or start == 0:
                chunks.append({"doc": b["doc"], "page": b["page"], "section": b["section"], "text": " ".join(piece),
                               "tokens_est": int(len(piece) * TOKENS_PER_WORD)})
            if start + size >= len(words):
                break
            start += size - ov
    for i, c in enumerate(chunks):
        c["id"] = i
    return chunks


# ----------------------------------------------------------------------------------------------- embeddings
class Embedder:
    """Unified embedding interface: sentence-transformers (local folder) or TF-IDF fallback."""

    def __init__(self, kind: str = "tfidf", st_model=None, vec=None, svd=None):
        self.kind, self.st, self.vec, self.svd = kind, st_model, vec, svd

    @classmethod
    def fit(cls, texts: List[str]) -> "Embedder":
        if (config.EMBED_MODEL_DIR / "config.json").exists() or (config.EMBED_MODEL_DIR / "modules.json").exists():
            try:
                from sentence_transformers import SentenceTransformer
                return cls("st", st_model=SentenceTransformer(str(config.EMBED_MODEL_DIR), device="cpu"))
            except Exception as e:  # noqa: BLE001
                print(f"[ingest] sentence-transformers unavailable ({e}); using TF-IDF fallback")
        from sklearn.feature_extraction.text import TfidfVectorizer
        vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True, stop_words="english", min_df=1, max_features=20000)
        X = vec.fit_transform(texts)
        svd = None
        if X.shape[1] > 8000 and X.shape[0] > 400:
            from sklearn.decomposition import TruncatedSVD
            svd = TruncatedSVD(n_components=384, random_state=0).fit(X)
        return cls("tfidf", vec=vec, svd=svd)

    def encode(self, texts: List[str]) -> np.ndarray:
        if self.kind == "st":
            return np.asarray(self.st.encode(texts, normalize_embeddings=True, show_progress_bar=False), dtype="float32")
        X = self.vec.transform(texts)
        X = self.svd.transform(X) if self.svd is not None else X.toarray()
        X = np.asarray(X, dtype="float32")
        n = np.linalg.norm(X, axis=1, keepdims=True); n[n == 0] = 1
        return X / n

    def save(self, folder: Path) -> None:
        meta = {"kind": self.kind}
        if self.kind == "tfidf":
            joblib.dump({"vec": self.vec, "svd": self.svd}, folder / "embedder.joblib")
        (folder / "embedder.json").write_text(json.dumps(meta))

    @classmethod
    def load(cls, folder: Path) -> "Embedder":
        meta = json.loads((folder / "embedder.json").read_text())
        if meta["kind"] == "st":
            from sentence_transformers import SentenceTransformer
            return cls("st", st_model=SentenceTransformer(str(config.EMBED_MODEL_DIR), device="cpu"))
        d = joblib.load(folder / "embedder.joblib")
        return cls("tfidf", vec=d["vec"], svd=d["svd"])


# ----------------------------------------------------------------------------------------------- index
def build_index(chunk_tokens: int = 300, overlap_tokens: int = 60, out_dir: Optional[Path] = None,
                guide_dir: Path = config.GUIDE_DIR) -> dict:
    out = Path(out_dir or config.INDEX_DIR)
    out.mkdir(parents=True, exist_ok=True)
    blocks = read_documents(guide_dir)
    chunks = chunk_blocks(blocks, chunk_tokens, overlap_tokens)
    if not chunks:
        raise ValueError(f"No text could be extracted from {guide_dir}. Add guideline PDF/TXT files first.")
    emb = Embedder.fit([c["text"] for c in chunks])
    vecs = emb.encode([c["text"] for c in chunks])
    try:
        import faiss
        index = faiss.IndexFlatIP(vecs.shape[1]); index.add(vecs)
        faiss.write_index(index, str(out / "index.faiss")); backend = "faiss"
    except ImportError:
        np.save(out / "vectors.npy", vecs); backend = "numpy"
    emb.save(out)
    meta = {"n_chunks": len(chunks), "n_docs": len({c["doc"] for c in chunks}), "docs": sorted({c["doc"] for c in chunks}),
            "chunk_tokens": chunk_tokens, "overlap_tokens": overlap_tokens, "embedder": emb.kind, "vector_store": backend,
            "dim": int(vecs.shape[1])}
    (out / "chunks.json").write_text(json.dumps({"meta": meta, "chunks": chunks}, indent=1))
    return meta


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--chunk", type=int, default=300); ap.add_argument("--overlap", type=int, default=60)
    a = ap.parse_args()
    print(build_index(a.chunk, a.overlap))
