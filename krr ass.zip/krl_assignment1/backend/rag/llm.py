"""Local LLM client for Ollama (localhost only). Includes an extractive fallback so the system still answers
when Ollama is not running (the fallback is clearly labelled and never invents content)."""
import json
import re
from typing import Dict, List, Optional

import httpx

from backend import config


def available() -> Dict:
    """Check the Ollama server and whether the configured model is pulled."""
    try:
        r = httpx.get(f"{config.OLLAMA_URL}/api/tags", timeout=2.0)
        names = [m.get("name", "") for m in r.json().get("models", [])]
        ok = any(n == config.OLLAMA_MODEL or n.startswith(config.OLLAMA_MODEL.split(":")[0]) for n in names)
        return {"reachable": True, "model": config.OLLAMA_MODEL, "model_pulled": ok, "models": names}
    except Exception as e:  # noqa: BLE001
        return {"reachable": False, "model": config.OLLAMA_MODEL, "model_pulled": False, "error": str(e)[:120]}


def chat(messages: List[Dict[str, str]], json_mode: bool = False, temperature: float = 0.1,
         num_ctx: int = 4096, timeout: Optional[float] = None) -> str:
    """Call Ollama /api/chat. Raises on any failure so callers can fall back."""
    payload = {"model": config.OLLAMA_MODEL, "messages": messages, "stream": False,
               "options": {"temperature": temperature, "num_ctx": num_ctx}}
    if json_mode:
        payload["format"] = "json"
    r = httpx.post(f"{config.OLLAMA_URL}/api/chat", json=payload, timeout=timeout or config.LLM_TIMEOUT)
    r.raise_for_status()
    return r.json()["message"]["content"]


def extract_json(messages: List[Dict[str, str]]) -> dict:
    """Ask the model for JSON and parse it robustly (strips code fences)."""
    raw = chat(messages, json_mode=True, temperature=0.0)
    raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
    return json.loads(raw)


def extractive_answer(question: str, passages: List[dict], graph_facts: List[dict], rule_lines: List[str],
                      risk_line: Optional[str]) -> str:
    """Fallback generator: stitches the retrieved evidence together without any generative model."""
    parts = ["(Extractive mode: the local language model is not running, so this answer simply quotes the evidence found.)"]
    if rule_lines:
        parts.append("Rules that fired for your values:\n" + "\n".join(f"- {l}" for l in rule_lines[:6]))
    if risk_line:
        parts.append(risk_line)
    if passages:
        parts.append("What the guidelines say:")
        for p in passages[:3]:
            snippet = re.sub(r"\s+", " ", p["text"]).strip()
            snippet = snippet[:320].rsplit(" ", 1)[0] + "..." if len(snippet) > 320 else snippet
            parts.append(f"- {snippet} [{p['doc']}, p.{p['page']}]")
    for g in graph_facts[:3]:
        parts.append(f"- {g['text']} [{g['source']}]")
    if not passages and not graph_facts:
        parts.append("The provided guidelines do not cover this.")
    return "\n".join(parts)
