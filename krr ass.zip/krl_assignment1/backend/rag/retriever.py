"""Hybrid retrieval (Task 5): vector search in FAISS + lexical re-ranking + knowledge-graph lookups.

mode='vector' : plain cosine-similarity top-k.
mode='hybrid' : (1) vector candidates (2k), (2) keyword-overlap and rule-source boosts re-rank them,
                (3) facts from the knowledge graph attached to the patient's inferred conditions are added."""
import json
import re
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from backend import config
from backend.knowledge import queries as kg
from backend.rag.ingest import Embedder

STOP = set("the a an of and or to in is are for with my me i what how do does should can on at be it this that your you".split())


def _terms(s: str) -> set:
    return {w for w in re.findall(r"[a-z0-9]+", s.lower()) if w not in STOP and len(w) > 2}


class Retriever:
    def __init__(self, index_dir: Path = config.INDEX_DIR):
        self.dir = Path(index_dir)
        self.chunks: List[dict] = []
        self.meta: Dict = {}
        self.emb: Optional[Embedder] = None
        self.index = None
        self.vectors = None
        self.load()

    def load(self) -> bool:
        f = self.dir / "chunks.json"
        if not f.exists():
            return False
        d = json.loads(f.read_text())
        self.chunks, self.meta = d["chunks"], d["meta"]
        self.emb = Embedder.load(self.dir)
        if (self.dir / "index.faiss").exists():
            import faiss
            self.index = faiss.read_index(str(self.dir / "index.faiss"))
        elif (self.dir / "vectors.npy").exists():
            self.vectors = np.load(self.dir / "vectors.npy")
        return True

    @property
    def ready(self) -> bool:
        return bool(self.chunks) and (self.index is not None or self.vectors is not None)

    def _vector_search(self, query: str, n: int):
        q = self.emb.encode([query])
        n = min(n, len(self.chunks))
        if self.index is not None:
            scores, ids = self.index.search(q, n)
            return list(zip(ids[0].tolist(), scores[0].tolist()))
        s = (self.vectors @ q[0]); ids = np.argsort(-s)[:n]
        return [(int(i), float(s[i])) for i in ids]

    def search(self, query: str, k: int = 4, mode: str = "hybrid", tags: Optional[List[str]] = None,
               rule_sources: Optional[List[str]] = None) -> Dict:
        if not self.ready:
            return {"passages": [], "graph_facts": []}
        tags, rule_sources = tags or [], set(rule_sources or [])
        cand = self._vector_search(query, k if mode == "vector" else max(2 * k, 8))
        qterms = _terms(query + " " + " ".join(re.sub(r"(?<!^)(?=[A-Z])", " ", t) for t in tags))
        scored = []
        for cid, s in cand:
            c = self.chunks[cid]
            score = s
            if mode == "hybrid":
                overlap = len(qterms & _terms(c["text"] + " " + c["section"])) / (len(qterms) or 1)
                score = s + 0.30 * overlap + (0.05 if c["doc"] in rule_sources else 0.0)
            scored.append((score, s, c))
        scored.sort(key=lambda x: -x[0])
        passages = [{**c, "score": round(float(sc), 4), "vector_score": round(float(v), 4)} for sc, v, c in scored[:k]]
        facts = kg.facts_for_tags(tags, limit=6) if mode == "hybrid" else []
        return {"passages": passages, "graph_facts": facts}

    def stats(self) -> dict:
        return {"ready": self.ready, **self.meta}


_retriever: Optional[Retriever] = None


def get_retriever(reload: bool = False) -> Retriever:
    global _retriever
    if _retriever is None or reload:
        _retriever = Retriever()
    return _retriever
