"""Synthetic demo dataset generator. NOT real patient data - it only lets the pipeline run end-to-end before the
public datasets (UCI Cleveland, Kaggle Heart Failure Prediction, Framingham) are placed in data/datasets/."""
import numpy as np
import pandas as pd

from backend import config

FILE = config.DATASET_DIR / "synthetic_heart_DEMO.csv"


def generate(n: int = 3000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    male = rng.binomial(1, 0.55, n)
    age = np.clip(rng.normal(54, 12, n), 25, 85).round()
    bmi = np.clip(rng.normal(27.5, 4.6, n), 16, 48).round(1)
    smoker = rng.binomial(1, 0.22, n)
    sbp = np.clip(105 + 0.55 * (age - 40) + 0.6 * (bmi - 25) + rng.normal(0, 13, n), 90, 200).round()
    ldl = np.clip(rng.normal(125, 34, n) + 0.3 * (bmi - 25), 45, 260).round()
    hdl = np.clip(rng.normal(55, 10, n) - 9 * male - 0.4 * (bmi - 25), 20, 100).round()
    tg = np.clip(np.exp(rng.normal(4.9, 0.45, n) + 0.02 * (bmi - 25)), 40, 900).round()
    glu = np.clip(rng.normal(96, 14, n) + 0.5 * (bmi - 25) + 0.2 * (age - 50), 65, 300).round()
    tc = (ldl + hdl + tg / 5).round()
    diabetes = (glu >= 126).astype(int)
    logit = (-10.2 + 0.065 * age + 0.6 * male + 0.022 * (sbp - 120) + 0.013 * (ldl - 100) - 0.03 * (hdl - 45)
             + 0.0015 * (tg - 150) + 0.012 * (glu - 100) + 0.75 * smoker + 0.03 * (bmi - 25) + rng.normal(0, 0.8, n))
    logit = (logit - logit.mean()) * 1.4 - 0.6          # centre so prevalence is about 35 %
    p = 1 / (1 + np.exp(-logit))
    df = pd.DataFrame({"age": age, "sex": male, "systolic_bp": sbp, "total_chol": tc, "ldl": ldl, "hdl": hdl,
                       "triglycerides": tg, "fasting_glucose": glu, "bmi": bmi, "smoker": smoker, "diabetes": diabetes,
                       "heart_disease": rng.binomial(1, p)})
    for c in ["total_chol", "ldl", "hdl", "triglycerides", "fasting_glucose", "bmi"]:   # realistic missingness
        df.loc[rng.random(n) < 0.04, c] = np.nan
    return df


def ensure_file() -> str:
    if not FILE.exists():
        generate().to_csv(FILE, index=False)
    return str(FILE)


if __name__ == "__main__":
    d = generate(); d.to_csv(FILE, index=False); print(FILE, d.shape, "prevalence", d.heart_disease.mean().round(3))
