"""SHAP explanations (Task 4). Model-agnostic permutation SHAP on the calibrated model, so contributions are
reported per ORIGINAL feature (age, ldl, smoker ...) rather than per encoded column."""
from pathlib import Path
from typing import List

import numpy as np
import pandas as pd
import shap


def make_explainer(model, background: pd.DataFrame):
    cols = list(background.columns)
    fn = lambda X: model.predict_proba(pd.DataFrame(X, columns=cols))[:, 1]    # noqa: E731
    masker = shap.maskers.Independent(background.values, max_samples=100)
    return shap.Explainer(fn, masker, algorithm="permutation", feature_names=cols), cols


def shap_values(explainer, cols: List[str], X: pd.DataFrame) -> np.ndarray:
    ex = explainer(X.values, max_evals=2 * len(cols) + 1 + 10, silent=True)
    return np.asarray(ex.values)


def local_explanation(explainer, cols, row: pd.DataFrame, top: int = 8) -> List[dict]:
    vals = shap_values(explainer, cols, row)[0]
    items = [{"feature": c, "value": None if pd.isna(row.iloc[0][c]) else float(row.iloc[0][c]), "shap": float(v)}
             for c, v in zip(cols, vals)]
    return sorted(items, key=lambda d: abs(d["shap"]), reverse=True)[:top]


def save_global_plot(explainer, cols, X: pd.DataFrame, path: Path) -> List[dict]:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    sample = X.sample(min(150, len(X)), random_state=0)
    vals = shap_values(explainer, cols, sample)
    imp = np.abs(vals).mean(axis=0)
    order = np.argsort(imp)
    fig, ax = plt.subplots(figsize=(7, 0.45 * len(cols) + 1.2))
    ax.barh([cols[i] for i in order], imp[order], color="#0F5C5C")
    ax.set_xlabel("mean |SHAP value| (effect on predicted probability)"); ax.set_title("Global feature importance")
    fig.tight_layout(); path.parent.mkdir(parents=True, exist_ok=True); fig.savefig(path, dpi=140); plt.close(fig)
    return [{"feature": cols[i], "mean_abs_shap": float(imp[i])} for i in order[::-1]]


def save_local_plot(items: List[dict], title: str, path: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    items = items[::-1]
    fig, ax = plt.subplots(figsize=(7, 0.45 * len(items) + 1.2))
    ax.barh([f"{i['feature']} = {i['value']:.3g}" if i["value"] is not None else f"{i['feature']} (missing)" for i in items],
            [i["shap"] for i in items], color=["#B3261E" if i["shap"] > 0 else "#0F5C5C" for i in items])
    ax.axvline(0, color="k", lw=0.6); ax.set_title(title, fontsize=10); ax.set_xlabel("SHAP value (red raises risk)")
    fig.tight_layout(); fig.savefig(path, dpi=140); plt.close(fig)
