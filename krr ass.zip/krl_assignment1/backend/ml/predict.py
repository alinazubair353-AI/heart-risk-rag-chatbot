"""Load the active risk model and score a patient record (stage 5)."""
import json
from typing import Dict, Optional

import joblib
import numpy as np

from backend import config
from backend.ml import explain, features

_cache: Dict = {}


def reload() -> None:
    _cache.clear()


def active_file() -> Optional[str]:
    p = config.MODEL_DIR / "active.json"
    return json.loads(p.read_text()).get("file") if p.exists() else None


def load():
    """Returns the artefact dict, or None when no model has been trained yet."""
    if "art" in _cache:
        return _cache["art"]
    f = active_file()
    if not f or not (config.MODEL_DIR / f).exists():
        return None
    art = joblib.load(config.MODEL_DIR / f)
    art["explainer"], art["explainer_cols"] = explain.make_explainer(art["model"], art["background"])
    _cache["art"] = art
    return art


def list_models() -> list:
    out = []
    for p in sorted(config.MODEL_DIR.glob("metrics_*.json")):
        d = json.loads(p.read_text())
        out.append({"file": f"model_{p.stem[len('metrics_'):]}.joblib", "name": d["name"], "dataset": d.get("dataset"),
                    "best_model": d["best_model"], "roc_auc": d["final_test_metrics"]["roc_auc"], "recall": d["final_test_metrics"]["recall"],
                    "hybrid": d["deployed_hybrid"], "trained_at": d["trained_at"], "n_features": d["n_features"]})
    return out


def activate(file: str) -> None:
    if not (config.MODEL_DIR / file).exists():
        raise FileNotFoundError(file)
    (config.MODEL_DIR / "active.json").write_text(json.dumps({"file": file, "name": file}))
    reload()


def band(p: float) -> str:
    return "Low" if p < 0.2 else "Moderate" if p < 0.5 else "High"


def score(record, engine_result: dict) -> dict:
    """Calibrated probability + SHAP contributions for one patient. Missing inputs are median-imputed by the pipeline,
    so the number of missing model inputs is reported as a reliability warning."""
    art = load()
    if art is None:
        return {"available": False, "warnings": ["No risk model has been trained yet (Learning section or scripts/bootstrap.py)."]}
    cols = art["features"]
    X = features.record_to_features(record, engine_result, cols)
    p = float(art["model"].predict_proba(X)[0, 1])
    base_missing = [c for c in art["base_features"] if X[c].isna().any()]
    items = explain.local_explanation(art["explainer"], art["explainer_cols"], X, top=8)
    warns = []
    if base_missing:
        warns.append(f"{len(base_missing)} of {len(art['base_features'])} model inputs are missing ({', '.join(base_missing)}); "
                     "they were filled with training-set medians, so the estimate is less reliable.")
    if len(base_missing) >= max(3, len(art["base_features"]) // 2):
        warns.append("Too many inputs are missing for a reliable estimate.")
    info = art["info"]
    return {"available": True, "probability": p, "band": band(p), "shap": items, "warnings": warns,
            "model_info": {"name": info["name"], "dataset": info["dataset"], "best_model": info["best_model"],
                           "hybrid": info["deployed_hybrid"], "roc_auc": info["final_test_metrics"]["roc_auc"],
                           "recall": info["final_test_metrics"]["recall"], "trained_at": info["trained_at"],
                           "missing_inputs": base_missing}}
