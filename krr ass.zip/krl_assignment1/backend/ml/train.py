"""Train, tune, evaluate, calibrate and explain the heart-disease risk models (Task 4).

Run:  python -m backend.ml.train                      # every CSV in data/datasets (+ demo data if none)
      python -m backend.ml.train --dataset data/datasets/heart.csv --target HeartDisease --hybrid auto

Pipeline per dataset
  1. clean + canonicalise columns -> features that exist in a patient record (features.py)
  2. stratified 80/20 split;  ALL preprocessing (median imputation, scaling) lives inside a sklearn Pipeline (no leakage)
  3. logistic regression, random forest, XGBoost tuned with GridSearchCV (5-fold stratified, ROC-AUC)
  4. accuracy / precision / recall / F1 / ROC-AUC / confusion matrix on the held-out test set
  5. CalibratedClassifierCV on the best model, calibration curves before vs after
  6. SHAP global + 3 local plots
  7. hybrid experiment: the same models with rule-derived features added (compare honestly)
The deployed artefact is saved with joblib and a pointer file (active.json) tells the backend which one to load."""
import argparse
import json
import time
import warnings
from pathlib import Path
from typing import Dict, Optional

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, brier_score_loss, confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

from backend import config
from backend.ml import explain, features, synthetic
from backend.reasoning.engine import RULE_FEATURES

warnings.filterwarnings("ignore")
SEED = 42
PLOT_DIR = config.MODEL_DIR / "plots"


def _models(fast: bool) -> Dict[str, tuple]:
    if fast:
        return {"logistic_regression": (LogisticRegression(max_iter=2000), {"clf__C": [0.1, 1.0]}),
                "random_forest": (RandomForestClassifier(random_state=SEED, n_jobs=-1), {"clf__n_estimators": [150], "clf__max_depth": [4, 8]}),
                "xgboost": (XGBClassifier(eval_metric="logloss", random_state=SEED, n_jobs=2, verbosity=0),
                            {"clf__n_estimators": [100], "clf__max_depth": [2, 3], "clf__learning_rate": [0.1]})}
    return {"logistic_regression": (LogisticRegression(max_iter=4000), {"clf__C": [0.01, 0.1, 1, 10]}),
            "random_forest": (RandomForestClassifier(random_state=SEED, n_jobs=-1),
                              {"clf__n_estimators": [200, 400], "clf__max_depth": [4, 6, 10, None], "clf__min_samples_leaf": [1, 3]}),
            "xgboost": (XGBClassifier(eval_metric="logloss", random_state=SEED, n_jobs=2, verbosity=0),
                        {"clf__n_estimators": [100, 250], "clf__max_depth": [2, 3, 5], "clf__learning_rate": [0.03, 0.1]})}


def _pipe(cols, clf) -> Pipeline:
    prep = ColumnTransformer([("num", Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), cols)])
    return Pipeline([("prep", prep), ("clf", clf)])


def _metrics(y, proba, thr=0.5) -> dict:
    pred = (proba >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"accuracy": accuracy_score(y, pred), "precision": precision_score(y, pred, zero_division=0),
            "recall": recall_score(y, pred), "f1": f1_score(y, pred), "roc_auc": roc_auc_score(y, proba),
            "confusion_matrix": [[int(tn), int(fp)], [int(fn), int(tp)]]}


def _fit_all(X_tr, y_tr, X_te, y_te, cols, fast) -> dict:
    cv = StratifiedKFold(n_splits=5 if y_tr.value_counts().min() >= 5 else 3, shuffle=True, random_state=SEED)
    results, fitted = {}, {}
    for name, (clf, grid) in _models(fast).items():
        t0 = time.time()
        gs = GridSearchCV(_pipe(cols, clf), grid, scoring="roc_auc", cv=cv, n_jobs=1)
        gs.fit(X_tr[cols], y_tr)
        proba = gs.predict_proba(X_te[cols])[:, 1]
        m = _metrics(y_te, proba)
        m.update({"cv_roc_auc": float(gs.best_score_), "best_params": {k.replace("clf__", ""): v for k, v in gs.best_params_.items()},
                  "fit_seconds": round(time.time() - t0, 1)})
        results[name], fitted[name] = m, gs.best_estimator_
    return {"metrics": results, "fitted": fitted}


def _calibration_plot(y_te, p_before, p_after, name, path: Path) -> dict:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(5.5, 5))
    ax.plot([0, 1], [0, 1], "k--", label="perfect")
    for p, lab, c in ((p_before, "before calibration", "#B3261E"), (p_after, "after calibration", "#0F5C5C")):
        fr, mp = calibration_curve(y_te, p, n_bins=8, strategy="quantile")
        ax.plot(mp, fr, "o-", label=lab, color=c)
    ax.set_xlabel("mean predicted probability"); ax.set_ylabel("observed fraction positive"); ax.legend(); ax.set_title(f"Calibration: {name}")
    fig.tight_layout(); path.parent.mkdir(parents=True, exist_ok=True); fig.savefig(path, dpi=140); plt.close(fig)
    return {"brier_before": float(brier_score_loss(y_te, p_before)), "brier_after": float(brier_score_loss(y_te, p_after))}


def train_and_save(df: pd.DataFrame, target: str, name: str, fast: bool = True, hybrid: str = "auto",
                   activate: bool = True, dataset_label: str = "") -> dict:
    """Full experiment on one DataFrame. hybrid: 'off' | 'on' | 'auto' (deploy whichever has the better ROC-AUC)."""
    t_start = time.time()
    c = features.canonicalise(df, target).drop_duplicates()
    c = c[c["y"].notna()]
    base = [f for f in features.CANON if f in c and c[f].notna().mean() > 0.3]
    if len(base) < 3:
        raise ValueError(f"Only {len(base)} usable patient-record features could be mapped from this dataset "
                         f"({base}). Need age/sex/blood pressure/cholesterol/glucose/BMI-like columns.")
    if c["y"].nunique() < 2 or len(c) < 60:
        raise ValueError("Need at least 60 rows and both classes in the target column.")
    X_base, y = c[base], c["y"].astype(int)
    X_rules = features.rule_features_df(c)
    X_all = pd.concat([X_base, X_rules], axis=1)
    X_tr, X_te, y_tr, y_te = train_test_split(X_all, y, test_size=0.2, stratify=y, random_state=SEED)

    plain = _fit_all(X_tr, y_tr, X_te, y_te, base, fast)
    hyb_cols = base + RULE_FEATURES
    hyb = _fit_all(X_tr, y_tr, X_te, y_te, hyb_cols, fast) if hybrid != "off" else None

    def best_of(res):
        n = max(res["metrics"], key=lambda k: (res["metrics"][k]["roc_auc"], res["metrics"][k]["recall"]))
        return n, res["metrics"][n]
    bn_p, bm_p = best_of(plain)
    use_hybrid, chosen, cols = False, (bn_p, plain), base
    if hyb is not None:
        bn_h, bm_h = best_of(hyb)
        if hybrid == "on" or (hybrid == "auto" and bm_h["roc_auc"] > bm_p["roc_auc"]):
            use_hybrid, chosen, cols = True, (bn_h, hyb), hyb_cols
    best_name, res = chosen
    best_pipe = res["fitted"][best_name]

    # ---- calibration (sigmoid for small data, isotonic for large)
    method = "isotonic" if len(X_tr) >= 1500 else "sigmoid"
    cal = CalibratedClassifierCV(clone(best_pipe), method=method, cv=5)
    cal.fit(X_tr[cols], y_tr)
    p_before = best_pipe.predict_proba(X_te[cols])[:, 1]
    p_after = cal.predict_proba(X_te[cols])[:, 1]
    slug = "".join(ch if ch.isalnum() else "_" for ch in name)
    cal_info = _calibration_plot(y_te, p_before, p_after, f"{best_name} ({method})", PLOT_DIR / f"calibration_{slug}.png")
    final_metrics = _metrics(y_te, p_after)
    screening = _metrics(y_te, p_after, thr=0.3)                 # lower threshold -> higher recall (screening)

    # ---- SHAP
    bg = X_tr[cols].sample(min(100, len(X_tr)), random_state=SEED)
    explainer, ecols = explain.make_explainer(cal, bg)
    global_imp = explain.save_global_plot(explainer, ecols, X_te[cols], PLOT_DIR / f"shap_global_{slug}.png")
    order = np.argsort(p_after)
    for tag, idx in (("low", order[0]), ("mid", order[len(order) // 2]), ("high", order[-1])):
        row = X_te[cols].iloc[[idx]]
        items = explain.local_explanation(explainer, ecols, row)
        explain.save_local_plot(items, f"Local explanation ({tag}-risk test patient, p={p_after[idx]:.2f})", PLOT_DIR / f"shap_local_{tag}_{slug}.png")

    info = {
        "name": name, "dataset": dataset_label, "n_rows": int(len(c)), "n_features": len(base), "features": base,
        "class_balance": {"positive": int(y.sum()), "negative": int((1 - y).sum()), "prevalence": round(float(y.mean()), 3)},
        "best_model": best_name, "deployed_hybrid": use_hybrid, "calibration_method": method, "calibration": cal_info,
        "final_test_metrics": final_metrics, "screening_threshold_0.3": screening,
        "models_without_rules": plain["metrics"], "models_with_rules": hyb["metrics"] if hyb else None,
        "hybrid_comparison": ({"best_without_rules": {"model": bn_p, "roc_auc": bm_p["roc_auc"], "recall": bm_p["recall"], "f1": bm_p["f1"]},
                               "best_with_rules": {"model": bn_h, "roc_auc": bm_h["roc_auc"], "recall": bm_h["recall"], "f1": bm_h["f1"]},
                               "delta_roc_auc": bm_h["roc_auc"] - bm_p["roc_auc"], "delta_recall": bm_h["recall"] - bm_p["recall"]} if hyb else None),
        "global_shap": global_imp, "plots_dir": str(PLOT_DIR), "trained_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "train_seconds": round(time.time() - t_start, 1),
    }
    artefact = {"model": cal, "features": cols, "base_features": base, "hybrid": use_hybrid, "background": bg, "info": info}
    config.MODEL_DIR.mkdir(parents=True, exist_ok=True)
    path = config.MODEL_DIR / f"model_{slug}.joblib"
    joblib.dump(artefact, path)
    joblib.dump(best_pipe.named_steps["prep"], config.MODEL_DIR / f"preprocessor_{slug}.joblib")
    (config.MODEL_DIR / f"metrics_{slug}.json").write_text(json.dumps(info, indent=2, default=float))
    if activate:
        (config.MODEL_DIR / "active.json").write_text(json.dumps({"file": path.name, "name": name}))
        from backend.ml import predict
        predict.reload()
    info["file"] = path.name
    return info


def load_dataset(path: Path, target: Optional[str] = None) -> tuple:
    df = pd.read_csv(path)
    t = target or features.guess_target(df)
    if t is None:
        raise ValueError(f"Could not guess the target column of {path.name}; pass --target.")
    return df, t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset"); ap.add_argument("--target"); ap.add_argument("--hybrid", default="auto", choices=["off", "on", "auto"])
    ap.add_argument("--full", action="store_true", help="larger hyper-parameter grids (slower)")
    a = ap.parse_args()
    paths = [Path(a.dataset)] if a.dataset else sorted(config.DATASET_DIR.glob("*.csv"))
    if not paths:
        paths = [Path(synthetic.ensure_file())]
    for i, p in enumerate(paths):
        df, t = load_dataset(p, a.target)
        info = train_and_save(df, t, p.stem, fast=not a.full, hybrid=a.hybrid, activate=(i == len(paths) - 1), dataset_label=p.name)
        fm = info["final_test_metrics"]
        print(f"[{p.name}] best={info['best_model']} hybrid={info['deployed_hybrid']} AUC={fm['roc_auc']:.3f} recall={fm['recall']:.3f} "
              f"brier {info['calibration']['brier_before']:.3f}->{info['calibration']['brier_after']:.3f}")


if __name__ == "__main__":
    main()
