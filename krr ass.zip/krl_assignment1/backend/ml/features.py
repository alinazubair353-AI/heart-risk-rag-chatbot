"""Column canonicalisation: maps column names of public datasets (UCI Cleveland, Kaggle Heart Failure Prediction,
Framingham, synthetic demo data, user uploads) to the features that exist in a patient record."""
import re
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

CANON = ["age", "sex", "systolic_bp", "total_chol", "ldl", "hdl", "triglycerides", "fasting_glucose",
         "fasting_high", "bmi", "smoker", "diabetes"]

ALIASES = {
    "age": ["age"],
    "sex": ["sex", "gender", "male"],
    "systolic_bp": ["systolicbp", "sysbp", "trestbps", "restingbp", "aphi", "sbp", "systolic"],
    "total_chol": ["totalchol", "totchol", "chol", "cholesterol", "totalcholesterol"],
    "ldl": ["ldl", "ldlc", "ldlcholesterol"],
    "hdl": ["hdl", "hdlc", "hdlcholesterol"],
    "triglycerides": ["triglycerides", "tg", "trig"],
    "fasting_glucose": ["fastingglucose", "glucose", "fbg"],
    "fasting_high": ["fbs", "fastingbs", "fastingbloodsugar"],
    "bmi": ["bmi"],
    "smoker": ["smoker", "currentsmoker", "smoking"],
    "diabetes": ["diabetes"],
}
TARGETS = ["heartdisease", "target", "num", "tenyearchd", "chd", "disease", "cardio", "output", "heartdisease_label",
           "heart_disease", "label", "condition"]


def _key(c: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(c).lower())


def guess_target(df: pd.DataFrame) -> Optional[str]:
    keys = {_key(c): c for c in df.columns}
    for t in TARGETS:
        if _key(t) in keys:
            return keys[_key(t)]
    return None


def column_mapping(df: pd.DataFrame, exclude: Optional[str] = None) -> Dict[str, str]:
    """canonical feature -> original column name (first alias found)."""
    keys = {_key(c): c for c in df.columns if c != exclude}
    out = {}
    for canon, aliases in ALIASES.items():
        for a in aliases:
            if a in keys:
                out[canon] = keys[a]
                break
    return out


def canonicalise(df: pd.DataFrame, target: Optional[str] = None) -> pd.DataFrame:
    """Return a DataFrame with canonical numeric feature columns (+ 'y' if target given)."""
    mapping = column_mapping(df, exclude=target)
    out = pd.DataFrame(index=df.index)
    for canon, col in mapping.items():
        s = df[col]
        if canon == "sex" and s.dtype == object:
            s = s.astype(str).str.strip().str.lower().map(lambda v: 1.0 if v.startswith("m") else 0.0 if v.startswith("f") else np.nan)
        elif canon in ("smoker", "diabetes") and s.dtype == object:
            s = s.astype(str).str.lower().map(lambda v: 1.0 if v in ("yes", "y", "true", "1") else 0.0 if v in ("no", "n", "false", "0") else np.nan)
        s = pd.to_numeric(s, errors="coerce")
        if canon in ("total_chol", "systolic_bp", "ldl", "hdl", "triglycerides", "bmi"):
            s = s.where(s > 0)                      # Kaggle heart dataset stores missing cholesterol/BP as 0
        out[canon] = s
    if "fasting_high" not in out and "fasting_glucose" in out:
        out["fasting_high"] = (out["fasting_glucose"] > 120).astype(float).where(out["fasting_glucose"].notna())
    if target is not None:
        y = pd.to_numeric(df[target], errors="coerce")
        out["y"] = (y > 0).astype(float).where(y.notna())
    return out


def row_to_facts(row: pd.Series) -> dict:
    """Canonical row -> facts dict understood by the rule engine."""
    g = lambda k: (None if k not in row or pd.isna(row[k]) else float(row[k]))   # noqa: E731
    sex = g("sex")
    return {"age": g("age"), "sex": None if sex is None else ("male" if sex >= 0.5 else "female"),
            "bmi": g("bmi"), "sbp": g("systolic_bp"), "dbp": None, "tc": g("total_chol"), "ldl": g("ldl"),
            "hdl": g("hdl"), "tg": g("triglycerides"), "glu": g("fasting_glucose"), "a1c": None,
            "smoker": None if g("smoker") is None else bool(g("smoker")), "cpd": None, "activity": None,
            "diet": None, "alcohol": None, "sleep": None, "stress": None,
            "diabetes": None if g("diabetes") is None else bool(g("diabetes")),
            "hypertension": None, "family": None, "symptoms": []}


def rule_features_df(df: pd.DataFrame) -> pd.DataFrame:
    """Compute rule-derived features for every row (hybrid experiment)."""
    from backend.reasoning.engine import run_rules, rule_feature_vector, RULE_FEATURES
    rows = [rule_feature_vector(run_rules(row_to_facts(r))) for _, r in df.iterrows()]
    return pd.DataFrame(rows, index=df.index, columns=RULE_FEATURES)


def record_to_features(record, engine_result: dict, wanted: List[str]) -> pd.DataFrame:
    """Build a one-row feature frame for a PatientRecord in the column order the model expects."""
    from backend.reasoning.engine import facts_from_record, rule_feature_vector, has_diabetes_wrapper
    f = facts_from_record(record)
    glu = f["glu"]
    vals = {"age": f["age"], "sex": None if f["sex"] is None else (1.0 if f["sex"] == "male" else 0.0),
            "systolic_bp": f["sbp"], "total_chol": f["tc"], "ldl": f["ldl"], "hdl": f["hdl"], "triglycerides": f["tg"],
            "fasting_glucose": glu, "fasting_high": None if glu is None else float(glu > 120), "bmi": f["bmi"],
            "smoker": None if f["smoker"] is None else float(bool(f["smoker"])),
            "diabetes": float(has_diabetes_wrapper(f)) if (f["diabetes"] is not None or glu is not None or f["a1c"] is not None) else None}
    vals.update(rule_feature_vector(engine_result))
    return pd.DataFrame([{k: (np.nan if vals.get(k) is None else vals[k]) for k in wanted}], columns=wanted)
