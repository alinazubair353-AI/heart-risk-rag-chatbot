"""Clinical rule base (Task 3): 36 executable rules with ids, human-readable conditions, conclusions, severities
and source references that exist in the knowledge graph (backend/knowledge/build_triples.py).

Each rule's `test(f)` receives a flat facts dict (see engine.facts_from_record) and returns either None (did not
fire) or a dict of the values that triggered it - this dict is what makes the explanation trace possible.

risk_level: 1 = Moderate, 2 = High, 3 = Very high (rules without risk_level only describe a finding).
severity:   1 info, 2 attention, 3 important, 4 prompt medical review, 5 emergency.
These rules are an educational simplification of the guidelines, not a clinical decision tool."""
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional

Facts = Dict[str, object]


@dataclass
class Rule:
    id: str
    name: str
    condition: str
    conclusion: str
    severity: int
    source: str
    test: Callable[[Facts], Optional[Dict]]
    tag: Optional[str] = None          # ontology / KG concept this rule concludes
    risk_level: Optional[int] = None
    bypass_chatbot: bool = False


def _has(f, *keys):
    return all(f.get(k) is not None for k in keys)


# ------------------------------------------------------------------ category helpers
def bp_stage(f) -> Optional[int]:
    """0 normal, 1 elevated, 2 stage 1, 3 stage 2, 4 crisis; None if no BP at all."""
    s, d = f.get("sbp"), f.get("dbp")
    if s is None and d is None:
        return None
    s_ = s if s is not None else 0
    d_ = d if d is not None else 0
    if s_ > 180 or d_ > 120: return 4
    if s_ >= 140 or d_ >= 90: return 3
    if s_ >= 130 or d_ >= 80: return 2
    if s_ >= 120: return 1
    return 0


def ldl_cat(f) -> Optional[int]:
    v = f.get("ldl")
    if v is None: return None
    return 0 if v < 100 else 1 if v < 130 else 2 if v < 160 else 3 if v < 190 else 4


def has_diabetes(f) -> bool:
    return bool(f.get("diabetes")) or (f.get("glu") is not None and f["glu"] >= 126) or (f.get("a1c") is not None and f["a1c"] >= 6.5)


def has_htn(f) -> bool:
    return bool(f.get("hypertension")) or (bp_stage(f) or 0) >= 3


def low_hdl(f) -> Optional[Dict]:
    h, sex = f.get("hdl"), f.get("sex")
    if h is None: return None
    thr = 50 if sex == "female" else 40
    return {"HDL": h, "threshold": thr, "sex": sex or "unknown (male threshold used)"} if h < thr else None


def metabolic_components(f) -> List[str]:
    c = []
    if f.get("tg") is not None and f["tg"] >= 150: c.append(f"TG={f['tg']}")
    if low_hdl(f): c.append(f"HDL={f['hdl']}")
    if (f.get("sbp") or 0) >= 130 or (f.get("dbp") or 0) >= 85: c.append(f"BP={f.get('sbp')}/{f.get('dbp')}")
    if f.get("glu") is not None and f["glu"] >= 100: c.append(f"glucose={f['glu']}")
    if f.get("bmi") is not None and f["bmi"] >= 30: c.append(f"BMI={f['bmi']}")
    return c


def sym(f, *names):
    return [s for s in (f.get("symptoms") or []) if s in names]


R: List[Rule] = [
 # ---- blood pressure (AHA/ACC 2017)
 Rule("R01", "Normal blood pressure", "SBP < 120 and DBP < 80 mmHg", "Normal blood pressure", 1, "AHA-ACC-2017-BP",
      lambda f: {"SBP": f["sbp"], "DBP": f["dbp"]} if bp_stage(f) == 0 and _has(f, "sbp", "dbp") else None, "NormalBP"),
 Rule("R02", "Elevated blood pressure", "SBP 120-129 and DBP < 80 mmHg", "Elevated blood pressure", 2, "AHA-ACC-2017-BP",
      lambda f: {"SBP": f.get("sbp"), "DBP": f.get("dbp")} if bp_stage(f) == 1 else None, "ElevatedBP"),
 Rule("R03", "Stage 1 hypertension", "SBP 130-139 or DBP 80-89 mmHg", "Hypertension stage 1", 3, "AHA-ACC-2017-BP",
      lambda f: {"SBP": f.get("sbp"), "DBP": f.get("dbp")} if bp_stage(f) == 2 else None, "Stage1Hypertension"),
 Rule("R04", "Stage 2 hypertension", "SBP >= 140 or DBP >= 90 mmHg", "Hypertension stage 2", 3, "AHA-ACC-2017-BP",
      lambda f: {"SBP": f.get("sbp"), "DBP": f.get("dbp")} if bp_stage(f) == 3 else None, "Stage2Hypertension", risk_level=2),
 Rule("R05", "Hypertensive-crisis range reading", "SBP > 180 or DBP > 120 mmHg", "Reading in crisis range: prompt medical assessment", 4, "AHA-ACC-2017-BP",
      lambda f: {"SBP": f.get("sbp"), "DBP": f.get("dbp")} if bp_stage(f) == 4 else None, "HypertensiveCrisis", risk_level=3),
 # ---- LDL categories (mg/dL) (ACC/AHA 2018)
 Rule("R06", "LDL optimal", "LDL < 100 mg/dL", "LDL optimal", 1, "ACC-AHA-2018-Cholesterol",
      lambda f: {"LDL": f["ldl"]} if ldl_cat(f) == 0 else None),
 Rule("R07", "LDL near optimal", "LDL 100-129 mg/dL", "LDL near optimal / above optimal", 1, "ACC-AHA-2018-Cholesterol",
      lambda f: {"LDL": f["ldl"]} if ldl_cat(f) == 1 else None),
 Rule("R08", "LDL borderline high", "LDL 130-159 mg/dL", "LDL borderline high", 2, "ACC-AHA-2018-Cholesterol",
      lambda f: {"LDL": f["ldl"]} if ldl_cat(f) == 2 else None, "HighLDL"),
 Rule("R09", "LDL high", "LDL 160-189 mg/dL", "LDL high (risk-enhancing)", 3, "ACC-AHA-2018-Cholesterol",
      lambda f: {"LDL": f["ldl"]} if ldl_cat(f) == 3 else None, "HighLDL", risk_level=1),
 Rule("R10", "LDL very high", "LDL >= 190 mg/dL", "LDL very high (severe hypercholesterolaemia)", 4, "ACC-AHA-2018-Cholesterol",
      lambda f: {"LDL": f["ldl"]} if ldl_cat(f) == 4 else None, "SevereHighLDL", risk_level=2),
 # ---- HDL / TG / total cholesterol
 Rule("R11", "Low HDL (sex-specific)", "HDL < 40 mg/dL (men) or < 50 mg/dL (women)", "Low protective HDL", 3, "ACC-AHA-2018-Cholesterol",
      low_hdl, "LowHDL", risk_level=1),
 Rule("R12", "Borderline-high triglycerides", "TG 150-199 mg/dL", "Triglycerides borderline high", 2, "ACC-AHA-2018-Cholesterol",
      lambda f: {"TG": f["tg"]} if f.get("tg") is not None and 150 <= f["tg"] < 200 else None, "HighTriglycerides"),
 Rule("R13", "High triglycerides", "TG 200-499 mg/dL", "Triglycerides high", 3, "ACC-AHA-2018-Cholesterol",
      lambda f: {"TG": f["tg"]} if f.get("tg") is not None and 200 <= f["tg"] < 500 else None, "HighTriglycerides"),
 Rule("R14", "Very high triglycerides", "TG >= 500 mg/dL", "Triglycerides very high: medical evaluation advised", 4, "ACC-AHA-2018-Cholesterol",
      lambda f: {"TG": f["tg"]} if f.get("tg") is not None and f["tg"] >= 500 else None, "HighTriglycerides", risk_level=1),
 Rule("R15", "High total cholesterol", "Total cholesterol >= 240 mg/dL", "Total cholesterol high", 3, "ACC-AHA-2018-Cholesterol",
      lambda f: {"TC": f["tc"]} if f.get("tc") is not None and f["tc"] >= 240 else None, "HighTotalCholesterol"),
 # ---- glucose (ADA 2024)
 Rule("R16", "Normal fasting glucose", "Fasting glucose < 100 mg/dL", "Normal fasting glucose", 1, "ADA-2024-Standards",
      lambda f: {"glucose": f["glu"]} if f.get("glu") is not None and f["glu"] < 100 else None),
 Rule("R17", "Prediabetes (glucose)", "Fasting glucose 100-125 mg/dL", "Prediabetes", 2, "ADA-2024-Standards",
      lambda f: {"glucose": f["glu"]} if f.get("glu") is not None and 100 <= f["glu"] < 126 else None, "Prediabetes"),
 Rule("R18", "Diabetes range (glucose)", "Fasting glucose >= 126 mg/dL", "Diabetes-range glucose (needs confirmation by a physician)", 3, "ADA-2024-Standards",
      lambda f: {"glucose": f["glu"]} if f.get("glu") is not None and f["glu"] >= 126 else None, "Diabetes", risk_level=2),
 Rule("R19", "Prediabetes (HbA1c)", "HbA1c 5.7-6.4 %", "Prediabetes by HbA1c", 2, "ADA-2024-Standards",
      lambda f: {"HbA1c": f["a1c"]} if f.get("a1c") is not None and 5.7 <= f["a1c"] < 6.5 else None, "Prediabetes"),
 Rule("R20", "Diabetes range (HbA1c)", "HbA1c >= 6.5 %", "Diabetes-range HbA1c (needs confirmation by a physician)", 3, "ADA-2024-Standards",
      lambda f: {"HbA1c": f["a1c"]} if f.get("a1c") is not None and f["a1c"] >= 6.5 else None, "Diabetes", risk_level=2),
 # ---- BMI (AHA LE8 / WHO)
 Rule("R21", "Overweight", "BMI 25.0-29.9 kg/m2", "Overweight", 2, "AHA-LE8-2022",
      lambda f: {"BMI": f["bmi"]} if f.get("bmi") is not None and 25 <= f["bmi"] < 30 else None, "Overweight"),
 Rule("R22", "Obesity", "BMI >= 30 kg/m2", "Obesity", 3, "AHA-LE8-2022",
      lambda f: {"BMI": f["bmi"]} if f.get("bmi") is not None and f["bmi"] >= 30 else None, "Obesity", risk_level=1),
 # ---- combined rules
 Rule("R23", "Smoker with high LDL, age > 45", "smoker AND LDL >= 160 AND age > 45", "High cardiovascular risk", 4, "ESC-2021-Prevention",
      lambda f: {"LDL": f["ldl"], "Smoking": True, "age": f["age"]} if f.get("smoker") and f.get("ldl") is not None and f["ldl"] >= 160 and (f.get("age") or 0) > 45 else None,
      "HighRisk", risk_level=2),
 Rule("R24", "Diabetes with hypertension", "diabetes AND hypertension", "Very high cardiovascular risk", 4, "ESC-2021-Prevention",
      lambda f: {"diabetes": True, "hypertension": True} if has_diabetes(f) and has_htn(f) else None, "VeryHighRisk", risk_level=3),
 Rule("R25", "Family history with elevated markers", "family history of heart disease AND age >= 40 AND (LDL >= 130 OR hypertension)",
      "Elevated risk: family history plus risk markers", 3, "ESC-2021-Prevention",
      lambda f: {"family_history": True, "age": f.get("age"), "LDL": f.get("ldl")} if f.get("family") and (f.get("age") or 0) >= 40 and ((f.get("ldl") or 0) >= 130 or has_htn(f)) else None,
      "FamilyHistoryOfCHD", risk_level=1),
 Rule("R26", "Current smoker", "smoker = true", "Smoking is a major modifiable risk factor", 3, "WHO-CVD-FactSheet",
      lambda f: {"Smoking": True, "cigarettes_per_day": f.get("cpd")} if f.get("smoker") else None, "Smoking", risk_level=1),
 Rule("R27", "Sedentary and overweight", "activity = sedentary AND BMI >= 25", "Inactivity with excess weight raises risk", 2, "WHO-PhysicalActivity-2020",
      lambda f: {"activity": "sedentary", "BMI": f["bmi"]} if f.get("activity") == "sedentary" and (f.get("bmi") or 0) >= 25 else None, "PhysicalInactivity", risk_level=1),
 Rule("R28", "Short sleep with high stress", "sleep < 6 h AND stress = high", "Short sleep and high stress are adverse for heart health", 2, "AHA-LE8-2022",
      lambda f: {"sleep_hours": f["sleep"], "stress": "high"} if f.get("sleep") is not None and f["sleep"] < 6 and f.get("stress") == "high" else None, "ShortSleep"),
 Rule("R29", "Metabolic syndrome pattern", ">= 3 of: TG >= 150, low HDL, BP >= 130/85, glucose >= 100, BMI >= 30",
      "Metabolic-syndrome pattern", 3, "ACC-AHA-2018-Cholesterol",
      lambda f: {"components": metabolic_components(f)} if len(metabolic_components(f)) >= 3 else None, "MetabolicSyndrome", risk_level=2),
 Rule("R30", "Inactive lifestyle", "activity = sedentary", "Physical inactivity is a risk factor", 2, "WHO-PhysicalActivity-2020",
      lambda f: {"activity": "sedentary"} if f.get("activity") == "sedentary" else None, "PhysicalInactivity"),
 Rule("R31", "Fried / processed food diet", "diet = high_fried_food or high_salt", "Diet is higher in saturated fat or salt than advised", 2, "AHA-Diet-2021",
      lambda f: {"diet": f["diet"]} if f.get("diet") in ("high_fried_food", "high_salt") else None, "UnhealthyDiet"),
 # ---- red flags (bypass the chatbot)
 Rule("R32", "RED FLAG: chest pain at rest", "symptom = chest pain / pressure at rest", "URGENT: seek emergency care", 5, "WHO-CVD-FactSheet",
      lambda f: {"symptom": "chest pain at rest"} if sym(f, "chest_pain_at_rest") else None, "ChestPain", bypass_chatbot=True),
 Rule("R33", "RED FLAG: pain radiating to arm/jaw", "symptom = pain spreading to left arm, jaw or neck", "URGENT: seek emergency care", 5, "WHO-CVD-FactSheet",
      lambda f: {"symptom": "pain radiating to arm/jaw"} if sym(f, "pain_radiating_to_arm_jaw") else None, "RadiatingArmPain", bypass_chatbot=True),
 Rule("R34", "RED FLAG: breathlessness at rest / fainting", "symptom = sudden breathlessness at rest OR fainting", "URGENT: seek emergency care", 5, "WHO-CVD-FactSheet",
      lambda f: {"symptom": sym(f, "breathlessness_at_rest", "syncope")} if sym(f, "breathlessness_at_rest", "syncope") else None, "Breathlessness", bypass_chatbot=True),
 Rule("R35", "RED FLAG: stroke warning signs", "symptom = facial droop, slurred speech or one-sided weakness", "URGENT: seek emergency care", 5, "WHO-CVD-FactSheet",
      lambda f: {"symptom": "stroke signs"} if sym(f, "stroke_signs") else None, "StrokeSigns", bypass_chatbot=True),
 Rule("R36", "Exertional chest pain", "symptom = chest pain (not at rest)", "Chest pain needs prompt medical review", 4, "WHO-CVD-FactSheet",
      lambda f: {"symptom": "chest pain"} if sym(f, "chest_pain") else None, "ChestPain", risk_level=2),
]

RULES_BY_ID = {r.id: r for r in R}
