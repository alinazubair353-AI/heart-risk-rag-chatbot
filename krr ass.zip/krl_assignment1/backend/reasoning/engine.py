"""Rule engine (Task 3, stage 4): runs every rule, records a trace of what fired and why, derives a risk category."""
from typing import Dict, List, Optional

from backend.reasoning.rules import R, Rule
from backend.safety import URGENT_MESSAGE, KEY_FIELDS

RISK_NAMES = {0: "Low", 1: "Moderate", 2: "High", 3: "Very high"}


def facts_from_record(rec) -> Dict:
    """Flatten a PatientRecord into the plain dict that rules read."""
    g = lambda k: rec.labs[k].value if k in rec.labs else None   # noqa: E731
    ls, h = rec.lifestyle, rec.history
    return {"age": rec.age, "sex": rec.sex, "bmi": rec.bmi, "sbp": g("systolic_bp"), "dbp": g("diastolic_bp"),
            "tc": g("total_chol"), "ldl": g("ldl"), "hdl": g("hdl"), "tg": g("triglycerides"),
            "glu": g("fasting_glucose"), "a1c": g("hba1c"), "smoker": ls.smoker, "cpd": ls.cigarettes_per_day,
            "activity": ls.activity, "diet": ls.diet, "alcohol": ls.alcohol, "sleep": ls.sleep_hours, "stress": ls.stress,
            "diabetes": h.diabetes, "hypertension": h.hypertension, "family": h.family_heart_disease,
            "symptoms": list(rec.symptoms)}


def trace_line(rule: Rule, values: Dict) -> str:
    vals = ", ".join(f"{k} = {v}" for k, v in values.items() if v is not None)
    return f"{rule.id} fired because {vals}; conclusion: {rule.conclusion}; source: {rule.source}"


def run_rules(facts: Dict, n_missing: Optional[int] = None) -> Dict:
    """Execute all rules. Returns fired rules, trace lines, inferred condition tags, risk category, red-flag status."""
    fired: List[dict] = []
    for rule in R:
        try:
            values = rule.test(facts)
        except (TypeError, KeyError):
            values = None                      # missing data means the rule simply does not fire
        if values:
            fired.append({"id": rule.id, "name": rule.name, "conclusion": rule.conclusion, "severity": rule.severity,
                          "source": rule.source, "values": values, "trace": trace_line(rule, values), "tag": rule.tag,
                          "risk_level": rule.risk_level, "bypass": rule.bypass_chatbot, "condition": rule.condition})
    level = max([f["risk_level"] for f in fired if f["risk_level"]], default=None)
    enough = any(facts.get(k) is not None for k in ("ldl", "tc", "sbp", "glu", "a1c", "bmi"))
    if level is None:
        category = "Low" if enough else "Insufficient data"
    else:
        category = RISK_NAMES[level]
    red = [f for f in fired if f["bypass"]]
    return {"fired": fired, "trace": [f["trace"] for f in fired],
            "conditions": sorted({f["tag"] for f in fired if f["tag"]}),
            "risk_category": category, "risk_level": level or 0,
            "red_flag": bool(red), "urgent_message": URGENT_MESSAGE if red else None,
            "red_flag_rules": [f["id"] for f in red]}


def run_on_record(rec) -> Dict:
    return run_rules(facts_from_record(rec))


# ------------------------------------------------------- rule-derived ML features (hybrid experiment, Task 4)
RULE_FEATURES = ["rule_risk_level", "rule_n_fired", "flag_HighLDL", "flag_LowHDL", "flag_HighTG", "flag_Prediabetes",
                 "flag_Diabetes", "flag_Hypertension", "flag_Obese"]


def rule_feature_vector(result: Dict) -> Dict[str, float]:
    ids = {f["id"] for f in result["fired"]}
    tags = set(result["conditions"])
    return {"rule_risk_level": float(result["risk_level"]), "rule_n_fired": float(len(result["fired"])),
            "flag_HighLDL": float(bool(ids & {"R09", "R10"})), "flag_LowHDL": float("R11" in ids),
            "flag_HighTG": float(bool(ids & {"R13", "R14"})), "flag_Prediabetes": float(bool(ids & {"R17", "R19"})),
            "flag_Diabetes": float(bool(ids & {"R18", "R20"})),
            "flag_Hypertension": float(bool(ids & {"R03", "R04", "R05"})), "flag_Obese": float("R22" in ids)}


def has_diabetes_wrapper(f: Dict) -> bool:
    from backend.reasoning.rules import has_diabetes
    return has_diabetes(f)
