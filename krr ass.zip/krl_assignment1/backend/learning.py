"""Helpers behind the Learning section: add guideline documents, add training datasets, train models, add KG facts.
Guideline documents and datasets are public knowledge material and are kept in data/ (this is NOT patient data)."""
import re
from pathlib import Path
from typing import Dict, List

import pandas as pd
from rdflib import Graph, Literal, RDF, RDFS, Namespace

from backend import config
from backend.ml import features, train as train_mod
from backend.rag import ingest
from backend.rag.retriever import get_retriever

MAX_BYTES = 40 * 1024 * 1024
DOC_EXT = {".pdf", ".txt", ".md"}
H = Namespace("http://example.org/heart#")
KG = Namespace("http://example.org/kg#")


def safe_name(name: str) -> str:
    n = re.sub(r"[^A-Za-z0-9._-]", "_", Path(name).name)
    if not n or n.startswith("."):
        raise ValueError("Invalid file name")
    return n


# ----------------------------------------------------------------------------- guideline documents
def list_documents() -> List[dict]:
    chunks_per_doc: Dict[str, int] = {}
    for c in get_retriever().chunks:
        chunks_per_doc[c["doc"]] = chunks_per_doc.get(c["doc"], 0) + 1
    out = []
    for p in sorted(config.GUIDE_DIR.iterdir()):
        if p.suffix.lower() in DOC_EXT:
            out.append({"name": p.name, "size_kb": round(p.stat().st_size / 1024, 1), "chunks": chunks_per_doc.get(p.stem, 0),
                        "indexed": p.stem in chunks_per_doc})
    return out


def save_document(name: str, data: bytes) -> str:
    n = safe_name(name)
    if Path(n).suffix.lower() not in DOC_EXT:
        raise ValueError("Guideline documents must be .pdf, .txt or .md")
    if len(data) > MAX_BYTES:
        raise ValueError("File too large (max 40 MB)")
    (config.GUIDE_DIR / n).write_bytes(data)
    return n


def delete_document(name: str) -> bool:
    p = config.GUIDE_DIR / safe_name(name)
    if p.exists():
        p.unlink(); return True
    return False


def reindex(chunk_tokens: int = 300, overlap_tokens: int = 60) -> dict:
    meta = ingest.build_index(chunk_tokens, overlap_tokens)
    get_retriever(reload=True)
    return meta


# ----------------------------------------------------------------------------- datasets
def list_datasets() -> List[dict]:
    out = []
    for folder in (config.DATASET_DIR, config.UPLOAD_DATASET_DIR):
        for p in sorted(folder.glob("*.csv")):
            out.append({"name": p.name, "path": str(p.relative_to(config.DATASET_DIR)), "size_kb": round(p.stat().st_size / 1024, 1),
                        "uploaded": folder == config.UPLOAD_DATASET_DIR})
    return out


def save_dataset(name: str, data: bytes) -> str:
    n = safe_name(name)
    if not n.lower().endswith(".csv"):
        raise ValueError("Training datasets must be .csv files")
    if len(data) > MAX_BYTES:
        raise ValueError("File too large (max 40 MB)")
    (config.UPLOAD_DATASET_DIR / n).write_bytes(data)
    return n


def dataset_path(name: str) -> Path:
    n = safe_name(name)
    for folder in (config.UPLOAD_DATASET_DIR, config.DATASET_DIR):
        if (folder / n).exists():
            return folder / n
    raise FileNotFoundError(name)


def preview_dataset(name: str) -> dict:
    df = pd.read_csv(dataset_path(name))
    target = features.guess_target(df)
    mapping = features.column_mapping(df, exclude=target)
    return {"name": name, "rows": int(len(df)), "columns": list(map(str, df.columns)), "head": df.head(8).fillna("").astype(str).to_dict("records"),
            "guessed_target": target, "mapped_features": mapping,
            "unmapped_columns": [c for c in df.columns if c not in mapping.values() and c != target],
            "missing_pct": {str(c): round(float(df[c].isna().mean() * 100), 1) for c in df.columns[:30]}}


def train(name: str, target: str, model_name: str, use_rules: bool, fast: bool, activate: bool) -> dict:
    df = pd.read_csv(dataset_path(name))
    if target not in df.columns:
        raise ValueError(f"Target column '{target}' not found")
    return train_mod.train_and_save(df, target, model_name or Path(name).stem, fast=fast, hybrid="on" if use_rules else "auto",
                                    activate=activate, dataset_label=name)


# ----------------------------------------------------------------------------- knowledge-graph facts
def add_triples(name: str, data: bytes) -> dict:
    """Add facts from a CSV (subject,predicate,object,text,source[,section]) or Turtle file.
    Every fact MUST name its source document (assignment requirement)."""
    g = Graph()
    if config.EXTRA_TRIPLES_FILE.exists():
        g.parse(str(config.EXTRA_TRIPLES_FILE), format="turtle")
    start = len(list(g.subjects(RDF.type, RDF.Statement)))
    added = 0
    if name.lower().endswith(".csv"):
        import io
        df = pd.read_csv(io.BytesIO(data)).fillna("")
        need = {"subject", "predicate", "object", "source"}
        if not need.issubset(df.columns):
            raise ValueError(f"CSV needs columns {sorted(need)} (optional: text, section)")
        for i, r in df.iterrows():
            if not str(r["source"]).strip():
                raise ValueError(f"Row {i + 2} has no source - every triple must record its source document")
            s_, p_ = H[re.sub(r"\W", "", str(r["subject"]))], H[re.sub(r"\W", "", str(r["predicate"]))]
            o = str(r["object"]); o_ = H[re.sub(r"\W", "", o)] if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", o) else Literal(o)
            st = KG[f"user{start + added + 1:03d}"]
            g.add((s_, p_, o_)); g.add((st, RDF.type, RDF.Statement)); g.add((st, RDF.subject, s_)); g.add((st, RDF.predicate, p_)); g.add((st, RDF.object, o_))
            g.add((st, KG.source, Literal(str(r["source"])))); g.add((st, KG.section, Literal(str(r.get("section", "")))))
            g.add((st, RDFS.comment, Literal(str(r.get("text", "")) or f"{r['subject']} {r['predicate']} {r['object']}")))
            added += 1
    elif name.lower().endswith((".ttl", ".turtle")):
        new = Graph(); new.parse(data=data.decode("utf-8", "ignore"), format="turtle")
        stmts = list(new.subjects(RDF.type, RDF.Statement))
        if any(not list(new.objects(s, KG.source)) for s in stmts):
            raise ValueError("Every rdf:Statement must have a kg:source")
        for t in new: g.add(t)
        added = len(stmts)
    else:
        raise ValueError("Use a .csv or .ttl file")
    g.serialize(destination=str(config.EXTRA_TRIPLES_FILE), format="turtle")
    from backend.knowledge import queries
    queries.load_graph(force=True)
    return {"added": added, "total_facts": queries.count_facts()}
