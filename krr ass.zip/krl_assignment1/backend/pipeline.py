"""Orchestration of the seven pipeline stages and the safe chat flow."""
import re
import time
from typing import Dict, List, Optional

from backend import config, safety
from backend.knowledge import queries as kg
from backend.knowledge.build_ontology import add_patient, remove_patient, classify_patient
from backend.ml import predict
from backend.rag import llm, prompt
from backend.rag.retriever import get_retriever
from backend.reasoning.engine import run_on_record
from backend.state import Session


def analyse(s: Session) -> Dict:
    """Stages 3-5: ontology individual -> rule engine -> ML risk. Results are cached on the session."""
    rec = s.record
    s.engine = run_on_record(rec)
    try:
        remove_patient(s.id); add_patient(rec)
        s.engine["ontology_classes"] = classify_patient(rec)
    except Exception as e:  # noqa: BLE001
        s.engine["ontology_classes"] = []
        s.engine["ontology_error"] = str(e)[:100]
    s.graph_facts = kg.facts_for_tags(s.engine["conditions"], limit=8)
    s.risk = predict.score(rec, s.engine)
    return {"engine": s.engine, "risk": s.risk}


def risk_warnings(s: Session) -> List[str]:
    w = list(s.record.warnings)
    m = safety.missing_data_warning(s.record.missing_fields)
    if m:
        w.append(m)
    if s.risk:
        w += s.risk.get("warnings", [])
    return list(dict.fromkeys(w))


def _risk_line(s: Session) -> Optional[str]:
    r = s.risk
    if r and r.get("available"):
        return f"The calibrated model estimates a {r['probability']:.0%} probability of heart disease ({r['band']}); this is a screening-style estimate, not a diagnosis."
    return None


def answer(s: Session, question: str, config_name: str = "full", top_k: int = 4, retrieval_mode: str = "hybrid") -> Dict:
    t0 = time.time()
    flags: List[str] = []
    warnings: List[str] = []
    base = {"passages": [], "graph_facts": [], "citations": [], "warnings": warnings, "safety_flags": flags, "generator": "rule"}

    # ---- S2: red flags in the new message or already in the record -> urgent message, chatbot bypassed
    new_flags = safety.detect_red_flags(question)
    if new_flags and s.record is not None:
        s.record.symptoms = sorted(set(s.record.symptoms) | set(new_flags))
        analyse(s)
    if new_flags or (s.engine and s.engine["red_flag"]):
        flags.append("red_flag_bypass")
        return {**base, "answer": safety.URGENT_MESSAGE, "latency_s": round(time.time() - t0, 3)}
    # ---- S3: no medicines / doses
    if safety.is_prescription_request(question):
        flags.append("prescription_refused")
        return {**base, "answer": safety.PRESCRIBE_REFUSAL, "latency_s": round(time.time() - t0, 3)}
    # ---- S4: out of scope
    if safety.is_out_of_scope(question, has_context=bool(s.history)):
        flags.append("out_of_scope")
        return {**base, "answer": safety.OUT_OF_SCOPE_REFUSAL, "latency_s": round(time.time() - t0, 3)}

    engine = s.engine if s.record is not None else None
    tags = engine["conditions"] if engine else []
    rule_sources = sorted({f["source"] for f in engine["fired"]}) if engine else []
    q = question
    if len(question.split()) < 8:                          # short follow-up: add the previous user question as context
        prev = next((m["content"] for m in reversed(s.history) if m["role"] == "user"), "")
        q = f"{prev} {question}".strip()

    passages, gfacts = [], []
    if config_name != "llm_only":
        res = get_retriever().search(q, k=top_k, mode=retrieval_mode, tags=tags, rule_sources=rule_sources)
        passages, gfacts = res["passages"], res["graph_facts"]
    s.last_passages = passages

    if s.record is not None:
        mw = safety.missing_data_warning(s.record.missing_fields)
        if mw: warnings.append(mw); flags.append("missing_data_warning")
        if s.risk and s.risk.get("warnings"): warnings += s.risk["warnings"]

    messages = prompt.build_messages(question, s.record, engine, s.risk, passages, gfacts, s.history, config_name)
    generator = "ollama"
    try:
        text = llm.chat(messages)
    except Exception:  # noqa: BLE001
        generator = "extractive"
        text = llm.extractive_answer(question, passages, gfacts, (engine or {}).get("trace", []) if config_name in ("rag_rules", "full") else [],
                                     _risk_line(s) if config_name == "full" else None)
        warnings.append("Local language model not reachable: answer built directly from retrieved evidence.")

    ok, bad = safety.verify_citations(text, passages, gfacts)
    if bad:
        flags.append("unverified_citation"); warnings.append("Some citations could not be matched to retrieved evidence: " + "; ".join(bad))
    text = safety.with_disclaimer(text)

    cits = [{"label": f"{p['doc']}, p.{p['page']}", "doc": p["doc"], "page": p["page"], "section": p["section"],
             "text": p["text"][:300], "verified": True} for p in passages]
    s.history += [{"role": "user", "content": question}, {"role": "assistant", "content": text}]
    s.history = prompt.trim_history(s.history, config.MAX_HISTORY_CHARS * 2)
    return {"answer": text, "citations": cits, "passages": passages, "graph_facts": gfacts, "warnings": list(dict.fromkeys(warnings)),
            "safety_flags": flags, "generator": generator, "latency_s": round(time.time() - t0, 3)}
