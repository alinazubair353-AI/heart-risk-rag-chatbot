"""In-memory session store. Uploaded reports never touch permanent storage: files are parsed from a temp dir that is
removed immediately (extraction/record_builder.py), and everything else lives only in this dict until deleted/expired."""
import shutil
import tempfile
import threading
import time
import uuid
from pathlib import Path
from typing import Dict, List, Optional

from backend import config


class Session:
    def __init__(self, sid: str):
        self.id = sid
        self.created = time.time()
        self.touched = time.time()
        self.tmpdir = Path(tempfile.mkdtemp(prefix=f"krl_{sid}_"))
        self.record = None          # PatientRecord
        self.engine: Optional[dict] = None
        self.risk: Optional[dict] = None
        self.graph_facts: List[dict] = []
        self.history: List[Dict[str, str]] = []
        self.last_passages: List[dict] = []


_SESSIONS: Dict[str, Session] = {}
_LOCK = threading.Lock()


def create_session() -> Session:
    cleanup_expired()
    sid = "session-" + uuid.uuid4().hex[:6]
    with _LOCK:
        _SESSIONS[sid] = Session(sid)
    return _SESSIONS[sid]


def get_session(sid: str) -> Session:
    s = _SESSIONS.get(sid)
    if s is None:
        raise KeyError(sid)
    s.touched = time.time()
    return s


def delete_session(sid: str) -> bool:
    """Remove every trace of a session: temp dir, ontology individuals, in-memory record and chat history."""
    with _LOCK:
        s = _SESSIONS.pop(sid, None)
    if s is None:
        return False
    shutil.rmtree(s.tmpdir, ignore_errors=True)
    try:
        from backend.knowledge.build_ontology import remove_patient
        remove_patient(sid)
    except Exception:  # noqa: BLE001
        pass
    s.record = s.engine = s.risk = None
    s.history.clear()
    return True


def cleanup_expired() -> int:
    now, n = time.time(), 0
    for sid in [k for k, v in list(_SESSIONS.items()) if now - v.touched > config.SESSION_TTL_SECONDS]:
        delete_session(sid); n += 1
    return n


def active_sessions() -> int:
    return len(_SESSIONS)
