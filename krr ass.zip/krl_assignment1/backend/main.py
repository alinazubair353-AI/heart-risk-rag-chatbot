"""FastAPI application (Task 6). Start with:  uvicorn backend.main:app --port 8000
Interactive API docs are served at http://localhost:8000/docs"""
import json
import threading
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

from backend import config, learning, pipeline, safety, state
from backend.extraction.record_builder import build_record
from backend.knowledge import queries as kg
from backend.knowledge.patient_graph import build_patient_graph
from backend.ml import predict
from backend.rag import llm
from backend.rag.retriever import get_retriever
from backend.reasoning.rules import R
from backend.schemas import (ChatRequest, ChatResponse, FiredRule, HealthResponse, RecordUpdate, RiskRequest,
                             RiskResponse, ShapItem, TrainRequest, UploadResponse)

_training = {"running": False}
ALLOWED_UPLOAD = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".csv", ".xlsx", ".xls", ".txt"}
MAX_UPLOAD = 15 * 1024 * 1024


def ensure_assets() -> None:
    """Build anything that is missing so a fresh checkout works (all offline)."""
    from backend.knowledge import build_ontology, build_triples
    if not config.ONTOLOGY_FILE.exists():
        build_ontology.build()
    if not config.TRIPLES_FILE.exists():
        build_triples.build()
    if not (config.INDEX_DIR / "chunks.json").exists():
        try:
            learning.reindex()
        except ValueError:
            pass
    if predict.load() is None:
        def _bg():
            from backend.ml import synthetic, train
            _training["running"] = True
            try:
                df, t = train.load_dataset(Path(synthetic.ensure_file()))
                train.train_and_save(df, t, "synthetic_heart_DEMO", fast=True, dataset_label="synthetic_heart_DEMO.csv")
            finally:
                _training["running"] = False
        threading.Thread(target=_bg, daemon=True).start()


@asynccontextmanager
async def lifespan(app: FastAPI):
    ensure_assets()
    yield


app = FastAPI(
    title="KRL Heart-Risk RAG Chatbot API",
    version="1.0.0",
    description=("Offline educational prototype combining an OWL ontology, a guideline knowledge graph, a clinical rule engine, "
                 "a calibrated ML risk model with SHAP, and a retrieval-augmented local LLM. **Not a medical device. "
                 "Never use real patient data.** All endpoints are local-only; uploaded reports are processed in a temporary "
                 "directory, deleted immediately, and session data is removed by `DELETE /session/{id}`."),
    openapi_tags=[{"name": "Pipeline", "description": "Upload, risk, explain and chat"},
                  {"name": "Session", "description": "Session lifecycle and privacy"},
                  {"name": "System", "description": "Health and diagnostics"},
                  {"name": "Knowledge", "description": "Rules, ontology, SPARQL"},
                  {"name": "Learning", "description": "Add guideline documents, datasets and train models"}],
    lifespan=lifespan,
)


def _session(sid: str) -> state.Session:
    try:
        return state.get_session(sid)
    except KeyError:
        raise HTTPException(404, f"Unknown or expired session '{sid}'. Create one with POST /upload.")


def _need_record(s: state.Session):
    if s.record is None or s.engine is None:
        raise HTTPException(409, "No patient data yet. Call POST /upload with files and/or lifestyle text first.")


# ------------------------------------------------------------------------------------------------ system
@app.get("/health", response_model=HealthResponse, tags=["System"], summary="Status of model, index, ontology and LLM")
def health():
    art = predict.load()
    model = ({"loaded": True, **{k: art["info"][k] for k in ("name", "dataset", "best_model", "deployed_hybrid", "trained_at")},
              "roc_auc": art["info"]["final_test_metrics"]["roc_auc"]} if art else {"loaded": False, "training": _training["running"]})
    try:
        from backend.knowledge.build_ontology import summary
        onto = {"loaded": True, **summary(), "kg_facts": kg.count_facts(), "file": config.ONTOLOGY_FILE.name}
    except Exception as e:  # noqa: BLE001
        onto = {"loaded": False, "error": str(e)[:120]}
    idx = get_retriever().stats()
    ok = bool(art) and idx.get("ready", False) and onto.get("loaded", False)
    return HealthResponse(status="ok" if ok else "degraded", model=model, index=idx, ontology=onto, llm=llm.available())


# ------------------------------------------------------------------------------------------------ pipeline
@app.post("/upload", response_model=UploadResponse, tags=["Pipeline"],
          summary="Extract a structured patient record from files and typed lifestyle text",
          responses={415: {"description": "Unsupported file type"}, 413: {"description": "File too large"}})
async def upload(files: List[UploadFile] = File(default=[]), lifestyle_text: str = Form(""),
                 session_id: Optional[str] = Form(None), use_llm: bool = Form(True)):
    """Accepts text PDFs, scanned PDFs, PNG/JPG scans (OCR), CSV/XLSX and the typed description. Creates a session if
    `session_id` is omitted. Files are processed from a temporary folder and deleted straight away."""
    if not files and not lifestyle_text.strip():
        raise HTTPException(422, "Provide at least one file or some lifestyle text.")
    payload = []
    for f in files:
        ext = Path(f.filename or "").suffix.lower()
        if ext not in ALLOWED_UPLOAD:
            raise HTTPException(415, f"Unsupported file type '{ext}'. Allowed: {', '.join(sorted(ALLOWED_UPLOAD))}")
        data = await f.read()
        if len(data) > MAX_UPLOAD:
            raise HTTPException(413, f"{f.filename} is larger than {MAX_UPLOAD // 1048576} MB")
        payload.append((f.filename, data))
    s = _session(session_id) if session_id else state.create_session()
    rec, processed, errors = build_record(s.id, payload, lifestyle_text, use_llm=use_llm, base=s.record)
    s.record = rec
    pipeline.analyse(s)
    return UploadResponse(session_id=s.id, record=rec, files_processed=processed, errors=errors)


@app.put("/record", response_model=UploadResponse, tags=["Pipeline"], summary="Replace the record with manually corrected values")
def update_record(body: RecordUpdate):
    s = _session(body.session_id)
    rec = body.record.model_copy(update={"patient_id": s.id})
    from backend.extraction.record_builder import compute_missing
    from backend.extraction.normaliser import compute_bmi
    if rec.bmi is None:
        rec.bmi = compute_bmi(rec.height_cm, rec.weight_kg)
    rec.missing_fields = compute_missing(rec)
    s.record = rec
    pipeline.analyse(s)
    return UploadResponse(session_id=s.id, record=rec, files_processed=[], errors=[])


def _risk_response(s: state.Session) -> RiskResponse:
    e, r = s.engine, s.risk or {}
    return RiskResponse(
        session_id=s.id, probability=r.get("probability"), risk_band=r.get("band", "Unavailable"),
        rule_risk_category=e["risk_category"],
        fired_rules=[FiredRule(id=f["id"], name=f["name"], conclusion=f["conclusion"], severity=f["severity"], source=f["source"],
                               values={k: v for k, v in f["values"].items()}, trace=f["trace"]) for f in e["fired"]],
        trace=e["trace"], conditions=e["conditions"], shap=[ShapItem(**x) for x in r.get("shap", [])],
        red_flag=e["red_flag"], urgent_message=e["urgent_message"], warnings=pipeline.risk_warnings(s),
        model_info=r.get("model_info", {}), disclaimer=safety.DISCLAIMER)


@app.post("/risk", response_model=RiskResponse, tags=["Pipeline"], summary="Calibrated risk, rule trace and SHAP values")
def risk(body: RiskRequest):
    s = _session(body.session_id); _need_record(s)
    pipeline.analyse(s)
    return _risk_response(s)


@app.post("/explain", tags=["Pipeline"], summary="Detailed explanation: rule definitions, ontology classes, SHAP and graph facts")
def explain(body: RiskRequest):
    s = _session(body.session_id); _need_record(s)
    return {"session_id": s.id, "rules": [{k: f[k] for k in ("id", "name", "condition", "conclusion", "severity", "source", "values", "trace")} for f in s.engine["fired"]],
            "ontology_inferred_classes": s.engine.get("ontology_classes", []), "shap": (s.risk or {}).get("shap", []),
            "graph_facts": s.graph_facts, "missing_fields": s.record.missing_fields, "disclaimer": safety.DISCLAIMER}


@app.post("/chat", response_model=ChatResponse, tags=["Pipeline"], summary="Ask a question; answer is grounded and cited")
def chat(body: ChatRequest):
    s = _session(body.session_id)
    if body.config not in ("llm_only", "rag", "rag_rules", "full") or body.retrieval_mode not in ("vector", "hybrid"):
        raise HTTPException(422, "config must be llm_only|rag|rag_rules|full and retrieval_mode vector|hybrid")
    out = pipeline.answer(s, body.question, body.config, body.top_k, body.retrieval_mode)
    return ChatResponse(session_id=s.id, disclaimer=safety.DISCLAIMER, **out)


@app.get("/graph/{session_id}", tags=["Pipeline"], summary="Patient knowledge graph (nodes and edges)")
def patient_graph(session_id: str):
    s = _session(session_id); _need_record(s)
    return build_patient_graph(s.record, s.engine, s.graph_facts)


@app.delete("/session/{session_id}", tags=["Session"], summary="Delete all temporary data for a session")
def delete_session(session_id: str):
    if not state.delete_session(session_id):
        raise HTTPException(404, "Unknown session")
    return {"deleted": session_id}


# ------------------------------------------------------------------------------------------------ knowledge
@app.get("/rules", tags=["Knowledge"], summary="The rule base (id, condition, conclusion, severity, source)")
def rules():
    return [{"id": r.id, "name": r.name, "condition": r.condition, "conclusion": r.conclusion, "severity": r.severity,
             "source": r.source, "risk_level": r.risk_level, "bypass_chatbot": r.bypass_chatbot} for r in R]


@app.get("/kg/queries", tags=["Knowledge"], summary="Names of the predefined SPARQL queries")
def kg_queries():
    return list(kg.QUERIES.keys())


@app.post("/kg/query", tags=["Knowledge"], summary="Run a predefined SPARQL query")
def kg_query(name: str):
    if name not in kg.QUERIES:
        raise HTTPException(404, "Unknown query name")
    return {"query": kg.QUERIES[name], "rows": kg.run_query(name)}


# ------------------------------------------------------------------------------------------------ learning
@app.get("/learn/status", tags=["Learning"], summary="Documents, datasets, models and knowledge-graph size")
def learn_status():
    return {"documents": learning.list_documents(), "index": get_retriever().stats(), "datasets": learning.list_datasets(),
            "models": predict.list_models(), "active_model": predict.active_file(), "kg_facts": kg.count_facts(),
            "training": _training["running"]}


@app.post("/learn/documents", tags=["Learning"], summary="Add guideline documents (PDF/TXT/MD) to the knowledge base")
async def learn_add_documents(files: List[UploadFile] = File(...), reindex: bool = Form(True),
                              chunk_tokens: int = Form(300), overlap_tokens: int = Form(60)):
    saved = []
    for f in files:
        try:
            saved.append(learning.save_document(f.filename or "", await f.read()))
        except ValueError as e:
            raise HTTPException(422, str(e))
    meta = None
    if reindex:
        try:
            meta = learning.reindex(chunk_tokens, overlap_tokens)
        except ValueError as e:
            raise HTTPException(422, str(e))
    return {"saved": saved, "index": meta}


@app.delete("/learn/documents/{name}", tags=["Learning"], summary="Remove a guideline document (re-index afterwards)")
def learn_delete_document(name: str):
    if not learning.delete_document(name):
        raise HTTPException(404, "No such document")
    return {"deleted": name}


@app.post("/learn/reindex", tags=["Learning"], summary="Rebuild the vector index with chosen chunk settings")
def learn_reindex(chunk_tokens: int = 300, overlap_tokens: int = 60):
    try:
        return learning.reindex(chunk_tokens, overlap_tokens)
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.post("/learn/datasets", tags=["Learning"], summary="Upload a CSV training dataset")
async def learn_add_dataset(file: UploadFile = File(...)):
    try:
        name = learning.save_dataset(file.filename or "", await file.read())
        return learning.preview_dataset(name)
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.get("/learn/datasets/{name}", tags=["Learning"], summary="Preview a dataset and the auto-detected column mapping")
def learn_preview(name: str):
    try:
        return learning.preview_dataset(name)
    except FileNotFoundError:
        raise HTTPException(404, "No such dataset")


@app.post("/learn/train", tags=["Learning"], summary="Train, tune, calibrate and explain models on a dataset")
def learn_train(body: TrainRequest):
    if _training["running"]:
        raise HTTPException(409, "A training job is already running")
    _training["running"] = True
    try:
        info = learning.train(body.dataset, body.target, body.name or "", body.use_rule_features, body.fast, body.activate)
        return info
    except FileNotFoundError:
        raise HTTPException(404, "No such dataset")
    except ValueError as e:
        raise HTTPException(422, str(e))
    finally:
        _training["running"] = False


@app.get("/learn/models", tags=["Learning"], summary="Trained models")
def learn_models():
    return {"models": predict.list_models(), "active": predict.active_file()}


@app.post("/learn/models/activate", tags=["Learning"], summary="Switch the model used for risk scoring")
def learn_activate(file: str):
    try:
        predict.activate(file)
    except FileNotFoundError:
        raise HTTPException(404, "No such model file")
    return {"active": file}


@app.get("/learn/metrics/{file}", tags=["Learning"], summary="Full metrics JSON of a trained model")
def learn_metrics(file: str):
    p = config.MODEL_DIR / f"metrics_{Path(file).stem.replace('model_', '', 1)}.json"
    if not p.exists():
        raise HTTPException(404, "No metrics for that model")
    return json.loads(p.read_text())


@app.post("/learn/triples", tags=["Learning"], summary="Add knowledge-graph facts (CSV or Turtle); every fact needs a source")
async def learn_triples(file: UploadFile = File(...)):
    try:
        return learning.add_triples(file.filename or "", await file.read())
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.get("/learn/plot/{name}", tags=["Learning"], summary="Plot image (calibration / SHAP) generated during training")
def learn_plot(name: str):
    p = config.MODEL_DIR / "plots" / Path(name).name
    if not p.exists():
        raise HTTPException(404, "No such plot")
    return FileResponse(p)


@app.get("/eval/results", tags=["System"], summary="Latest evaluation result tables")
def eval_results():
    out = {}
    for p in sorted((config.EVAL_DIR / "results").glob("*.json")):
        out[p.stem] = json.loads(p.read_text())
    return out


@app.get("/eval/image/{name}", tags=["System"], summary="Evaluation figure")
def eval_image(name: str):
    p = config.EVAL_DIR / "results" / Path(name).name
    if not p.exists():
        raise HTTPException(404, "No such image")
    return FileResponse(p)
