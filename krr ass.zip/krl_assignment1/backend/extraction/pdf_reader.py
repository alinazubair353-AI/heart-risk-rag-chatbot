"""Digital PDF reader using pdfplumber (Task 2). Scanned pages are handed to the OCR reader."""
from pathlib import Path
from typing import List, Tuple

import pdfplumber

from backend.extraction.normaliser import parse_lab_text, parse_demographics


def read_pdf_pages(path: Path) -> List[Tuple[int, str, bool]]:
    """Return [(page_number, text, has_text_layer)]. Tables are flattened into 'name value unit' lines."""
    pages = []
    with pdfplumber.open(str(path)) as pdf:
        for i, page in enumerate(pdf.pages, start=1):
            text = page.extract_text() or ""
            rows = []
            try:
                for table in page.extract_tables():
                    for row in table:
                        cells = [str(c).strip() for c in row if c not in (None, "")]
                        if cells:
                            rows.append(" ".join(cells))
            except Exception:
                pass
            combined = text + ("\n" + "\n".join(rows) if rows else "")
            pages.append((i, combined, len(text.strip()) > 20))
    return pages


def extract_from_pdf(path: Path, display_name: str):
    """Extract labs and demographics from a PDF.

    Returns (labs, demo_values, demo_provenance, warnings, scanned_pages)."""
    labs, dvals, dprov, warns, scanned = {}, {}, {}, [], []
    for page, text, has_layer in read_pdf_pages(path):
        if not has_layer:
            scanned.append(page)
            continue
        src = f"{display_name} p{page}"
        l, w = parse_lab_text(text, src, base_confidence=0.95)
        for k, v in l.items():
            if k not in labs or v.confidence > labs[k].confidence:
                labs[k] = v
        warns += w
        v2, p2, w2 = parse_demographics(text, src, 0.95)
        for k in v2:
            dvals.setdefault(k, v2[k]); dprov.setdefault(k, p2[k])
        warns += w2
    return labs, dvals, dprov, warns, scanned
