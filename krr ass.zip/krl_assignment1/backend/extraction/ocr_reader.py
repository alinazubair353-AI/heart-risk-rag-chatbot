"""OCR reader (Task 2): Tesseract through pytesseract with Pillow pre-processing.

Pre-processing: grayscale -> autocontrast -> median denoise -> binary threshold.
Small rotations are corrected by trying a few angles and keeping the one with the best OCR confidence.
Scanned PDF pages are rendered with PyMuPDF (a permitted PDF library), so poppler is not required."""
from pathlib import Path
from typing import List, Tuple

from PIL import Image, ImageFilter, ImageOps
import pytesseract

from backend.extraction.normaliser import parse_lab_text, parse_demographics

import os
if os.getenv("TESSERACT_CMD"):                         # Windows: set TESSERACT_CMD="C:\\Program Files\\Tesseract-OCR\\tesseract.exe"
    pytesseract.pytesseract.tesseract_cmd = os.environ["TESSERACT_CMD"]

ANGLES = (0, -2, 2, -4, 4, -6, 6)


def preprocess(img: Image.Image, threshold: int = 150) -> Image.Image:
    g = ImageOps.grayscale(img)
    g = ImageOps.autocontrast(g)
    g = g.filter(ImageFilter.MedianFilter(3))
    if min(g.size) < 900:                      # upscale small scans: Tesseract likes ~300 dpi
        f = 1400 / max(g.size)
        g = g.resize((int(g.width * f), int(g.height * f)), Image.LANCZOS)
    return g.point(lambda p: 255 if p > threshold else 0)


def _ocr(img: Image.Image) -> Tuple[str, float]:
    data = pytesseract.image_to_data(img, config="--psm 6", output_type=pytesseract.Output.DICT)
    confs = [float(c) for c, t in zip(data["conf"], data["text"]) if str(t).strip() and float(c) >= 0]
    text = pytesseract.image_to_string(img, config="--psm 6")
    return text, (sum(confs) / len(confs) / 100 if confs else 0.0)


def ocr_image(img: Image.Image) -> Tuple[str, float]:
    """OCR with a small deskew search. Returns (text, mean_confidence 0..1)."""
    base = preprocess(img)
    best_text, best_conf = "", -1.0
    for ang in ANGLES:
        rot = base if ang == 0 else base.rotate(ang, expand=True, fillcolor=255)
        text, conf = _ocr(rot)
        if conf > best_conf:
            best_text, best_conf = text, conf
        if ang == 0 and conf > 0.85:            # clean scan: no need to search
            break
    return best_text, max(best_conf, 0.0)


def render_pdf_pages(path: Path, pages: List[int]) -> List[Tuple[int, Image.Image]]:
    try:
        import pymupdf as fitz  # PyMuPDF
    except ImportError:
        import fitz
    out = []
    with fitz.open(str(path)) as doc:
        for p in pages:
            pix = doc[p - 1].get_pixmap(dpi=250)
            out.append((p, Image.frombytes("RGB", (pix.width, pix.height), pix.samples)))
    return out


def extract_from_image(img: Image.Image, display_name: str):
    """Returns (labs, demo_values, demo_provenance, warnings)."""
    text, conf = ocr_image(img)
    base = round(min(0.9, 0.35 + conf * 0.6), 2)       # OCR values are never fully trusted
    labs, warns = parse_lab_text(text, display_name, base_confidence=base)
    dvals, dprov, w2 = parse_demographics(text, display_name, base)
    return labs, dvals, dprov, warns + w2


def extract_from_image_file(path: Path, display_name: str):
    with Image.open(path) as im:
        return extract_from_image(im.convert("RGB"), display_name)


def extract_from_scanned_pdf(path: Path, pages: List[int], display_name: str):
    labs, dvals, dprov, warns = {}, {}, {}, []
    for p, im in render_pdf_pages(path, pages):
        l, v, pr, w = extract_from_image(im, f"{display_name} p{p} (OCR)")
        for k, x in l.items():
            if k not in labs or x.confidence > labs[k].confidence:
                labs[k] = x
        for k in v:
            dvals.setdefault(k, v[k]); dprov.setdefault(k, pr[k])
        warns += w
    return labs, dvals, dprov, warns
