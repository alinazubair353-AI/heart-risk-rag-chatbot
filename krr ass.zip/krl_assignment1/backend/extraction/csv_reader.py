"""CSV / Excel lab-file reader (Task 2). Supports wide files (one column per test) and long files (test,value,unit)."""
from pathlib import Path
import re

import pandas as pd

from backend.extraction.normaliser import (LAB_SPECS, parse_lab_text, parse_demographics, is_plausible, convert_value)
from backend.schemas import LabValue


def _read_any(path: Path) -> pd.DataFrame:
    if path.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(path)
    return pd.read_csv(path, sep=None, engine="python")


def _key_for_name(name: str):
    """Map a column / test name to a canonical lab key using the same synonym dictionary as the text parser."""
    labs, _ = parse_lab_text(f"{name} 100", "x")      # trick: reuse the synonym matcher
    if labs:
        return next(iter(labs))
    if re.fullmatch(r"\s*(?:chol|cholesterol)\s*", name, flags=re.I):
        return "total_chol"
    return None


def extract_from_csv(path: Path, display_name: str):
    """Returns (labs, demo_values, demo_provenance, warnings)."""
    df = _read_any(path)
    labs, dvals, dprov, warns = {}, {}, {}, []
    cols = {c.lower().strip(): c for c in df.columns}

    # ---- long format: columns test/value/(unit)
    test_col = next((cols[c] for c in cols if c in ("test", "test_name", "name", "analyte", "parameter")), None)
    val_col = next((cols[c] for c in cols if c in ("value", "result", "val")), None)
    unit_col = next((cols[c] for c in cols if c in ("unit", "units")), None)
    if test_col and val_col:
        for i, row in df.iterrows():
            name = str(row[test_col])
            key = _key_for_name(name)
            try:
                val = float(row[val_col])
            except (TypeError, ValueError):
                continue
            if key is None:
                low = name.lower()
                if low in ("age",) and is_plausible("age", val):
                    dvals["age"] = int(val); dprov["age"] = {"source": f"{display_name} row {i + 2}", "confidence": 1.0}
                elif low in ("bmi",) and is_plausible("bmi", val):
                    dvals["bmi"] = val; dprov["bmi"] = {"source": f"{display_name} row {i + 2}", "confidence": 1.0}
                continue
            unit = str(row[unit_col]) if unit_col and pd.notna(row[unit_col]) else None
            _put(labs, warns, key, val, unit, f"{display_name} row {i + 2}")
        return labs, dvals, dprov, warns

    # ---- wide format: one column per test, first row(s) = patients
    row0 = df.iloc[0] if len(df) else None
    if row0 is None:
        return labs, dvals, dprov, ["CSV file is empty"]
    for c in df.columns:
        low = str(c).lower().strip()
        src = f"{display_name} row 2"
        if low == "age" and pd.notna(row0[c]) and is_plausible("age", float(row0[c])):
            dvals["age"] = int(row0[c]); dprov["age"] = {"source": src, "confidence": 1.0}; continue
        if low in ("sex", "gender") and pd.notna(row0[c]):
            dvals["sex"] = "male" if str(row0[c]).lower().startswith("m") else "female"
            dprov["sex"] = {"source": src, "confidence": 1.0}; continue
        if low in ("bmi", "height_cm", "weight_kg") and pd.notna(row0[c]):
            k = low
            if is_plausible(k, float(row0[c])):
                dvals[k] = float(row0[c]); dprov[k] = {"source": src, "confidence": 1.0}
            continue
        unit_m = re.search(r"\(([^)]+)\)", str(c))
        name = re.sub(r"\([^)]*\)", "", str(c)).strip()
        key = _key_for_name(name)
        if key and pd.notna(row0[c]):
            try:
                _put(labs, warns, key, float(row0[c]), unit_m.group(1) if unit_m else None, src)
            except ValueError:
                warns.append(f"Non-numeric value in column {c}")
    return labs, dvals, dprov, warns


def _put(labs, warns, key, val, unit, src):
    v, u, note = convert_value(key, val, unit)
    if not is_plausible(key, v):
        warns.append(f"Rejected implausible {LAB_SPECS[key]['label']} = {v} {u} from {src}")
        return
    labs[key] = LabValue(value=v, unit=u, source=src + (f" ({note})" if note else ""), confidence=1.0 if not note else 0.85)
