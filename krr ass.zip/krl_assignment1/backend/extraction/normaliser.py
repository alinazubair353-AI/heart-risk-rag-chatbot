"""Unit conversion, synonym recognition, plausibility validation and lab-value parsing (Task 2).

Conversion factors
  cholesterol (total / LDL / HDL): mmol/L x 38.67  = mg/dL   (given in the assignment)
  glucose:                          mmol/L x 18.02  = mg/dL   (given in the assignment)
  triglycerides:                    mmol/L x 88.57  = mg/dL   (standard clinical factor)
  HbA1c:                            mmol/mol -> % via (x / 10.929) + 2.15 (IFCC -> NGSP)
"""
import re
from typing import Dict, List, Optional, Tuple

from backend.schemas import LabValue

CHOL_FACTOR = 38.67
GLUCOSE_FACTOR = 18.02
TG_FACTOR = 88.57

# canonical key -> (display label, canonical unit, plausible range, synonyms as regex)
_NUM = r"(?P<val>\d+(?:[.,]\d+)?)"
LAB_SPECS: Dict[str, dict] = {
    "ldl": dict(label="LDL cholesterol", unit="mg/dL", range=(20, 400),
                syn=[r"low[-\s]density\s+lipoprotein(?:\s+cholesterol)?", r"\bl[do]l[-\s]?c(?:holesterol)?\b", r"\bldl(?:[-\s]?c(?:holesterol)?)?\b(?!\s*/)"]),
    "hdl": dict(label="HDL cholesterol", unit="mg/dL", range=(10, 150),
                syn=[r"high[-\s]density\s+lipoprotein(?:\s+cholesterol)?", r"(?<!non[-\s])\bh[do]l[-\s]?c(?:holesterol)?\b", r"(?<!non[-\s])(?<!non)\bhdl(?:[-\s]?c(?:holesterol)?)?\b"]),
    "total_chol": dict(label="Total cholesterol", unit="mg/dL", range=(80, 600),
                       syn=[r"total\s+cholesterol", r"chol(?:esterol)?\s*,\s*total", r"cholesterol\s*,?\s*total", r"\bt\.?\s*cholesterol", r"\btot\.?\s*chol(?:esterol)?\b",
                            r"\bt\.?\s*chol\b", r"\bTC\b"]),
    "triglycerides": dict(label="Triglycerides", unit="mg/dL", range=(30, 2000),
                          syn=[r"\btriglycerides?\b", r"\btrigs?\b", r"\bTG\b"]),
    "fasting_glucose": dict(label="Fasting glucose", unit="mg/dL", range=(40, 600),
                            syn=[r"fasting\s+(?:blood\s+)?(?:glucose|sugar)", r"\bFBS\b", r"\bFBG\b", r"\bFPG\b",
                                 r"glucose[, ]*fasting", r"blood\s+(?:glucose|sugar)", r"\bglucose\b"]),
    "hba1c": dict(label="HbA1c", unit="%", range=(3, 20),
                  syn=[r"hb\s*a[1lI]c", r"glyc(?:at|osyl)ed\s+h(?:a)?emoglobin", r"\ba1c\b"]),
    "systolic_bp": dict(label="Systolic BP", unit="mmHg", range=(60, 280),
                        syn=[r"systolic(?:\s+bp|\s+blood\s+pressure)?", r"\bSBP\b"]),
    "diastolic_bp": dict(label="Diastolic BP", unit="mmHg", range=(30, 160),
                         syn=[r"diastolic(?:\s+bp|\s+blood\s+pressure)?", r"\bDBP\b"]),
}
# generic cholesterol synonym: only used when the line is not LDL/HDL/VLDL
GENERIC_CHOL = r"\bchol(?:esterol)?\b"
LAB_ORDER = ["ldl", "hdl", "total_chol", "triglycerides", "hba1c", "fasting_glucose", "systolic_bp", "diastolic_bp"]
UNIT_RE = r"(?P<unit>(?i:mmol\s*/\s*mol|mmol\s*/\s*l|mg\s*/\s*dl|mm\s?hg|%))?"

PLAUSIBLE = {k: v["range"] for k, v in LAB_SPECS.items()}
PLAUSIBLE.update({"age": (1, 120), "bmi": (10, 80), "height_cm": (50, 250), "weight_kg": (10, 400),
                  "sleep_hours": (0, 24), "cigarettes_per_day": (0, 100)})


def _f(x: str) -> float:
    return float(x.replace(",", "."))


def normalise_unit_name(u: Optional[str]) -> Optional[str]:
    if not u:
        return None
    u = re.sub(r"\s+", "", u.lower())
    return {"mmol/l": "mmol/L", "mg/dl": "mg/dL", "mmhg": "mmHg", "%": "%", "mmol/mol": "mmol/mol"}.get(u, u)


def convert_value(key: str, value: float, unit: Optional[str]) -> Tuple[float, str, Optional[str]]:
    """Convert a lab value to the canonical unit. Returns (value, canonical_unit, note).

    If the unit is missing, a cautious guess is made from the magnitude and noted."""
    unit = normalise_unit_name(unit)
    note = None
    canon = LAB_SPECS[key]["unit"]
    if key in ("ldl", "hdl", "total_chol"):
        if unit is None and value < 30:
            unit, note = "mmol/L", "unit missing, assumed mmol/L from magnitude"
        if unit == "mmol/L":
            return round(value * CHOL_FACTOR, 1), canon, note or f"converted from mmol/L (x{CHOL_FACTOR})"
    elif key == "triglycerides":
        if unit is None and value < 15:
            unit, note = "mmol/L", "unit missing, assumed mmol/L from magnitude"
        if unit == "mmol/L":
            return round(value * TG_FACTOR, 1), canon, note or f"converted from mmol/L (x{TG_FACTOR})"
    elif key == "fasting_glucose":
        if unit is None and value < 35:
            unit, note = "mmol/L", "unit missing, assumed mmol/L from magnitude"
        if unit == "mmol/L":
            return round(value * GLUCOSE_FACTOR, 1), canon, note or f"converted from mmol/L (x{GLUCOSE_FACTOR})"
    elif key == "hba1c":
        if unit == "mmol/mol" or (unit is None and value > 20):
            return round(value / 10.929 + 2.15, 1), canon, "converted from mmol/mol"
    return value, canon, note


def mgdl_to_mmol(key: str, value: float) -> float:
    """Inverse conversion, used for display and tests."""
    f = {"ldl": CHOL_FACTOR, "hdl": CHOL_FACTOR, "total_chol": CHOL_FACTOR,
         "triglycerides": TG_FACTOR, "fasting_glucose": GLUCOSE_FACTOR}[key]
    return round(value / f, 2)


def is_plausible(key: str, value: float) -> bool:
    lo, hi = PLAUSIBLE.get(key, (-1e9, 1e9))
    return lo <= value <= hi


def _match_all(line: str) -> List[Tuple[str, float, Optional[str]]]:
    """Find every lab key/value/unit on one line of text (typed sentences often hold several values)."""
    found = []
    has_lipid_variant = re.search(r"\b(?:ldl|hdl|vldl|non[-\s]?hdl|l[do]l|h[do]l)\b", line, flags=re.I)
    for key in LAB_ORDER:
        patterns = list(LAB_SPECS[key]["syn"])
        if key == "total_chol" and not has_lipid_variant:
            patterns.append(GENERIC_CHOL)
        for syn in patterns:
            case_sensitive = bool(re.fullmatch(r"\\b(?:TC|TG|SBP|DBP|FBS|FBG|FPG)\\b", syn))
            label = syn if case_sensitive else f"(?i:{syn})"
            rx = re.compile(rf"(?:{label})\s*(?:\((?P<u1>[^)]{{0,12}})\))?\s*(?:[:=\-\u2013]|(?i:is|was))?\s*{_NUM}\s*{UNIT_RE}")
            m = rx.search(line)
            if m:
                found.append((key, _f(m.group("val")), m.group("unit") or m.group("u1")))
                break
    return found


BP_RE = re.compile(r"(?:blood\s+pressure|\bBP\b)\D{0,25}?(?P<sys>\d{2,3})\s*/\s*(?P<dia>\d{2,3})", re.I)


def parse_lab_text(text: str, source: str, base_confidence: float = 0.9) -> Tuple[Dict[str, LabValue], List[str]]:
    """Parse lab values out of raw text. Returns (labs, warnings).

    Implausible values are rejected with a warning (never silently accepted); missing values are not invented."""
    labs: Dict[str, LabValue] = {}
    warnings: List[str] = []
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        m = BP_RE.search(line)
        if m:
            for k, g in (("systolic_bp", "sys"), ("diastolic_bp", "dia")):
                _store(labs, warnings, k, float(m.group(g)), "mmHg", source, base_confidence)
            line = (line[:m.start()] + " " + line[m.end():]).strip()      # keep scanning the rest of the sentence
        for key, val, unit in _match_all(line):
            _store(labs, warnings, key, val, unit, source, base_confidence)
    return labs, warnings


def _store(labs, warnings, key, val, unit, source, conf):
    v, u, note = convert_value(key, val, unit)
    if not is_plausible(key, v):
        warnings.append(f"Rejected implausible {LAB_SPECS[key]['label']} = {v} {u} from {source}")
        return
    c = conf - (0.1 if note and "assumed" in note else 0)
    src = f"{source}" + (f" ({note})" if note else "")
    if key in labs and labs[key].confidence >= c:
        return
    labs[key] = LabValue(value=v, unit=u, source=src, confidence=round(max(c, 0.1), 2))


DEMO_PATTERNS = {
    "age": re.compile(r"\bage\b\s*[:=\-]?\s*(\d{1,3})\b|\b(\d{1,3})\s*(?:years?|yrs?)(?:\s*old)?\b", re.I),
    "sex": re.compile(r"\b(?:sex|gender)\b\s*[:=\-]?\s*(male|female|m|f)\b", re.I),
    "height_cm": re.compile(r"\bheight\b\s*[:=\-]?\s*(\d{2,3}(?:\.\d+)?)\s*cm", re.I),
    "weight_kg": re.compile(r"\bweight\b\s*[:=\-]?\s*(\d{2,3}(?:\.\d+)?)\s*kg", re.I),
    "bmi": re.compile(r"\bbmi\b\s*[:=\-]?\s*(\d{2}(?:\.\d+)?)", re.I),
}


def parse_demographics(text: str, source: str, conf: float = 0.9) -> Tuple[dict, dict, List[str]]:
    """Return (values, provenance, warnings) for age, sex, height, weight, BMI found in text."""
    vals, prov, warns = {}, {}, []
    for key, rx in DEMO_PATTERNS.items():
        m = rx.search(text or "")
        if not m:
            continue
        raw = next(g for g in m.groups() if g)
        if key == "sex":
            v = "male" if raw.lower().startswith("m") else "female"
        else:
            v = int(raw) if key == "age" else float(raw)
            if not is_plausible(key, v):
                warns.append(f"Rejected implausible {key} = {v} from {source}")
                continue
        vals[key] = v
        prov[key] = {"source": source, "confidence": conf}
    return vals, prov, warns


def compute_bmi(height_cm: Optional[float], weight_kg: Optional[float]) -> Optional[float]:
    if height_cm and weight_kg and height_cm > 0:
        return round(weight_kg / (height_cm / 100) ** 2, 1)
    return None
