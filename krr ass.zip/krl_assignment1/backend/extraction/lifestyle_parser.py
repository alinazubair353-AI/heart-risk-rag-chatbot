"""Typed lifestyle description -> structured fields (Task 2).

Primary path:  local LLM (Ollama) with a fixed Pydantic JSON schema (LifestyleExtraction).
Fallback path: regular expressions for the most important fields, used when the model is unreachable or
returns invalid JSON. Values the LLM leaves empty are also back-filled by the regex layer."""
import re
from typing import Dict, List, Tuple

from pydantic import ValidationError

from backend.schemas import LifestyleExtraction
from backend.extraction.normaliser import is_plausible
from backend import safety

SYSTEM_PROMPT = (
    "You extract structured facts from a patient's lifestyle description. Return ONLY a JSON object that follows this "
    "schema exactly. Use null for anything not stated; never guess. Allowed values: activity in "
    "[sedentary, moderate, active]; diet in [healthy, mixed, high_fried_food, high_salt]; alcohol in "
    "[none, moderate, heavy]; stress in [low, moderate, high]; sex in [male, female]. symptoms is a list of short "
    "phrases such as 'chest pain at rest'.\nSchema: " + str(LifestyleExtraction.model_json_schema()["properties"].keys())
)


def _sentence_for(text: str, span: Tuple[int, int]) -> str:
    start = max(text.rfind(".", 0, span[0]), text.rfind("!", 0, span[0]), text.rfind("?", 0, span[0])) + 1
    ends = [i for i in (text.find(".", span[1]), text.find("!", span[1]), text.find("?", span[1])) if i != -1]
    end = min(ends) if ends else len(text)
    return text[start:end].strip()[:160]


def _neg(t: str, term: str) -> bool:
    return bool(re.search(rf"(?:no|not|without|never|don'?t have|do not have|doesn'?t have|denies)\s+(?:\w+\s+){{0,2}}{term}", t))


def regex_extract(text: str) -> Tuple[Dict, Dict]:
    """Regex fallback. Returns (fields, provenance) where provenance maps field -> sentence it came from."""
    t = text or ""
    low = t.lower()
    out: Dict = {}
    prov: Dict = {}

    def put(field, value, m):
        out[field] = value
        prov[field] = {"source": f'typed text: "{_sentence_for(t, m.span())}"', "confidence": 0.6}

    if m := re.search(r"\b(?:i am|i'm|age[d]?[:\s])\s*(\d{2})\b|\b(\d{2})[-\s]?(?:years?[-\s]old|yo\b|y/o)", low):
        v = int(next(g for g in m.groups() if g))
        if is_plausible("age", v):
            put("age", v, m)
    if m := re.search(r"\b(female|woman|girl)\b", low):
        put("sex", "female", m)
    elif m := re.search(r"\b(male|man|boy)\b", low):
        put("sex", "male", m)
    if m := re.search(r"(\d+(?:\.\d+)?)\s*(?:cm)\b", low):
        v = float(m.group(1))
        if is_plausible("height_cm", v):
            put("height_cm", v, m)
    if m := re.search(r"(\d+(?:\.\d+)?)\s*kg\b", low):
        v = float(m.group(1))
        if is_plausible("weight_kg", v):
            put("weight_kg", v, m)
    # smoking
    if m := re.search(r"non[-\s]?smoker|(?:don'?t|do not|never)\s+smoke|never\s+smoked|quit\s+smoking|ex[-\s]?smoker|stopped\s+smoking", low):
        put("smoker", False, m)
    elif m := re.search(r"\b(?:smoke|smoker|smoking|cigarettes?|cigs?)\b", low):
        put("smoker", True, m)
    if m := re.search(r"(\d+)\s*(?:cigarettes?|cigs?)", low):
        put("cigarettes_per_day", int(m.group(1)), m)
        out.setdefault("smoker", True)
    elif m := re.search(r"(?:a|one)\s+pack\s+(?:a|per)\s+day", low):
        put("cigarettes_per_day", 20, m)
        out.setdefault("smoker", True)
    # sleep
    if m := re.search(r"sleep\w*\D{0,20}?(\d+(?:\.\d+)?)\s*(?:h\b|hours?|hrs?)|(\d+(?:\.\d+)?)\s*(?:h\b|hours?|hrs?)\s*(?:of\s+)?(?:sleep|a night)", low):
        v = float(next(g for g in m.groups() if g))
        if is_plausible("sleep_hours", v):
            put("sleep_hours", v, m)
    # activity
    if m := re.search(r"rarely\s+exercise|never\s+exercise|no\s+exercise|sedentary|inactive|don'?t\s+exercise|desk\s+job|do not exercise", low):
        put("activity", "sedentary", m)
    elif m := re.search(r"exercise\s+(?:daily|regularly|every\s+day)|work\s*out\s+(?:daily|regularly|\d)|(?:gym|jog|run|swim|cycl)\w*\s+(?:daily|regularly|\d)|very\s+active|active\s+lifestyle", low):
        put("activity", "active", m)
    elif m := re.search(r"sometimes\s+exercise|exercise\s+(?:once|twice|\d\s+times)|walk\w*\s+(?:daily|regularly|\d+\s*min)|light\s+exercise|moderately\s+active", low):
        put("activity", "moderate", m)
    # diet
    if m := re.search(r"fried|fast\s+food|junk|processed\s+(?:food|meat)|deep[-\s]fried", low):
        put("diet", "high_fried_food", m)
    elif m := re.search(r"extra\s+salt|salty|high\s+salt|lots\s+of\s+salt", low):
        put("diet", "high_salt", m)
    elif m := re.search(r"vegetables?|fruits?|mediterranean|balanced\s+diet|healthy\s+diet|whole\s+grain", low):
        put("diet", "healthy", m)
    # alcohol
    if m := re.search(r"(?:don'?t|do not|never)\s+(?:drink|consume\s+alcohol)|no\s+alcohol|teetotal|abstain", low):
        put("alcohol", "none", m)
    elif m := re.search(r"heavy\s+drink|drink\s+(?:daily|every\s+day)|binge", low):
        put("alcohol", "heavy", m)
    elif m := re.search(r"\b(?:drink|alcohol|beer|wine)\b", low):
        put("alcohol", "moderate", m)
    # stress
    if m := re.search(r"low\s+stress|not\s+stressed|relaxed|stress[-\s]free", low):
        put("stress", "low", m)
    elif m := re.search(r"high\s+stress|very\s+stress\w*|stressful|stressed|anxious|burn(?:ed)?\s*out|under\s+pressure", low):
        put("stress", "high", m)
    # history
    if m := re.search(r"diabet", low):
        put("diabetes", not _neg(low, r"diabet\w*") and not re.search(r"not\s+diabetic", low), m)
    if m := re.search(r"hypertens|high\s+blood\s+pressure|hypertensive", low):
        put("hypertension", not _neg(low, r"(?:hypertension|high\s+blood\s+pressure)"), m)
    if m := re.search(r"(?:father|mother|parent|family|brother|sister|grandfather|grandmother|uncle)\b[^.]{0,50}\b(?:heart|cardiac|cardio|heart\s+attack)", low):
        put("family_heart_disease", not re.search(r"no\s+family\s+history", low), m)
    # symptoms (canonical names)
    syms = safety.detect_red_flags(low)
    if syms:
        out["symptoms"] = syms
        prov["symptoms"] = {"source": f'typed text: "{t.strip()[:120]}"', "confidence": 0.7}
    elif m := re.search(r"chest\s+(?:pain|tightness|discomfort)", low):
        if not re.search(r"\b(?:no|not|without)\b.{0,12}chest", low):
            out["symptoms"] = ["chest_pain"]
            prov["symptoms"] = {"source": f'typed text: "{_sentence_for(t, m.span())}"', "confidence": 0.6}
    if m := re.search(r"short(?:ness)?\s+of\s+breath|breathless", low):
        if "breathlessness_at_rest" not in out.get("symptoms", []) and not re.search(r"\b(?:no|not|without)\b.{0,12}breath", low):
            out.setdefault("symptoms", []).append("breathlessness_on_exertion")
            prov.setdefault("symptoms", {"source": f'typed text: "{_sentence_for(t, m.span())}"', "confidence": 0.6})
    return out, prov


def parse_lifestyle(text: str, use_llm: bool = True) -> Tuple[Dict, Dict, str, List[str]]:
    """Return (fields, provenance, method, warnings). method is 'llm', 'llm+regex' or 'regex'."""
    warnings: List[str] = []
    regex_fields, regex_prov = regex_extract(text)
    if not text or not text.strip():
        return {}, {}, "none", warnings
    if use_llm:
        try:
            from backend.rag import llm
            raw = llm.extract_json([{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": text}])
            parsed = LifestyleExtraction(**raw)
            fields = {k: v for k, v in parsed.model_dump().items() if v not in (None, [], "")}
            prov = {k: {"source": f'typed text (LLM): "{text.strip()[:100]}"', "confidence": 0.8} for k in fields}
            for k, v in regex_fields.items():          # back-fill what the model left empty
                if k not in fields:
                    fields[k], prov[k] = v, regex_prov[k]
            # trust regex red flags even when the LLM missed them (safety first)
            if "symptoms" in regex_fields:
                fields["symptoms"] = sorted(set(fields.get("symptoms", [])) | set(regex_fields["symptoms"]))
            for k in ("age", "sleep_hours", "height_cm", "weight_kg", "cigarettes_per_day"):
                if k in fields and not is_plausible(k, float(fields[k])):
                    warnings.append(f"Rejected implausible {k} = {fields[k]}")
                    fields.pop(k)
            return fields, prov, "llm+regex" if regex_fields else "llm", warnings
        except (ValidationError, ValueError, KeyError) as e:
            warnings.append(f"LLM returned invalid JSON; regex fallback used ({type(e).__name__}).")
        except Exception:   # noqa: BLE001  (server not running, timeout, ...)
            warnings.append("Local LLM unavailable; regex fallback used for typed text.")
    return regex_fields, regex_prov, "regex", warnings
