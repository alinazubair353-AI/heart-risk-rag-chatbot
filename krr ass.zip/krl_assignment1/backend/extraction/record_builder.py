"""Assemble a validated PatientRecord from every extraction source (Task 2, stage 2)."""
import shutil
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

from backend.schemas import PatientRecord, Lifestyle, History, Provenance, LabValue
from backend.extraction import pdf_reader, ocr_reader, csv_reader, lifestyle_parser, normaliser
from backend.safety import KEY_FIELDS

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}
TABLE_EXT = {".csv", ".xlsx", ".xls"}


def _merge_labs(dst: Dict[str, LabValue], src: Dict[str, LabValue]) -> None:
    for k, v in src.items():
        if k not in dst or v.confidence > dst[k].confidence:
            dst[k] = v


def extract_file(path: Path, display_name: str):
    """Dispatch on file type. Returns (labs, demo_values, demo_provenance, warnings)."""
    ext = path.suffix.lower()
    if ext == ".pdf":
        labs, dv, dp, warns, scanned = pdf_reader.extract_from_pdf(path, display_name)
        if scanned:
            l2, d2, p2, w2 = ocr_reader.extract_from_scanned_pdf(path, scanned, display_name)
            _merge_labs(labs, l2)
            for k in d2:
                dv.setdefault(k, d2[k]); dp.setdefault(k, p2[k])
            warns += w2
        return labs, dv, dp, warns
    if ext in IMAGE_EXT:
        return ocr_reader.extract_from_image_file(path, display_name)
    if ext in TABLE_EXT:
        return csv_reader.extract_from_csv(path, display_name)
    if ext in (".txt", ".md"):
        text = path.read_text(errors="ignore")
        labs, w = normaliser.parse_lab_text(text, display_name, 0.9)
        dv, dp, w2 = normaliser.parse_demographics(text, display_name, 0.9)
        return labs, dv, dp, w + w2
    raise ValueError(f"Unsupported file type: {ext}")


def compute_missing(rec: PatientRecord) -> List[str]:
    have = {"age": rec.age is not None, "sex": rec.sex is not None, "bmi": rec.bmi is not None,
            "smoker": rec.lifestyle.smoker is not None}
    missing = [k for k, ok in have.items() if not ok]
    missing += [k for k in KEY_FIELDS if k in normaliser.LAB_SPECS and k not in rec.labs]
    return sorted(set(missing), key=KEY_FIELDS.index)


def build_record(session_id: str, files: List[tuple], lifestyle_text: str = "", use_llm: bool = True,
                 base: Optional[PatientRecord] = None):
    """files: list of (display_name, bytes). Files are written to a private temp dir, parsed, and deleted at once.

    Returns (record, processed_names, errors)."""
    rec = base.model_copy(deep=True) if base else PatientRecord(patient_id=session_id)
    processed, errors = [], []
    demo: Dict = {}
    prov: Dict = {}
    tmp = Path(tempfile.mkdtemp(prefix="krl_upload_"))
    try:
        for name, data in files:
            safe = Path(name).name
            p = tmp / safe
            try:
                p.write_bytes(data)
                labs, dv, dp, warns = extract_file(p, safe)
                _merge_labs(rec.labs, labs)
                for k, v in dv.items():
                    demo.setdefault(k, v); prov.setdefault(k, dp[k])
                rec.warnings += warns
                processed.append(safe)
                if not labs and not dv:
                    errors.append(f"{safe}: no recognisable lab values were found (is the file readable?)")
            except Exception as e:  # noqa: BLE001
                errors.append(f"{safe}: {type(e).__name__}: {str(e)[:150]}")
            finally:
                p.unlink(missing_ok=True)          # reports are never kept
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    fields, lprov, method, lw = lifestyle_parser.parse_lifestyle(lifestyle_text, use_llm=use_llm)
    rec.warnings += lw
    # typed text may also contain lab values ("my LDL is 162")
    if lifestyle_text:
        tl, tw = normaliser.parse_lab_text(lifestyle_text, "typed text", 0.8)
        _merge_labs(rec.labs, tl)
        rec.warnings += tw
        dv2, dp2, w2 = normaliser.parse_demographics(lifestyle_text, "typed text", 0.8)
        for k in dv2:
            fields.setdefault(k, dv2[k]); lprov.setdefault(k, dp2[k])

    for k in ("age", "sex", "height_cm", "weight_kg", "bmi"):
        val = demo.get(k, fields.get(k))
        if val is not None and getattr(rec, k) is None:
            setattr(rec, k, val)
            prov[k] = prov.get(k) or lprov.get(k) or {"source": "typed text", "confidence": 0.7}
    for k in ("smoker", "cigarettes_per_day", "activity", "diet", "alcohol", "sleep_hours", "stress"):
        if k in fields:
            setattr(rec.lifestyle, k, fields[k]); prov[k] = lprov.get(k, {"source": "typed text", "confidence": 0.7})
    for k in ("diabetes", "hypertension", "family_heart_disease"):
        if k in fields:
            setattr(rec.history, k, fields[k]); prov[k] = lprov.get(k, {"source": "typed text", "confidence": 0.7})
    if fields.get("symptoms"):
        rec.symptoms = sorted(set(rec.symptoms) | set(fields["symptoms"]))
        prov["symptoms"] = lprov.get("symptoms", {"source": "typed text", "confidence": 0.7})
    if rec.bmi is None:
        rec.bmi = normaliser.compute_bmi(rec.height_cm, rec.weight_kg)
        if rec.bmi:
            prov["bmi"] = {"source": "computed from height and weight", "confidence": 0.9}
    rec.provenance.update({k: Provenance(**v) for k, v in prov.items()})
    rec.missing_fields = compute_missing(rec)
    return rec, processed, errors
