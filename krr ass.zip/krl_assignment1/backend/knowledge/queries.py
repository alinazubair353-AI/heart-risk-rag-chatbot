"""Knowledge-graph loading, SPARQL queries and visualisation (Task 1).

Run:  python -m backend.knowledge.queries   (prints every query result and saves kg_graph.png)"""
from pathlib import Path
from typing import Dict, List

import networkx as nx
from rdflib import Graph, Namespace, RDF

from backend import config

H = Namespace("http://example.org/heart#")
KG = Namespace("http://example.org/kg#")
PREFIX = """PREFIX heart: <http://example.org/heart#>
PREFIX kg: <http://example.org/kg#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
"""

QUERIES: Dict[str, str] = {
 "Q1 Risk factors that increase CVD risk (with source)": PREFIX + """
SELECT ?factor ?source WHERE {
  ?st rdf:subject ?factor ; rdf:predicate heart:increasesRiskOf ; rdf:object heart:CardiovascularDisease ; kg:source ?source .
} ORDER BY ?factor""",
 "Q2 Diagnostic definitions / thresholds": PREFIX + """
SELECT ?concept ?definition ?source WHERE {
  ?st rdf:subject ?concept ; rdf:predicate heart:hasDefinition ; rdf:object ?definition ; kg:source ?source .
} ORDER BY ?concept""",
 "Q3 Recommendations for hypertension": PREFIX + """
SELECT ?measure ?text ?source WHERE {
  ?st rdf:subject heart:Hypertension ; rdf:predicate heart:recommends ; rdf:object ?measure ; rdfs:comment ?text ; kg:source ?source .
}""",
 "Q4 Number of facts contributed by each guideline": PREFIX + """
SELECT ?source (COUNT(?st) AS ?facts) WHERE { ?st a rdf:Statement ; kg:source ?source . }
GROUP BY ?source ORDER BY DESC(?facts)""",
 "Q5 Lifestyle measures that reduce risk": PREFIX + """
SELECT ?measure ?target ?source WHERE {
  ?st rdf:subject ?measure ; rdf:predicate heart:reducesRiskOf ; rdf:object ?target ; kg:source ?source .
} ORDER BY ?measure""",
 "Q6 Signs that indicate an emergency condition": PREFIX + """
SELECT ?sign ?condition ?source WHERE {
  ?st rdf:subject ?sign ; rdf:predicate heart:indicates ; rdf:object ?condition ; kg:source ?source .
  FILTER(?condition IN (heart:HeartAttack, heart:Stroke))
}""",
}

_graph = None


def load_graph(force: bool = False) -> Graph:
    """Load triples.ttl (and user_triples.ttl added through the Learning section)."""
    global _graph
    if _graph is None or force:
        if not config.TRIPLES_FILE.exists():
            from backend.knowledge import build_triples
            build_triples.build()
        g = Graph()
        g.parse(str(config.TRIPLES_FILE), format="turtle")
        if config.EXTRA_TRIPLES_FILE.exists():
            g.parse(str(config.EXTRA_TRIPLES_FILE), format="turtle")
        _graph = g
    return _graph


def count_facts() -> int:
    """Number of asserted facts (reified statements = one source-annotated triple each)."""
    return len(list(load_graph().subjects(RDF.type, RDF.Statement)))


def run_query(name_or_sparql: str) -> List[dict]:
    q = QUERIES.get(name_or_sparql, name_or_sparql)
    res = load_graph().query(q)
    return [{str(k): (str(v).split("#")[-1] if str(v).startswith("http") else str(v)) for k, v in zip(res.vars, row)} for row in res]


def facts_for_tags(tags: List[str], limit: int = 8) -> List[dict]:
    """Guideline facts connected to inferred conditions (graph side of hybrid retrieval)."""
    g = load_graph()
    out, seen = [], set()
    for tag in tags:
        for st in g.subjects(KG.source, None):
            if (st, RDF.subject, H[tag]) in g:
                text = str(next(g.objects(st, __import__("rdflib").RDFS.comment), ""))
                src = str(next(g.objects(st, KG.source), ""))
                if text and (text, src) not in seen:
                    seen.add((text, src))
                    out.append({"tag": tag, "text": text, "source": src, "section": str(next(g.objects(st, KG.section), ""))})
    return out[:limit] if limit else out


def networkx_view(max_edges: int = 80) -> nx.DiGraph:
    g = load_graph()
    G = nx.DiGraph()
    for st in g.subjects(RDF.type, RDF.Statement):
        s = str(next(g.objects(st, RDF.subject))).split("#")[-1]
        o = str(next(g.objects(st, RDF.object))).split("#")[-1]
        p = str(next(g.objects(st, RDF.predicate))).split("#")[-1]
        if str(next(g.objects(st, RDF.object))).startswith("http"):
            G.add_edge(s, o, label=p, source=str(next(g.objects(st, KG.source))))
    return G


def save_graph_image(path: Path = config.EVAL_DIR / "results" / "kg_graph.png") -> Path:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    G = networkx_view()
    pos = nx.spring_layout(G, seed=7, k=0.9)
    fig, ax = plt.subplots(figsize=(14, 10))
    nx.draw_networkx_nodes(G, pos, node_size=900, node_color="#cfe3df", ax=ax)
    nx.draw_networkx_edges(G, pos, arrows=True, alpha=0.4, ax=ax)
    nx.draw_networkx_labels(G, pos, font_size=7, ax=ax)
    ax.set_title("Cardiovascular guideline knowledge graph (entity-to-entity facts)"); ax.axis("off")
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=150, bbox_inches="tight"); plt.close(fig)
    return path


if __name__ == "__main__":
    print("facts:", count_facts())
    for name in QUERIES:
        rows = run_query(name)
        print(f"\n== {name} ({len(rows)} rows)")
        for r in rows[:6]:
            print("  ", r)
    print("image:", save_graph_image())
