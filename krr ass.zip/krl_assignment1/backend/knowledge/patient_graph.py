"""Small patient knowledge graph (nodes/edges) for the frontend view (stage 3 visualisation)."""
from typing import Dict, List

from backend.knowledge.build_ontology import classify_patient


def build_patient_graph(record, engine: dict, kg_facts: List[dict]) -> Dict[str, list]:
    nodes, edges = [], []

    def node(i, label, kind):
        if not any(n["id"] == i for n in nodes):
            nodes.append({"id": i, "label": label, "type": kind})

    def edge(a, b, label):
        edges.append({"source": a, "target": b, "label": label})

    node("patient", f"Patient\n{record.age or '?'}y {record.sex or ''}".strip(), "patient")
    for k, lv in record.labs.items():
        node(f"lab_{k}", f"{k.upper()} {lv.value:g}", "lab"); edge("patient", f"lab_{k}", "hasLabResult")
    ls = record.lifestyle
    for key, val in (("smoker", ls.smoker), ("activity", ls.activity), ("diet", ls.diet), ("sleep_hours", ls.sleep_hours), ("stress", ls.stress)):
        if val not in (None, False):
            node(f"ls_{key}", f"{key}: {val}", "lifestyle"); edge("patient", f"ls_{key}", "hasLifestyleFactor")
    for s in record.symptoms:
        node(f"sym_{s}", s.replace("_", " "), "symptom"); edge("patient", f"sym_{s}", "hasSymptom")
    for r in engine.get("fired", []):
        if r.get("tag"):
            node(f"cond_{r['tag']}", r["tag"], "condition")
            for v in r["values"]:
                for pre in ("lab_", "ls_"):
                    for n in list(nodes):
                        if n["id"] in (pre + v.lower().replace("-", "_"),):
                            edge(n["id"], f"cond_{r['tag']}", "indicates")
            edge("patient", f"cond_{r['tag']}", "hasCondition")
    for d in classify_patient(record):
        node(f"def_{d}", d, "inferred"); edge("patient", f"def_{d}", "inferredClass")
    for g in kg_facts[:6]:
        node(f"doc_{g['source']}", g["source"], "guideline")
        if g["tag"]:
            node(f"cond_{g['tag']}", g["tag"], "condition"); edge(f"cond_{g['tag']}", f"doc_{g['source']}", "definedInGuideline")
    # de-duplicate edges
    uniq = {(e["source"], e["target"], e["label"]): e for e in edges}
    return {"nodes": nodes, "edges": list(uniq.values())}
