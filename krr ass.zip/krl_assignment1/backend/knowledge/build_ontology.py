"""Build the cardiovascular OWL ontology with owlready2 and save it as heart_ontology.owl (Task 1).

Run:  python -m backend.knowledge.build_ontology

Contents
  * 7 top-level classes + subclasses (LabTest, LifestyleFactor, RiskFactor, Condition, Symptom, Guideline, Patient)
  * 10 object properties, 8 data properties with domains and ranges
  * 9 defined classes (equivalence axioms with value restrictions) such as HighLDL = LDL AND hasValue >= 160
  * Guideline individuals for the 8 source documents

THRESHOLDS is the single source of truth: it generates the OWL axioms AND is used by classify_patient() as a
Java-free fallback when no HermiT/Pellet reasoner is available."""
import re
from pathlib import Path
from typing import Dict, List

from owlready2 import (Thing, DataProperty, ObjectProperty, FunctionalProperty, ConstrainedDatatype,
                       get_ontology, destroy_entity, AllDisjoint)

from backend import config

IRI = "http://example.org/heart.owl#"

# defined class -> (lab class, min inclusive, max inclusive or None, comment)
THRESHOLDS: Dict[str, tuple] = {
    "HighLDL": ("LDL", 160.0, None, "LDL-C >= 160 mg/dL (ACC/AHA 2018)"),
    "SevereHighLDL": ("LDL", 190.0, None, "LDL-C >= 190 mg/dL (ACC/AHA 2018)"),
    "LowHDLMale": ("HDL", None, 39.99, "HDL-C < 40 mg/dL in men"),
    "LowHDLFemale": ("HDL", None, 49.99, "HDL-C < 50 mg/dL in women"),
    "HighTriglycerides": ("Triglycerides", 200.0, None, "TG >= 200 mg/dL"),
    "HighTotalCholesterol": ("TotalCholesterol", 240.0, None, "Total cholesterol >= 240 mg/dL"),
    "PrediabeticGlucose": ("FastingGlucose", 100.0, 125.99, "Fasting glucose 100-125 mg/dL (ADA)"),
    "DiabeticGlucose": ("FastingGlucose", 126.0, None, "Fasting glucose >= 126 mg/dL (ADA)"),
    "Stage2SystolicBP": ("SystolicBP", 140.0, None, "Systolic BP >= 140 mmHg (ACC/AHA 2017)"),
}


def build(path: Path = config.ONTOLOGY_FILE) -> Path:
    onto = get_ontology(IRI)
    with onto:
        # ------------------------------------------------------------- top-level classes
        class Patient(Thing): pass
        class LabTest(Thing): pass
        class LifestyleFactor(Thing): pass
        class RiskFactor(Thing): pass
        class Condition(Thing): pass
        class Symptom(Thing): pass
        class Guideline(Thing): pass

        # LabTest subclasses
        for n in ["TotalCholesterol", "LDL", "HDL", "Triglycerides", "FastingGlucose", "HbA1c", "SystolicBP", "DiastolicBP"]:
            type(n, (LabTest,), {})
        # LifestyleFactor subclasses
        for n in ["Smoking", "PhysicalActivity", "Diet", "AlcoholUse", "SleepDuration", "Stress"]:
            type(n, (LifestyleFactor,), {})
        # RiskFactor subclasses
        class ModifiableRiskFactor(RiskFactor): pass
        class NonModifiableRiskFactor(RiskFactor): pass
        for n in ["Hypertension", "Dyslipidaemia", "Obesity", "Diabetes", "TobaccoUse", "PhysicalInactivity", "UnhealthyDiet"]:
            type(n + "Factor", (ModifiableRiskFactor,), {})
        for n in ["AdvancedAge", "MaleSex", "FamilyHistoryOfCHD"]:
            type(n, (NonModifiableRiskFactor,), {})
        # Condition subclasses
        class CardiovascularDisease(Condition): pass
        class MetabolicCondition(Condition): pass
        class BloodPressureCondition(Condition): pass
        class LipidCondition(Condition): pass
        for n in ["CoronaryHeartDisease", "Stroke", "HeartFailure", "MyocardialInfarction"]:
            type(n, (CardiovascularDisease,), {})
        for n in ["Diabetes", "Prediabetes", "Obesity", "Overweight", "MetabolicSyndrome"]:
            type(n, (MetabolicCondition,), {})
        for n in ["Hypertension", "ElevatedBP", "Stage1Hypertension", "Stage2Hypertension", "HypertensiveCrisis"]:
            type(n, (BloodPressureCondition,), {})
        for n in ["HighLDLCondition", "LowHDLCondition", "HypertriglyceridaemiaCondition"]:
            type(n, (LipidCondition,), {})
        # Symptom subclasses
        for n in ["ChestPain", "RadiatingArmPain", "Breathlessness", "Syncope", "Palpitations", "StrokeSigns"]:
            type(n, (Symptom,), {})
        # Guideline subclasses
        for n in ["WHOGuideline", "AHAGuideline", "ESCGuideline", "ADAGuideline"]:
            type(n, (Guideline,), {})

        # ------------------------------------------------------------- object properties (10)
        class hasLabResult(ObjectProperty): domain = [Patient]; range = [LabTest]
        class hasLifestyleFactor(ObjectProperty): domain = [Patient]; range = [LifestyleFactor]
        class hasCondition(ObjectProperty): domain = [Patient]; range = [Condition]
        class hasSymptom(ObjectProperty): domain = [Patient]; range = [Symptom]
        class hasRiskFactor(ObjectProperty): domain = [Patient]; range = [RiskFactor]
        class increasesRiskOf(ObjectProperty): domain = [RiskFactor | LifestyleFactor | Condition]; range = [Condition]
        class reducesRiskOf(ObjectProperty): domain = [LifestyleFactor]; range = [Condition]
        class indicates(ObjectProperty): domain = [LabTest | Symptom]; range = [Condition]
        class definedInGuideline(ObjectProperty): domain = [Condition | LabTest | RiskFactor | LifestyleFactor]; range = [Guideline]
        class recommends(ObjectProperty): domain = [Guideline]; range = [LifestyleFactor]

        # ------------------------------------------------------------- data properties (8)
        class hasValue(DataProperty, FunctionalProperty): domain = [LabTest]; range = [float]
        class hasUnit(DataProperty, FunctionalProperty): domain = [LabTest]; range = [str]
        class hasConfidence(DataProperty, FunctionalProperty): domain = [LabTest]; range = [float]
        class hasAge(DataProperty, FunctionalProperty): domain = [Patient]; range = [int]
        class hasSex(DataProperty, FunctionalProperty): domain = [Patient]; range = [str]
        class hasBMI(DataProperty, FunctionalProperty): domain = [Patient]; range = [float]
        class cigarettesPerDay(DataProperty, FunctionalProperty): domain = [onto["Smoking"]]; range = [int]
        class sleepHours(DataProperty, FunctionalProperty): domain = [onto["SleepDuration"]]; range = [float]
        class hasThresholdValue(DataProperty): domain = [Condition]; range = [float]

        # ------------------------------------------------------------- equivalence axioms / restrictions
        for name, (lab, lo, hi, comment) in THRESHOLDS.items():
            base = onto[lab]
            kw = {}
            if lo is not None: kw["min_inclusive"] = lo
            if hi is not None: kw["max_inclusive"] = hi
            cls = type(name, (base,), {})
            cls.equivalent_to = [base & hasValue.some(ConstrainedDatatype(float, **kw))]
            cls.comment = [comment]

        class SmokerPatient(Patient): pass
        SmokerPatient.equivalent_to = [Patient & hasLifestyleFactor.some(onto["Smoking"])]
        class HypertensivePatient(Patient): pass
        HypertensivePatient.equivalent_to = [Patient & hasCondition.some(onto["Stage2Hypertension"] | onto["Stage1Hypertension"])]
        class PatientWithRedFlag(Patient): pass
        PatientWithRedFlag.equivalent_to = [Patient & hasSymptom.some(onto["ChestPain"] | onto["RadiatingArmPain"] | onto["StrokeSigns"])]
        class DiabeticPatient(Patient): pass
        DiabeticPatient.equivalent_to = [Patient & hasLabResult.some(onto["DiabeticGlucose"])]

        AllDisjoint([Patient, LabTest, LifestyleFactor, Condition, Symptom, Guideline])

        # ------------------------------------------------------------- guideline individuals
        docs = {
            "WHO-CVD-FactSheet": ("WHOGuideline", "WHO Cardiovascular diseases (CVDs) fact sheet"),
            "AHA-ACC-2017-BP": ("AHAGuideline", "2017 ACC/AHA Guideline for High Blood Pressure in Adults"),
            "ACC-AHA-2018-Cholesterol": ("AHAGuideline", "2018 AHA/ACC Guideline on the Management of Blood Cholesterol"),
            "ESC-2021-Prevention": ("ESCGuideline", "2021 ESC Guidelines on cardiovascular disease prevention"),
            "ADA-2024-Standards": ("ADAGuideline", "ADA Standards of Care in Diabetes - 2024"),
            "AHA-Diet-2021": ("AHAGuideline", "2021 AHA Dietary Guidance to Improve Cardiovascular Health"),
            "WHO-PhysicalActivity-2020": ("WHOGuideline", "WHO Guidelines on physical activity and sedentary behaviour 2020"),
            "AHA-LE8-2022": ("AHAGuideline", "AHA Life's Essential 8 (2022)"),
        }
        for k, (cls, title) in docs.items():
            ind = onto[cls](k.replace("-", "_"))
            ind.comment = [title]

    path.parent.mkdir(parents=True, exist_ok=True)
    onto.save(file=str(path), format="rdfxml")
    return path


# ---------------------------------------------------------------------------- patient individuals
_LAB_CLASS = {"total_chol": "TotalCholesterol", "ldl": "LDL", "hdl": "HDL", "triglycerides": "Triglycerides",
              "fasting_glucose": "FastingGlucose", "hba1c": "HbA1c", "systolic_bp": "SystolicBP", "diastolic_bp": "DiastolicBP"}
_onto_cache = None


def load_ontology():
    """Load (and cache) the ontology file; build it first if it does not exist."""
    global _onto_cache
    if _onto_cache is None:
        if not config.ONTOLOGY_FILE.exists():
            build()
        _onto_cache = get_ontology(f"file://{config.ONTOLOGY_FILE}").load()
    return _onto_cache


def add_patient(record) -> object:
    """Insert the patient record into the ontology as an individual linked to lab, lifestyle and symptom individuals.

    Stage 3 of the pipeline. Call remove_patient() at session end."""
    onto = load_ontology()
    pid = re.sub(r"\W", "_", record.patient_id)
    with onto:
        p = onto.Patient(f"patient_{pid}")
        if record.age is not None: p.hasAge = int(record.age)
        if record.sex: p.hasSex = record.sex
        if record.bmi is not None: p.hasBMI = float(record.bmi)
        for key, lv in record.labs.items():
            cls = onto[_LAB_CLASS[key]]
            ind = cls(f"{key}_{pid}")
            ind.hasValue = float(lv.value); ind.hasUnit = lv.unit; ind.hasConfidence = float(lv.confidence)
            p.hasLabResult.append(ind)
        ls = record.lifestyle
        if ls.smoker:
            s = onto.Smoking(f"smoking_{pid}")
            if ls.cigarettes_per_day is not None: s.cigarettesPerDay = int(ls.cigarettes_per_day)
            p.hasLifestyleFactor.append(s)
        if ls.sleep_hours is not None:
            sl = onto.SleepDuration(f"sleep_{pid}"); sl.sleepHours = float(ls.sleep_hours); p.hasLifestyleFactor.append(sl)
        if ls.activity: p.hasLifestyleFactor.append(onto.PhysicalActivity(f"activity_{pid}"))
        if ls.diet: p.hasLifestyleFactor.append(onto.Diet(f"diet_{pid}"))
        if ls.alcohol: p.hasLifestyleFactor.append(onto.AlcoholUse(f"alcohol_{pid}"))
        if ls.stress: p.hasLifestyleFactor.append(onto.Stress(f"stress_{pid}"))
        sym_map = {"chest_pain_at_rest": "ChestPain", "chest_pain": "ChestPain", "pain_radiating_to_arm_jaw": "RadiatingArmPain",
                   "breathlessness_at_rest": "Breathlessness", "breathlessness_on_exertion": "Breathlessness",
                   "syncope": "Syncope", "stroke_signs": "StrokeSigns"}
        for s in record.symptoms:
            if s in sym_map:
                p.hasSymptom.append(onto[sym_map[s]](f"sym_{s}_{pid}"))
    return p


def classify_patient(record) -> List[str]:
    """Names of defined ontology classes that the patient's lab results satisfy (HermiT-free fallback).

    Mirrors what a DL reasoner would infer from the equivalence axioms above."""
    hits = []
    for name, (lab, lo, hi, _c) in THRESHOLDS.items():
        key = next((k for k, v in _LAB_CLASS.items() if v == lab), None)
        lv = record.labs.get(key)
        if lv is None:
            continue
        if name == "LowHDLMale" and record.sex != "male":
            continue
        if name == "LowHDLFemale" and record.sex != "female":
            continue
        if (lo is None or lv.value >= lo) and (hi is None or lv.value <= hi):
            hits.append(name)
    if record.lifestyle.smoker: hits.append("SmokerPatient")
    return hits


def remove_patient(patient_id: str) -> None:
    """Delete every individual created for this session."""
    onto = load_ontology()
    pid = re.sub(r"\W", "_", patient_id)
    for ind in list(onto.individuals()):
        if ind.name.endswith(pid):
            destroy_entity(ind)


def summary() -> dict:
    onto = load_ontology()
    return {"classes": len(list(onto.classes())), "object_properties": len(list(onto.object_properties())),
            "data_properties": len(list(onto.data_properties())), "defined_classes": len(THRESHOLDS) + 4,
            "individuals": len(list(onto.individuals()))}


if __name__ == "__main__":
    print("saved", build())
