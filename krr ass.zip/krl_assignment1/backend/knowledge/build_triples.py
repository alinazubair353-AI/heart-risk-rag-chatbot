"""Generate the guideline knowledge graph (triples.ttl) - Task 1.

Every fact is asserted as a plain triple AND reified as an rdf:Statement carrying kg:source (document id),
kg:section and a human-readable rdfs:comment, so each triple records its source document.

IMPORTANT: facts are paraphrased from the guideline documents listed in DOCS. Verify each fact (and fill in exact
page numbers in kg:section) against the official PDFs you download before submission.

Run:  python -m backend.knowledge.build_triples"""
from pathlib import Path
from rdflib import Graph, Namespace, Literal, RDF, RDFS, URIRef, BNode
from rdflib.namespace import XSD

from backend import config

H = Namespace("http://example.org/heart#")
KG = Namespace("http://example.org/kg#")

DOCS = {
    "WHO-CVD-FactSheet": "WHO Cardiovascular diseases (CVDs) fact sheet",
    "AHA-ACC-2017-BP": "2017 ACC/AHA Guideline for High Blood Pressure in Adults",
    "ACC-AHA-2018-Cholesterol": "2018 AHA/ACC Guideline on the Management of Blood Cholesterol",
    "ESC-2021-Prevention": "2021 ESC Guidelines on cardiovascular disease prevention in clinical practice",
    "ADA-2024-Standards": "ADA Standards of Care in Diabetes - 2024",
    "AHA-Diet-2021": "2021 AHA Dietary Guidance to Improve Cardiovascular Health",
    "WHO-PhysicalActivity-2020": "WHO Guidelines on physical activity and sedentary behaviour 2020",
    "AHA-LE8-2022": "AHA Life's Essential 8 cardiovascular health score (2022)",
}

# (subject, predicate, object, readable text, source id, section)
# object starting with "lit:" is a literal; otherwise an entity in the heart: namespace
F = [
 # --- burden of disease (WHO)
 ("CardiovascularDisease", "isLeadingCauseOf", "lit:death worldwide", "Cardiovascular diseases are the leading cause of death worldwide.", "WHO-CVD-FactSheet", "Overview"),
 ("CardiovascularDisease", "causedDeathsPerYear", "lit:about 17.9 million (2019)", "CVDs caused an estimated 17.9 million deaths in 2019.", "WHO-CVD-FactSheet", "Overview"),
 ("HeartAttack", "accountsForShareOf", "lit:4 in 5 CVD deaths (with stroke)", "Four out of five CVD deaths are due to heart attacks and strokes.", "WHO-CVD-FactSheet", "Overview"),
 ("UnhealthyDiet", "increasesRiskOf", "CardiovascularDisease", "Unhealthy diet is a behavioural risk factor for CVD.", "WHO-CVD-FactSheet", "Risk factors"),
 ("PhysicalInactivity", "increasesRiskOf", "CardiovascularDisease", "Physical inactivity is a behavioural risk factor for CVD.", "WHO-CVD-FactSheet", "Risk factors"),
 ("Smoking", "increasesRiskOf", "CardiovascularDisease", "Tobacco use is a behavioural risk factor for CVD.", "WHO-CVD-FactSheet", "Risk factors"),
 ("HarmfulAlcoholUse", "increasesRiskOf", "CardiovascularDisease", "Harmful use of alcohol is a behavioural risk factor for CVD.", "WHO-CVD-FactSheet", "Risk factors"),
 ("Hypertension", "increasesRiskOf", "CardiovascularDisease", "Raised blood pressure is a leading metabolic risk factor for CVD.", "WHO-CVD-FactSheet", "Risk factors"),
 ("Diabetes", "increasesRiskOf", "CardiovascularDisease", "Raised blood glucose / diabetes raises CVD risk.", "WHO-CVD-FactSheet", "Risk factors"),
 ("HighLDL", "increasesRiskOf", "CardiovascularDisease", "Raised blood lipids raise CVD risk.", "WHO-CVD-FactSheet", "Risk factors"),
 ("Obesity", "increasesRiskOf", "CardiovascularDisease", "Overweight and obesity raise CVD risk.", "WHO-CVD-FactSheet", "Risk factors"),
 ("SaltReduction", "reducesRiskOf", "Hypertension", "Reducing salt intake to less than 5 g per day helps lower blood pressure and CVD risk.", "WHO-CVD-FactSheet", "Prevention"),
 ("TobaccoCessation", "reducesRiskOf", "CardiovascularDisease", "Stopping tobacco use lowers CVD risk.", "WHO-CVD-FactSheet", "Prevention"),
 ("ChestPain", "indicates", "HeartAttack", "Chest pain or pressure can be an early sign of a heart attack and needs urgent care.", "WHO-CVD-FactSheet", "Symptoms"),
 ("RadiatingArmPain", "indicates", "HeartAttack", "Pain spreading to the arm, jaw, neck or back can be a heart attack sign.", "WHO-CVD-FactSheet", "Symptoms"),
 ("StrokeSigns", "indicates", "Stroke", "Sudden facial droop, arm weakness or speech difficulty are stroke warning signs needing emergency care.", "WHO-CVD-FactSheet", "Symptoms"),
 # --- blood pressure (AHA/ACC 2017)
 ("NormalBP", "hasDefinition", "lit:systolic < 120 and diastolic < 80 mmHg", "Normal blood pressure is below 120/80 mmHg.", "AHA-ACC-2017-BP", "Categories"),
 ("ElevatedBP", "hasDefinition", "lit:systolic 120-129 and diastolic < 80 mmHg", "Elevated blood pressure is systolic 120-129 with diastolic below 80 mmHg.", "AHA-ACC-2017-BP", "Categories"),
 ("Stage1Hypertension", "hasDefinition", "lit:systolic 130-139 or diastolic 80-89 mmHg", "Stage 1 hypertension is systolic 130-139 or diastolic 80-89 mmHg.", "AHA-ACC-2017-BP", "Categories"),
 ("Stage2Hypertension", "hasDefinition", "lit:systolic >= 140 or diastolic >= 90 mmHg", "Stage 2 hypertension is systolic 140 or higher, or diastolic 90 or higher.", "AHA-ACC-2017-BP", "Categories"),
 ("HypertensiveCrisis", "hasDefinition", "lit:systolic > 180 and/or diastolic > 120 mmHg", "Readings above 180/120 mmHg need prompt medical assessment, urgently if symptoms are present.", "AHA-ACC-2017-BP", "Categories"),
 ("Hypertension", "recommends", "WeightLoss", "Weight loss is a recommended non-drug measure for blood pressure control.", "AHA-ACC-2017-BP", "Non-pharmacologic"),
 ("Hypertension", "recommends", "DASHDiet", "A heart-healthy DASH-style eating pattern is recommended to lower blood pressure.", "AHA-ACC-2017-BP", "Non-pharmacologic"),
 ("Hypertension", "recommends", "SodiumReduction", "Reducing dietary sodium lowers blood pressure.", "AHA-ACC-2017-BP", "Non-pharmacologic"),
 ("Hypertension", "recommends", "PotassiumRichFoods", "Increasing dietary potassium from foods can lower blood pressure.", "AHA-ACC-2017-BP", "Non-pharmacologic"),
 ("Hypertension", "recommends", "AerobicExercise", "Regular aerobic physical activity lowers blood pressure.", "AHA-ACC-2017-BP", "Non-pharmacologic"),
 ("Hypertension", "recommends", "AlcoholModeration", "Limiting alcohol helps lower blood pressure.", "AHA-ACC-2017-BP", "Non-pharmacologic"),
 ("Hypertension", "recommends", "HomeBPMonitoring", "Out-of-office or home blood pressure monitoring helps confirm the diagnosis.", "AHA-ACC-2017-BP", "Diagnosis"),
 # --- cholesterol (ACC/AHA 2018)
 ("LDL", "indicates", "CardiovascularDisease", "LDL cholesterol is a primary target for lowering atherosclerotic CVD risk.", "ACC-AHA-2018-Cholesterol", "Overview"),
 ("SevereHighLDL", "hasDefinition", "lit:LDL-C >= 190 mg/dL", "LDL-C of 190 mg/dL or higher is severe hypercholesterolaemia and is evaluated by a physician for treatment.", "ACC-AHA-2018-Cholesterol", "Primary prevention"),
 ("HighLDL", "hasDefinition", "lit:LDL-C >= 160 mg/dL", "LDL-C of 160 mg/dL or higher is a risk-enhancing factor.", "ACC-AHA-2018-Cholesterol", "Risk enhancers"),
 ("HighLDL", "recommends", "HeartHealthyDiet", "A heart-healthy diet is the foundation for lowering LDL cholesterol.", "ACC-AHA-2018-Cholesterol", "Lifestyle"),
 ("HighLDL", "recommends", "SaturatedFatReduction", "Reducing saturated fat and trans fat lowers LDL cholesterol.", "ACC-AHA-2018-Cholesterol", "Lifestyle"),
 ("HighLDL", "recommends", "AerobicExercise", "Regular physical activity supports healthy lipid levels.", "ACC-AHA-2018-Cholesterol", "Lifestyle"),
 ("LowHDL", "hasDefinition", "lit:HDL-C < 40 mg/dL (men), < 50 mg/dL (women)", "Low HDL-C is below 40 mg/dL in men and below 50 mg/dL in women.", "ACC-AHA-2018-Cholesterol", "Risk enhancers"),
 ("LowHDL", "increasesRiskOf", "CardiovascularDisease", "Low HDL cholesterol is associated with higher CVD risk.", "ACC-AHA-2018-Cholesterol", "Risk enhancers"),
 ("HighTriglycerides", "hasDefinition", "lit:fasting TG >= 175 mg/dL persistently elevated is a risk enhancer; >= 500 mg/dL is very high", "Persistently elevated triglycerides are a risk-enhancing factor; very high levels need medical evaluation.", "ACC-AHA-2018-Cholesterol", "Risk enhancers"),
 ("HighTriglycerides", "recommends", "AlcoholModeration", "Limiting alcohol and added sugars helps lower triglycerides.", "ACC-AHA-2018-Cholesterol", "Lifestyle"),
 ("MetabolicSyndrome", "increasesRiskOf", "CardiovascularDisease", "Metabolic syndrome is a risk-enhancing condition.", "ACC-AHA-2018-Cholesterol", "Risk enhancers"),
 ("Smoking", "isRiskEnhancerFor", "HighLDL", "Smoking amplifies the cardiovascular risk of elevated LDL.", "ACC-AHA-2018-Cholesterol", "Risk assessment"),
 # --- ESC 2021
 ("VeryHighRisk", "hasLDLGoal", "lit:< 55 mg/dL (1.4 mmol/L)", "For very high-risk people the LDL-C goal is below 55 mg/dL (1.4 mmol/L).", "ESC-2021-Prevention", "Lipids"),
 ("HighRisk", "hasLDLGoal", "lit:< 70 mg/dL (1.8 mmol/L)", "For high-risk people the LDL-C goal is below 70 mg/dL (1.8 mmol/L).", "ESC-2021-Prevention", "Lipids"),
 ("ModerateRisk", "hasLDLGoal", "lit:< 100 mg/dL (2.6 mmol/L)", "For moderate-risk people the LDL-C goal is below 100 mg/dL (2.6 mmol/L).", "ESC-2021-Prevention", "Lipids"),
 ("Diabetes", "isRiskCategory", "HighRisk", "Most people with diabetes are at high or very high cardiovascular risk.", "ESC-2021-Prevention", "Risk categories"),
 ("Smoking", "recommends", "TobaccoCessation", "Stopping smoking is the most effective lifestyle measure to reduce CVD risk.", "ESC-2021-Prevention", "Lifestyle"),
 ("FamilyHistoryOfCHD", "increasesRiskOf", "CoronaryHeartDisease", "A family history of premature coronary disease increases an individual's risk.", "ESC-2021-Prevention", "Risk factors"),
 ("PhysicalInactivity", "recommends", "AerobicExercise", "Adults should aim for at least 150 minutes of moderate-intensity activity per week.", "ESC-2021-Prevention", "Lifestyle"),
 ("Obesity", "recommends", "WeightLoss", "Weight reduction is advised in overweight and obese people to improve risk factors.", "ESC-2021-Prevention", "Lifestyle"),
 ("Hypertension", "recommends", "SaltReduction", "Reducing salt intake is advised to lower blood pressure.", "ESC-2021-Prevention", "Blood pressure"),
 ("HighRisk", "recommends", "PhysicianReview", "High-risk individuals should have their risk factors reviewed and managed with a physician.", "ESC-2021-Prevention", "Risk management"),
 # --- ADA 2024
 ("Prediabetes", "hasDefinition", "lit:fasting glucose 100-125 mg/dL or HbA1c 5.7-6.4%", "Prediabetes is fasting glucose 100-125 mg/dL or HbA1c 5.7-6.4%.", "ADA-2024-Standards", "Diagnosis"),
 ("Diabetes", "hasDefinition", "lit:fasting glucose >= 126 mg/dL or HbA1c >= 6.5%", "Diabetes is fasting glucose 126 mg/dL or higher or HbA1c 6.5% or higher, confirmed by repeat testing.", "ADA-2024-Standards", "Diagnosis"),
 ("Prediabetes", "recommends", "LifestyleChange", "Structured lifestyle change with weight loss and activity can prevent or delay type 2 diabetes.", "ADA-2024-Standards", "Prevention"),
 ("Prediabetes", "recommends", "WeightLoss", "Modest weight loss of 5-7% of body weight lowers diabetes risk in prediabetes.", "ADA-2024-Standards", "Prevention"),
 ("Diabetes", "recommends", "BPAndLipidControl", "People with diabetes need blood pressure and lipid management alongside glucose control.", "ADA-2024-Standards", "Cardiovascular risk"),
 ("Diabetes", "recommends", "PhysicianReview", "Diabetes care is individualised and managed with a healthcare team.", "ADA-2024-Standards", "Overview"),
 ("HbA1c", "indicates", "Diabetes", "HbA1c reflects average glucose over roughly three months.", "ADA-2024-Standards", "Diagnosis"),
 ("FastingGlucose", "indicates", "Diabetes", "Fasting plasma glucose is used to diagnose diabetes and prediabetes.", "ADA-2024-Standards", "Diagnosis"),
 # --- AHA diet 2021
 ("HeartHealthyDiet", "includes", "lit:vegetables, fruits, whole grains, legumes, nuts", "A heart-healthy pattern emphasises vegetables, fruit, whole grains, legumes and nuts.", "AHA-Diet-2021", "Pattern"),
 ("HeartHealthyDiet", "includes", "lit:fish and seafood, lean or plant protein", "Choose fish, seafood and plant-based or lean protein over processed meat.", "AHA-Diet-2021", "Protein"),
 ("HeartHealthyDiet", "includes", "lit:liquid plant oils such as olive oil", "Use liquid plant oils instead of tropical oils, butter and other animal fats.", "AHA-Diet-2021", "Fats"),
 ("SaturatedFatReduction", "limits", "lit:fried food, fatty and processed meat, butter, full-fat dairy", "Limit fried foods, processed meat, butter and other sources of saturated fat.", "AHA-Diet-2021", "Fats"),
 ("SodiumReduction", "limits", "lit:salty and packaged foods", "Choose foods with little or no added salt and limit packaged foods.", "AHA-Diet-2021", "Sodium"),
 ("AddedSugarReduction", "limits", "lit:sugar-sweetened drinks and sweets", "Minimise foods and drinks with added sugars.", "AHA-Diet-2021", "Sugars"),
 ("AlcoholModeration", "limits", "lit:alcohol", "If you do not drink alcohol, do not start; if you drink, limit intake.", "AHA-Diet-2021", "Alcohol"),
 ("HeartHealthyDiet", "reducesRiskOf", "CardiovascularDisease", "A heart-healthy dietary pattern lowers cardiovascular risk.", "AHA-Diet-2021", "Overview"),
 ("FibreIntake", "reducesRiskOf", "HighLDL", "Soluble fibre from oats, beans and fruit helps lower LDL cholesterol.", "AHA-Diet-2021", "Fibre"),
 # --- WHO physical activity
 ("AerobicExercise", "recommendedAmount", "lit:150-300 min/week moderate or 75-150 min/week vigorous (adults)", "Adults should do 150-300 minutes of moderate or 75-150 minutes of vigorous aerobic activity per week.", "WHO-PhysicalActivity-2020", "Adults"),
 ("MuscleStrengthening", "recommendedAmount", "lit:2 or more days per week", "Adults should add muscle-strengthening activities on 2 or more days per week.", "WHO-PhysicalActivity-2020", "Adults"),
 ("PhysicalInactivity", "increasesRiskOf", "CardiovascularDisease", "Insufficient physical activity raises the risk of cardiovascular disease.", "WHO-PhysicalActivity-2020", "Evidence"),
 ("AerobicExercise", "reducesRiskOf", "Hypertension", "Regular activity reduces the risk of hypertension.", "WHO-PhysicalActivity-2020", "Evidence"),
 ("SedentaryBehaviour", "increasesRiskOf", "CardiovascularDisease", "Long sedentary time raises cardiovascular mortality risk; limit it and replace with activity.", "WHO-PhysicalActivity-2020", "Evidence"),
 # --- AHA Life's Essential 8
 ("LifesEssential8", "includes", "lit:diet, physical activity, nicotine exposure, sleep, BMI, lipids, glucose, blood pressure", "Life's Essential 8 covers diet, activity, nicotine, sleep, body weight, lipids, glucose and blood pressure.", "AHA-LE8-2022", "Components"),
 ("ShortSleep", "increasesRiskOf", "CardiovascularDisease", "Adults should aim for 7 to 9 hours of sleep per night; short sleep is linked with worse heart health.", "AHA-LE8-2022", "Sleep"),
 ("Overweight", "hasDefinition", "lit:BMI 25.0-29.9 kg/m2", "Overweight is a BMI of 25.0-29.9 kg/m2.", "AHA-LE8-2022", "BMI"),
 ("Obesity", "hasDefinition", "lit:BMI >= 30 kg/m2", "Obesity is a BMI of 30 kg/m2 or higher.", "AHA-LE8-2022", "BMI"),
 ("Stress", "increasesRiskOf", "CardiovascularDisease", "Chronic psychological stress is associated with higher cardiovascular risk; stress management supports heart health.", "AHA-LE8-2022", "Wellbeing"),
 ("Smoking", "hasLE8Score", "lit:never smoker scores highest; current smoker lowest", "Never-smokers score best on the nicotine exposure metric; quitting improves the score.", "AHA-LE8-2022", "Nicotine"),
]


def build(path: Path = config.TRIPLES_FILE) -> Graph:
    g = Graph()
    g.bind("heart", H); g.bind("kg", KG)
    for did, title in DOCS.items():
        d = H[did.replace("-", "_")]
        g.add((d, RDF.type, KG.GuidelineDocument)); g.add((d, RDFS.label, Literal(did))); g.add((d, KG.title, Literal(title)))
    for i, (s, p, o, text, src, sec) in enumerate(F, 1):
        s_, p_ = H[s], H[p]
        o_ = Literal(o[4:]) if o.startswith("lit:") else H[o]
        g.add((s_, p_, o_))                                  # the plain triple
        st = KG[f"fact{i:03d}"]                              # reification: source for each triple
        g.add((st, RDF.type, RDF.Statement)); g.add((st, RDF.subject, s_)); g.add((st, RDF.predicate, p_)); g.add((st, RDF.object, o_))
        g.add((st, KG.source, Literal(src))); g.add((st, KG.section, Literal(sec))); g.add((st, RDFS.comment, Literal(text)))
    path.parent.mkdir(parents=True, exist_ok=True)
    g.serialize(destination=str(path), format="turtle")
    return g


if __name__ == "__main__":
    g = build()
    print(f"{len(F)} facts (asserted triples) + reification; total RDF triples in file: {len(g)}")
