"""Safety behaviours (Task 8). Each behaviour is a small pure function so it is unit-testable.

Implemented behaviours
  S1  Permanent medical disclaimer on every answer
  S2  Red-flag symptom detection -> urgent-care message that BYPASSES the chatbot
  S3  Refusal to prescribe medicines or doses
  S4  Refusal of questions unrelated to cardiovascular health
  S5  Warning when too many key values are missing for a reliable estimate
  S6  Citation verification: citations that do not match retrieved evidence are flagged
  S7  Plausibility validation of extracted values (see extraction/normaliser.py)
"""
import re
from typing import List, Optional, Tuple

DISCLAIMER = ("This tool is an educational prototype. It is NOT a medical diagnosis or medical advice. "
              "Please discuss these results with a qualified physician.")

URGENT_MESSAGE = ("URGENT: the symptoms you describe can be signs of a heart attack, stroke or another emergency. "
                  "Stop using this chatbot and call your local emergency number (1122 in Pakistan, 911 in the US, "
                  "999 in the UK) or go to the nearest emergency department now. Do not drive yourself.")

RED_FLAG_PATTERNS = {
    "chest_pain_at_rest": r"chest\s+(?:pain|pressure|tightness|discomfort)\b.{0,30}\b(?:at\s+rest|right\s+now|now|while\s+resting|crushing)|crushing\s+chest|chest\s+pain\s+at\s+rest|(?:pain|pressure)\s+in\s+(?:my\s+)?chest\s+(?:right\s+now|at\s+rest)",
    "pain_radiating_to_arm_jaw": r"(?:pain|pressure|numbness).{0,25}(?:radiat\w+|spread\w*|going|shoot\w*).{0,15}(?:left\s+arm|arm|jaw|neck|shoulder)|left\s+arm\s+pain",
    "breathlessness_at_rest": r"(?:short(?:ness)?\s+of\s+breath|breathless\w*|can'?t\s+breathe|difficulty\s+breathing).{0,30}(?:at\s+rest|suddenly|sudden|right\s+now|while\s+resting)|sudden\s+(?:short(?:ness)?\s+of\s+breath|breathlessness)",
    "syncope": r"\b(?:fainted|fainting|passed\s+out|blacked\s+out|syncope|collapsed)\b",
    "stroke_signs": r"face\s+(?:is\s+)?droop\w*|slurred\s+speech|sudden\s+weakness\s+(?:on|in)\s+one\s+side|can'?t\s+(?:lift|move)\s+(?:my\s+)?(?:arm|leg)",
}

CARDIO_KEYWORDS = [
    "heart", "cardio", "cardiac", "cholesterol", "ldl", "hdl", "triglyceride", "lipid", "blood pressure", "bp",
    "hypertension", "glucose", "sugar", "diabet", "hba1c", "diet", "food", "eat", "fat", "salt", "sodium", "fibre",
    "fiber", "exercise", "activity", "walk", "workout", "smok", "tobacco", "cigarette", "alcohol", "sleep", "stress",
    "weight", "bmi", "obes", "risk", "stroke", "artery", "statin", "report", "result", "lab", "my values", "guideline",
    "lifestyle", "reduce", "lower", "improve", "prevent", "symptom", "chest", "breath", "doctor", "physician",
    "metabolic", "pulse", "angina", "shap", 
]

PRESCRIBE_PATTERNS = [
    r"\bhow\s+(?:much|many)\b.{0,40}\b(?:mg|milligram|tablet|pill|dose|statin|aspirin|medicine|medication)",
    r"\b(?:dose|dosage|dosing)\b",
    r"\bprescribe\b",
    r"\bwhich\s+(?:medicine|medication|drug|statin|tablet|pill)s?\b.{0,30}\b(?:should|can|shall)\s+i\b",
    r"\bshould\s+i\s+(?:take|start|stop|increase|decrease)\b.{0,30}\b(?:statin|aspirin|metformin|medicine|medication|tablet|pill|drug|insulin|beta[-\s]?blocker)",
    r"\bwhat\s+(?:medicine|medication|drug|tablet)\b.{0,20}\b(?:for|to\s+take)\b",
]

PRESCRIBE_REFUSAL = ("I can't recommend medicines or doses. Medication decisions depend on your full medical history "
                     "and must be made by a qualified physician or pharmacist. I can explain what the guidelines say "
                     "about lifestyle measures and when treatment is generally discussed with a doctor.")

OUT_OF_SCOPE_REFUSAL = ("I can only help with questions about cardiovascular health, your lab values, risk factors and "
                        "related lifestyle topics. Please ask something related to heart health or your uploaded report.")

KEY_FIELDS = ["age", "sex", "systolic_bp", "diastolic_bp", "total_chol", "ldl", "hdl", "triglycerides",
              "fasting_glucose", "hba1c", "smoker", "bmi"]


def detect_red_flags(text: str) -> List[str]:
    """Return the list of red-flag symptom codes found in free text (S2)."""
    t = (text or "").lower()
    negated = re.search(r"\b(?:no|not|without|denies|never)\b.{0,15}(?:chest\s+pain|breath)", t)
    resolved = re.search(r"\bno\s+(?:chest\s+)?pain\s+(?:now|at\s+rest|currently)|pain[-\s]free|no\s+longer\s+(?:have|feel)", t)
    found = [code for code, pat in RED_FLAG_PATTERNS.items() if re.search(pat, t)]
    if (negated or resolved) and found:
        found = [c for c in found if c in ("stroke_signs", "syncope")]
    return found                       # bias: when unsure, a false alarm is safer than a missed emergency


def is_prescription_request(question: str) -> bool:
    """S3: detect requests for medicines or doses."""
    q = (question or "").lower()
    return any(re.search(p, q) for p in PRESCRIBE_PATTERNS)


def is_out_of_scope(question: str, has_context: bool = False) -> bool:
    """S4: crude keyword gate for non-cardiovascular questions."""
    q = (question or "").lower()
    if has_context and len(q.split()) <= 5:          # short follow-ups ("why?", "and for salt?") inherit the topic
        return False
    if any(re.search(r"\b" + re.escape(k), q) for k in CARDIO_KEYWORDS):
        return False
    return True


def missing_data_warning(missing_fields: List[str]) -> Optional[str]:
    """S5: warn when too many key inputs are missing."""
    n = len([m for m in missing_fields if m in KEY_FIELDS])
    if n >= 7:
        return (f"{n} of {len(KEY_FIELDS)} key inputs are missing, so any risk estimate is unreliable. "
                "Upload a lab report or add more details.")
    if n >= 4:
        return f"{n} of {len(KEY_FIELDS)} key inputs are missing; treat the estimate with caution."
    return None


def verify_citations(answer: str, passages: List[dict], graph_facts: List[dict]) -> Tuple[List[str], List[str]]:
    """S6: return (verified_labels, unverified_labels) for citations found in the answer."""
    allowed = set()
    for p in passages:
        allowed.add(f"{p['doc']}, p.{p['page']}".lower())
    for g in graph_facts:
        allowed.add(str(g.get("source", "")).lower())
    allowed_docs = {a.split(",")[0].strip() for a in allowed}
    ok, bad = [], []
    for m in re.finditer(r"\[([^\[\]]{3,80})\]", answer or ""):
        inner = m.group(1)
        for part in re.split(r";", inner):
            part = part.strip()
            if not re.search(r"p\.?\s*\d+|KG", part, flags=re.I) and part.lower().split(",")[0] not in allowed_docs:
                continue
            norm = re.sub(r"\s+", " ", part.lower().replace("p. ", "p."))
            (ok if (norm in allowed or norm.split(",")[0] in allowed_docs and "p." not in norm) else bad).append(part)
    return ok, bad


def with_disclaimer(answer: str) -> str:
    """S1: guarantee the disclaimer is present at the end of every answer."""
    if DISCLAIMER.lower()[:40] in (answer or "").lower():
        return answer
    return f"{answer.rstrip()}\n\n_{DISCLAIMER}_"
