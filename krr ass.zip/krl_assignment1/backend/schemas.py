"""Pydantic schemas for the patient record and every API request/response."""
from __future__ import annotations
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class LabValue(BaseModel):
    value: float
    unit: str
    source: str = "unknown"
    confidence: float = Field(0.8, ge=0, le=1)


class Provenance(BaseModel):
    source: str = "unknown"
    confidence: float = Field(0.8, ge=0, le=1)


class Lifestyle(BaseModel):
    smoker: Optional[bool] = None
    cigarettes_per_day: Optional[int] = None
    activity: Optional[str] = None      # sedentary | moderate | active
    diet: Optional[str] = None          # healthy | mixed | high_fried_food | high_salt
    alcohol: Optional[str] = None       # none | moderate | heavy
    sleep_hours: Optional[float] = None
    stress: Optional[str] = None        # low | moderate | high


class History(BaseModel):
    diabetes: Optional[bool] = None
    hypertension: Optional[bool] = None
    family_heart_disease: Optional[bool] = None


class PatientRecord(BaseModel):
    patient_id: str
    age: Optional[int] = None
    sex: Optional[str] = None
    height_cm: Optional[float] = None
    weight_kg: Optional[float] = None
    bmi: Optional[float] = None
    labs: Dict[str, LabValue] = {}
    lifestyle: Lifestyle = Lifestyle()
    history: History = History()
    symptoms: List[str] = []
    missing_fields: List[str] = []
    provenance: Dict[str, Provenance] = {}
    warnings: List[str] = []


class LifestyleExtraction(BaseModel):
    """Fixed JSON schema that the local LLM must fill from typed text."""
    age: Optional[int] = None
    sex: Optional[str] = Field(None, description="male or female")
    height_cm: Optional[float] = None
    weight_kg: Optional[float] = None
    smoker: Optional[bool] = None
    cigarettes_per_day: Optional[int] = None
    activity: Optional[str] = Field(None, description="sedentary, moderate or active")
    diet: Optional[str] = Field(None, description="healthy, mixed, high_fried_food or high_salt")
    alcohol: Optional[str] = Field(None, description="none, moderate or heavy")
    sleep_hours: Optional[float] = None
    stress: Optional[str] = Field(None, description="low, moderate or high")
    diabetes: Optional[bool] = None
    hypertension: Optional[bool] = None
    family_heart_disease: Optional[bool] = None
    symptoms: List[str] = []


class UploadResponse(BaseModel):
    session_id: str
    record: PatientRecord
    files_processed: List[str]
    errors: List[str] = []


class RecordUpdate(BaseModel):
    session_id: str
    record: PatientRecord


class RiskRequest(BaseModel):
    session_id: str


class FiredRule(BaseModel):
    id: str
    name: str
    conclusion: str
    severity: int
    source: str
    values: Dict[str, Any]
    trace: str


class ShapItem(BaseModel):
    feature: str
    value: Optional[float] = None
    shap: float


class RiskResponse(BaseModel):
    session_id: str
    probability: Optional[float] = None
    risk_band: str
    rule_risk_category: str
    fired_rules: List[FiredRule]
    trace: List[str]
    conditions: List[str]
    shap: List[ShapItem] = []
    red_flag: bool = False
    urgent_message: Optional[str] = None
    warnings: List[str] = []
    model_info: Dict[str, Any] = {}
    disclaimer: str


class ChatRequest(BaseModel):
    session_id: str
    question: str = Field(..., min_length=1, max_length=2000)
    config: str = Field("full", description="llm_only | rag | rag_rules | full")
    top_k: int = Field(4, ge=1, le=12)
    retrieval_mode: str = Field("hybrid", description="vector | hybrid")


class Citation(BaseModel):
    label: str
    doc: str
    page: Optional[int] = None
    section: Optional[str] = None
    text: str = ""
    verified: bool = True


class ChatResponse(BaseModel):
    session_id: str
    answer: str
    citations: List[Citation] = []
    passages: List[Dict[str, Any]] = []
    graph_facts: List[Dict[str, Any]] = []
    warnings: List[str] = []
    safety_flags: List[str] = []
    generator: str = "extractive"
    latency_s: float = 0.0
    disclaimer: str


class HealthResponse(BaseModel):
    status: str
    model: Dict[str, Any]
    index: Dict[str, Any]
    ontology: Dict[str, Any]
    llm: Dict[str, Any]


class TrainRequest(BaseModel):
    dataset: str
    target: str
    name: Optional[str] = None
    use_rule_features: bool = False
    fast: bool = True
    activate: bool = True


class ErrorResponse(BaseModel):
    detail: str
