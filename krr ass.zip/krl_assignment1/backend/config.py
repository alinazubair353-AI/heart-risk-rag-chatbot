"""Central configuration: paths, offline guard and model settings."""
import os
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
GUIDE_DIR = DATA / "guidelines"
DATASET_DIR = DATA / "datasets"
UPLOAD_DATASET_DIR = DATASET_DIR / "uploads"
INDEX_DIR = DATA / "index"
TEST_REPORT_DIR = DATA / "test_reports"
MODEL_DIR = ROOT / "backend" / "ml" / "models"
KNOW_DIR = ROOT / "backend" / "knowledge"
EVAL_DIR = ROOT / "evaluation"
EMBED_MODEL_DIR = ROOT / "models" / "embedding"   # sentence-transformers save_pretrained() folder

ONTOLOGY_FILE = KNOW_DIR / "heart_ontology.owl"
TRIPLES_FILE = KNOW_DIR / "triples.ttl"
EXTRA_TRIPLES_FILE = KNOW_DIR / "user_triples.ttl"   # triples added from the Learning section

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:3b")
LLM_TIMEOUT = float(os.getenv("LLM_TIMEOUT", "120"))
MAX_HISTORY_CHARS = 6000          # conversation memory budget (~1500 tokens)
SESSION_TTL_SECONDS = 2 * 3600

# --- Offline guard: the only network endpoint allowed is localhost -------------
_host = urlparse(OLLAMA_URL).hostname
if _host not in ("localhost", "127.0.0.1", "::1"):
    raise RuntimeError("OLLAMA_URL must point to localhost: this project must run offline.")

for _d in (GUIDE_DIR, UPLOAD_DATASET_DIR, INDEX_DIR, MODEL_DIR, TEST_REPORT_DIR, EVAL_DIR / "results"):
    _d.mkdir(parents=True, exist_ok=True)
