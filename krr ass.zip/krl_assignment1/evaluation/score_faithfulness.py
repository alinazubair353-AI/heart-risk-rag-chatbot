"""Score the manually annotated sheet evaluation/results/faithfulness_sheet.csv.
Fill the two columns with 1/0 for each statement (see README), then run this script."""
import csv, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from backend import config

rows = list(csv.DictReader(open(config.EVAL_DIR / "results" / "faithfulness_sheet.csv")))
done = [r for r in rows if r["supported_by_evidence(1/0)"].strip() in ("0", "1")]
if not done:
    sys.exit("Sheet not annotated yet.")
sup = sum(int(r["supported_by_evidence(1/0)"]) for r in done)
bad = sum(int(r["incorrect(1/0)"] or 0) for r in done)
res = {"answers": len({r["profile"] for r in done}), "statements": len(done), "faithfulness": round(sup / len(done), 3),
       "hallucination_rate": round(sum(1 for r in done if r["supported_by_evidence(1/0)"] == "0" or r["incorrect(1/0)"] == "1") / len(done), 3), "incorrect_statements": bad}
(config.EVAL_DIR / "results" / "faithfulness.json").write_text(json.dumps(res, indent=2)); print(res)
