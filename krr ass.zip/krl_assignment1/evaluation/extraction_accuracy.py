"""Extraction accuracy per file type (Task 2): % of ground-truth fields correctly extracted (tolerance 1 %)."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from backend import config
from backend.extraction.record_builder import build_record


def evaluate(use_llm=False):
    gt = json.loads((config.TEST_REPORT_DIR / "ground_truth.json").read_text())
    per_type, rows = {}, []
    for fname, truth in gt.items():
        data = (config.TEST_REPORT_DIR / fname).read_bytes()
        rec, _, errs = build_record("eval", [(fname, data)], "", use_llm=use_llm)
        got = {k: v.value for k, v in rec.labs.items()}
        got.update({"age": rec.age, "sex": rec.sex, "bmi": rec.bmi})
        t = truth["type"]
        for field, want in truth.items():
            if field == "type":
                continue
            have = got.get(field)
            ok = have is not None and ((have == want) if isinstance(want, str) else abs(float(have) - float(want)) <= 0.01 * abs(float(want)) + 0.051)
            per_type.setdefault(t, []).append(ok)
            rows.append({"file": fname, "type": t, "field": field, "expected": want, "extracted": have, "correct": bool(ok)})
    summary = {t: {"fields": len(v), "correct": int(sum(v)), "accuracy_pct": round(100 * sum(v) / len(v), 1)} for t, v in per_type.items()}
    allv = [r["correct"] for r in rows]
    summary["overall"] = {"fields": len(allv), "correct": int(sum(allv)), "accuracy_pct": round(100 * sum(allv) / len(allv), 1)}
    return {"summary": summary, "details": rows}


if __name__ == "__main__":
    res = evaluate()
    out = config.EVAL_DIR / "results" / "extraction_accuracy.json"
    out.write_text(json.dumps(res, indent=2))
    print(json.dumps(res["summary"], indent=2))
    for r in res["details"]:
        if not r["correct"]:
            print("MISS", r["file"], r["field"], "expected", r["expected"], "got", r["extracted"])
