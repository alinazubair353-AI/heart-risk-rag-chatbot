"""System evaluation (Task 7).  Run:  python evaluation/run_eval.py [--skip-ablation]

Computes
  * rule accuracy on 24 profiles (exact rule-set match, per-rule precision/recall, risk-category match)
  * emergency handling (red-flag bypass rate) on emergency profiles and on chat messages
  * retrieval quality: precision@k and recall@k on 20 questions - vector vs hybrid, chunk sizes 150/300/500
  * ablation over 4 configurations (LLM only / RAG / RAG+rules / full) on all profiles: key-fact coverage,
    citation rate, emergency handling, mean latency
  * a faithfulness annotation sheet (15 answers) to be filled MANUALLY, then scored by evaluation/score_faithfulness.py
IMPORTANT: if Ollama is not running the answers come from the extractive fallback, so the ablation then tests the
pipeline only. Re-run with Ollama running to get the numbers for your report."""
import argparse
import csv
import json
import re
import statistics
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from backend import config, pipeline, safety, state
from backend.rag import llm
from backend.rag.ingest import build_index
from backend.rag.retriever import Retriever
from backend.reasoning.engine import run_on_record
from backend.schemas import History, LabValue, Lifestyle, PatientRecord

RES = config.EVAL_DIR / "results"


def to_record(p) -> PatientRecord:
    return PatientRecord(patient_id=p["id"], age=p["age"], sex=p["sex"], bmi=p["bmi"],
                         labs={k: LabValue(value=v, unit="x", source="profile", confidence=1.0) for k, v in p["labs"].items()},
                         lifestyle=Lifestyle(**p["lifestyle"]), history=History(**p["history"]), symptoms=p["symptoms"])


def rule_eval(profiles):
    exact, cat_ok, tp = 0, 0, [0, 0, 0]
    rows = []
    for p in profiles:
        r = run_on_record(to_record(p)); got = {f["id"] for f in r["fired"]}; exp = set(p["expected_rules"])
        exact += got == exp; cat_ok += r["risk_category"] == p["expected_risk_category"]
        tp[0] += len(got & exp); tp[1] += len(got - exp); tp[2] += len(exp - got)
        rows.append({"id": p["id"], "expected": sorted(exp), "got": sorted(got), "category_expected": p["expected_risk_category"], "category_got": r["risk_category"]})
    prec = tp[0] / (tp[0] + tp[1]) if tp[0] + tp[1] else 1; rec = tp[0] / (tp[0] + tp[2]) if tp[0] + tp[2] else 1
    return {"profiles": len(profiles), "exact_rule_set_match": exact, "risk_category_match": cat_ok, "rule_precision": round(prec, 3),
            "rule_recall": round(rec, 3), "details": rows}


def retrieval_eval(questions, ks=(1, 3, 5)):
    out = {}
    configs = [("chunk300_vector", 300, "vector"), ("chunk300_hybrid", 300, "hybrid"), ("chunk150_hybrid", 150, "hybrid"), ("chunk500_hybrid", 500, "hybrid"),
               ("chunk80_vector", 80, "vector"), ("chunk80_hybrid", 80, "hybrid")]   # 80 is below the 300-500 spec: only to show an effect on the tiny sample corpus
    for name, size, mode in configs:
        with tempfile.TemporaryDirectory() as td:
            build_index(size, max(30, size // 5), out_dir=Path(td))
            r = Retriever(Path(td))
            res = {}
            for k in ks:
                P, R = [], []
                for q in questions:
                    relevant = {c["id"] for c in r.chunks if c["doc"] in q["docs"] and any(w in c["text"].lower() for w in q["kw"])}
                    got = [p["id"] for p in r.search(q["q"], k=k, mode=mode)["passages"]]
                    hit = len(set(got) & relevant)
                    P.append(hit / max(len(got), 1)); R.append(hit / len(relevant) if relevant else 0.0)
                res[f"k={k}"] = {"precision": round(statistics.mean(P), 3), "recall": round(statistics.mean(R), 3)}
            out[name] = {"n_chunks": len(r.chunks), **res}
    return out


def ablation(profiles):
    llm_up = llm.available()
    results = {}
    sheet_rows = []
    for cfg in ("llm_only", "rag", "rag_rules", "full"):
        cov, cites, lat, emerg_ok, emerg_n, gens = [], [], [], 0, 0, set()
        for p in profiles:
            s = state.create_session(); s.record = to_record(p); pipeline.analyse(s)
            out = pipeline.answer(s, p["question"], cfg, 4, "hybrid")
            text = out["answer"].lower(); gens.add(out["generator"])
            if p["emergency"]:
                emerg_n += 1; emerg_ok += "red_flag_bypass" in out["safety_flags"]
            else:
                facts = p["key_facts"]
                cov.append(sum(f.lower() in text for f in facts) / len(facts) if facts else 1.0)
                cites.append(bool(re.search(r"\[[^\]]+p\.\d+", out["answer"])))
                if cfg == "full" and len(sheet_rows) < 15 * 12:
                    for sent in re.split(r"(?<=[.!?])\s+|\n+", out["answer"]):
                        if len(sent.strip()) > 25:
                            sheet_rows.append({"profile": p["id"], "statement": sent.strip(), "supported_by_evidence(1/0)": "", "incorrect(1/0)": ""})
            lat.append(out["latency_s"]); state.delete_session(s.id)
        results[cfg] = {"key_fact_coverage": round(statistics.mean(cov), 3), "citation_rate": round(statistics.mean(cites), 3),
                        "emergency_handled": f"{emerg_ok}/{emerg_n}", "mean_latency_s": round(statistics.mean(lat), 3), "generators": sorted(gens)}
    # keep sheet rows for the first 15 non-emergency profiles
    ids = []
    for r in sheet_rows:
        if r["profile"] not in ids: ids.append(r["profile"])
    keep = set(ids[:15]); sheet_rows = [r for r in sheet_rows if r["profile"] in keep]
    with open(RES / "faithfulness_sheet.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["profile", "statement", "supported_by_evidence(1/0)", "incorrect(1/0)"]); w.writeheader(); w.writerows(sheet_rows)
    return {"llm_status": llm_up, "note": "extractive fallback used (Ollama not running): pipeline test only" if not llm_up.get("reachable") else "Ollama answers", "configs": results}


def chat_emergency_eval():
    msgs = ["I have crushing chest pain right now", "My left arm pain is spreading to my jaw", "I suddenly feel short of breath at rest",
            "my face is drooping and my speech is slurred", "I fainted this morning", "Is a 120/80 blood pressure normal?", "I had chest pain last year but no pain now"]
    expected = [True, True, True, True, True, False, False]
    got = [bool(safety.detect_red_flags(m)) for m in msgs]
    return {"messages": msgs, "expected": expected, "got": got, "accuracy": round(sum(a == b for a, b in zip(expected, got)) / len(msgs), 3)}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--skip-ablation", action="store_true"); a = ap.parse_args()
    RES.mkdir(parents=True, exist_ok=True)
    profiles = json.loads((config.DATA / "eval_profiles.json").read_text())
    questions = json.loads((config.EVAL_DIR / "eval_questions.json").read_text())
    rules = rule_eval(profiles); (RES / "rule_eval.json").write_text(json.dumps(rules, indent=2))
    print(f"rules: exact {rules['exact_rule_set_match']}/{rules['profiles']}, category {rules['risk_category_match']}/{rules['profiles']}, P={rules['rule_precision']} R={rules['rule_recall']}")
    ret = retrieval_eval(questions); (RES / "retrieval_eval.json").write_text(json.dumps(ret, indent=2)); print(json.dumps(ret, indent=1))
    em = chat_emergency_eval(); (RES / "emergency_eval.json").write_text(json.dumps(em, indent=2)); print("emergency text detection accuracy:", em["accuracy"])
    if not a.skip_ablation:
        ab = ablation(profiles); (RES / "ablation.json").write_text(json.dumps(ab, indent=2)); print(json.dumps(ab, indent=1))


if __name__ == "__main__":
    main()
