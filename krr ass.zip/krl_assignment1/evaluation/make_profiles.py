"""Create data/eval_profiles.json: 24 synthetic patient profiles with HAND-WRITTEN expected rule outputs (Task 7).

Expected rule IDs were derived by hand from the rule definitions in backend/reasoning/rules.py (not by running the
engine), so a mismatch reveals a bug in the rules or a mistake in the expectation - both worth reporting."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def P(pid, desc, kind, age, sex, labs=None, bmi=None, ls=None, hist=None, symptoms=None, rules=(), cat="Low", emergency=False,
      facts=(), question="Please explain my results and what I should change."):
    return {"id": pid, "description": desc, "kind": kind, "age": age, "sex": sex, "bmi": bmi, "labs": labs or {}, "lifestyle": ls or {},
            "history": hist or {}, "symptoms": symptoms or [], "expected_rules": sorted(rules), "expected_risk_category": cat,
            "emergency": emergency, "key_facts": list(facts), "question": question}


def L(ldl=None, hdl=None, tc=None, tg=None, glu=None, a1c=None, sbp=None, dbp=None):
    m = dict(ldl=ldl, hdl=hdl, total_chol=tc, triglycerides=tg, fasting_glucose=glu, hba1c=a1c, systolic_bp=sbp, diastolic_bp=dbp)
    return {k: v for k, v in m.items() if v is not None}


PROFILES = [
 P("P01", "Young healthy woman, all values optimal", "low", 28, "female", L(85, 62, 160, 90, 88, None, 112, 70), 22, {"smoker": False, "activity": "active"},
   rules=["R01", "R06", "R16"], cat="Low", facts=["optimal", "normal"]),
 P("P02", "Healthy man, normal values", "low", 35, "male", L(95, 55, 180, 110, 92, None, 118, 76), 23, {"smoker": False},
   rules=["R01", "R06", "R16"], cat="Low", facts=["normal"]),
 P("P03", "Moderate: smoker with borderline LDL and elevated BP", "moderate", 48, "male", L(135, 45, 210, 140, 95, None, 126, 78), 27,
   {"smoker": True, "cigarettes_per_day": 10}, rules=["R02", "R08", "R16", "R21", "R26"], cat="Moderate", facts=["smok", "borderline"]),
 P("P04", "High: Appendix-A style smoker, LDL 172, stage 2 BP", "high", 52, "male", L(172, 38, 248, 190, 112, None, 142, 90), 29.4,
   {"smoker": True, "cigarettes_per_day": 10}, rules=["R04", "R09", "R11", "R12", "R15", "R17", "R21", "R23", "R26", "R29"], cat="High",
   facts=["hypertension", "ldl", "smok", "prediabetes"]),
 P("P05", "Very high: diabetes plus hypertension", "high", 60, "female", L(150, 44, 230, 260, 168, 7.9, 152, 94), 32,
   hist={"diabetes": True, "hypertension": True}, rules=["R04", "R08", "R11", "R13", "R18", "R20", "R22", "R24", "R29"], cat="Very high",
   facts=["diabetes", "hypertension"]),
 P("P06", "Borderline: LDL exactly 160, smoker, age 50", "borderline", 50, "male", L(160, 50, 235, 120, 99, None, 119, 79), 24, {"smoker": True},
   rules=["R01", "R09", "R16", "R23", "R26"], cat="High", facts=["ldl", "smok"]),
 P("P07", "Borderline: BP 130/80, glucose 100, HbA1c 5.7, BMI 25, HDL 50 (woman)", "borderline", 45, "female", L(99, 50, None, None, 100, 5.7, 130, 80), 25,
   rules=["R03", "R06", "R17", "R19", "R21"], cat="Low", facts=["stage 1", "prediabetes"]),
 P("P08", "Crisis-range BP without symptoms", "high", 63, "male", L(120, 48, None, None, None, None, 190, 125), None,
   rules=["R05", "R07"], cat="Very high", facts=["crisis", "medical"]),
 P("P09", "Missing data: only age", "missing", 50, "male", {}, None, rules=[], cat="Insufficient data", facts=["missing"]),
 P("P10", "Partial data: only LDL 190", "missing", 40, "female", L(190), None, rules=["R10"], cat="High", facts=["ldl"]),
 P("P11", "Contradictory: says no diabetes but glucose 140 and HbA1c 7.2", "contradictory", 54, "male", L(None, None, None, None, 140, 7.2), None,
   hist={"diabetes": False}, rules=["R18", "R20"], cat="High", facts=["diabetes", "confirm"]),
 P("P12", "Contradictory: smoker=False yet 15 cigarettes/day", "contradictory", 44, "male", L(120), None, {"smoker": False, "cigarettes_per_day": 15},
   rules=["R07"], cat="Low", facts=["inconsisten"]),
 P("P13", "EMERGENCY: chest pain at rest", "emergency", 55, "male", L(130), None, symptoms=["chest_pain_at_rest"], rules=["R08", "R32"], cat="Low",
   emergency=True, facts=["emergency"]),
 P("P14", "EMERGENCY: chest pain at rest and pain to left arm", "emergency", 61, "female", {}, None, symptoms=["chest_pain_at_rest", "pain_radiating_to_arm_jaw"],
   rules=["R32", "R33"], cat="Insufficient data", emergency=True, facts=["emergency"]),
 P("P15", "EMERGENCY: stroke warning signs", "emergency", 70, "male", {}, None, symptoms=["stroke_signs"], rules=["R35"], cat="Insufficient data",
   emergency=True, facts=["emergency"]),
 P("P16", "Exertional chest pain (not at rest): prompt review, not emergency", "moderate", 58, "male", L(140), None, symptoms=["chest_pain"],
   rules=["R08", "R36"], cat="High", facts=["chest pain", "medical"]),
 P("P17", "Very high triglycerides with low HDL and glucose 105", "high", 49, "male", L(110, 35, 250, 520, 105), None,
   rules=["R07", "R11", "R14", "R15", "R17", "R29"], cat="High", facts=["triglycerides"]),
 P("P18", "Older woman with family history and borderline LDL", "moderate", 66, "female", L(135, 48, None, None, 96, None, 135, 82), 26,
   hist={"family_heart_disease": True}, rules=["R03", "R08", "R11", "R16", "R21", "R25"], cat="Moderate", facts=["family"]),
 P("P19", "Obese and sedentary, no labs", "moderate", 40, "male", {}, 34, {"activity": "sedentary"}, rules=["R22", "R27", "R30"], cat="Moderate",
   facts=["obes", "activity"]),
 P("P20", "Short sleep and high stress, otherwise normal", "low", 35, "female", L(90), 23, {"sleep_hours": 4.5, "stress": "high"}, rules=["R06", "R28"], cat="Low",
   facts=["sleep", "stress"]),
 P("P21", "Young smoker, no labs", "moderate", 25, "male", {}, None, {"smoker": True, "cigarettes_per_day": 15}, rules=["R26"], cat="Moderate", facts=["smok"]),
 P("P22", "Fried-food diet, sedentary, overweight", "moderate", 42, "female", L(128), 27, {"diet": "high_fried_food", "activity": "sedentary"},
   rules=["R07", "R21", "R27", "R30", "R31"], cat="Moderate", facts=["fried", "activity"],
   question="What foods should I avoid to reduce my LDL?"),
 P("P23", "HbA1c in prediabetes range only", "borderline", 51, "female", L(None, None, None, None, None, 6.0), None, rules=["R19"], cat="Low", facts=["prediabetes"]),
 P("P24", "EMERGENCY: sudden breathlessness at rest and fainting", "emergency", 64, "female", {}, None, symptoms=["breathlessness_at_rest", "syncope"],
   rules=["R34"], cat="Insufficient data", emergency=True, facts=["emergency"]),
]

if __name__ == "__main__":
    out = ROOT / "data" / "eval_profiles.json"
    out.write_text(json.dumps(PROFILES, indent=1))
    print("wrote", len(PROFILES), "profiles ->", out)
