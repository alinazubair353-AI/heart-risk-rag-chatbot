# Offline RAG Chatbot for Heart-Disease Risk (KRL Assignment 1)

Fully offline, Python-only chatbot that reads lab reports and a typed lifestyle description, reasons with an **OWL ontology,
a guideline knowledge graph and 36 clinical rules**, estimates risk with a **calibrated ML model + SHAP**, retrieves guideline
passages with **hybrid vector + graph retrieval**, and answers with citations through a **local LLM (Ollama)**.

> Educational prototype. Not a medical device. Use only public or synthetic data.

## Quick start (offline after step 1)

```bash
# 0. Python 3.10+ and (for scanned reports) the Tesseract OCR engine:  https://github.com/tesseract-ocr/tesseract
python -m venv .venv && source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 1. ONLINE, once: embedding model + local LLM (optional but recommended)
pip install sentence-transformers
python scripts/download_assets.py                           # saves models/embedding and runs `ollama pull llama3.2:3b`

# 2. Build everything (ontology, KG, models, index, test reports, evaluation) - works offline
python scripts/bootstrap.py

# 3. Run (two terminals)
./run_backend.sh        # http://localhost:8000/docs      (Windows: run_backend.bat)
./run_frontend.sh       # http://localhost:8501           (Windows: run_frontend.bat)

# 4. Tests
pytest -q
```

Without Ollama the chat falls back to an **extractive mode** (quotes the retrieved evidence, clearly labelled). Without a
sentence-transformers model the index uses a TF-IDF fallback. Both keep the system working offline, but **use Ollama and a
real embedding model for the numbers in your report.** Windows: if Tesseract is not on PATH, set
`TESSERACT_CMD="C:\Program Files\Tesseract-OCR\tesseract.exe"`.

## The app

The Streamlit sidebar lists every section: **Overview, Chat, Extracted values, Risk dashboard, Rules & trace, Retrieved sources,
Knowledge graph, Learning, Evaluation, Safety & ethics, System & API**, plus *New analysis* (upload + lifestyle text),
*Clear session* and the permanent disclaimer. Overview has one-click **low-risk / high-risk / emergency** demo scenarios for your video.

### Learning section (teach the chatbot)
| Tab | What you upload | What happens |
|---|---|---|
| Guideline documents | PDF / TXT / MD guidelines | Text is extracted, chunked (300-500 tokens, 50-80 overlap), embedded locally and added to FAISS. The **file name becomes the citation label** (e.g. `WHO-CVD-FactSheet.pdf` -> `[WHO-CVD-FactSheet, p.2]`). |
| Training datasets | CSV (UCI Cleveland, Kaggle Heart Failure, Framingham, your own) | Columns auto-mapped to patient-record features; 3 models tuned with GridSearchCV, calibrated, SHAP plots, optional hybrid (rule features) experiment; activate the model you want. |
| Knowledge-graph facts | CSV / Turtle with a `source` for every fact | Facts are added to the graph and used by hybrid retrieval and SPARQL. |

Uploaded **patient reports** are never stored: parsed from a temp folder that is deleted immediately; session data is removed by
`DELETE /session/{id}` (the *Clear session* button) or after 2 hours. Guideline documents and training datasets are public material kept under `data/`.

## Folder map (matches the assignment structure)
```
backend/main.py            FastAPI: /upload /risk /explain /chat /health DELETE /session/{id} (+ /rules /kg/* /learn/*)
backend/schemas.py         Pydantic models          backend/safety.py   7 safety behaviours
backend/extraction/        pdf_reader, ocr_reader, csv_reader, lifestyle_parser (LLM+regex), normaliser, record_builder
backend/knowledge/         build_ontology.py -> heart_ontology.owl, build_triples.py -> triples.ttl, queries.py (6 SPARQL)
backend/reasoning/         rules.py (36 rules), engine.py (trace)
backend/ml/                train.py, explain.py (SHAP), predict.py, features.py, synthetic.py, models/ (joblib + plots)
backend/rag/               ingest.py, retriever.py, prompt.py, llm.py
frontend/app.py            Streamlit UI             tests/test_all.py   54 pytest tests
data/                      guidelines/, datasets/, test_reports/ (6 synthetic reports + ground truth), eval_profiles.json
evaluation/                extraction_accuracy.py, run_eval.py, score_faithfulness.py, results/
report/                    REPORT_TEMPLATE.md  (required structure + AI-use declaration)
```

## Task -> where it lives
| Task | Files | Reproduce |
|---|---|---|
| 1 Ontology + KG (10 object / 9 data props, 13 defined classes, 78 sourced facts) | `backend/knowledge/*` | `python -m backend.knowledge.build_ontology && python -m backend.knowledge.queries` |
| 2 Extraction + accuracy report | `backend/extraction/*`, `scripts/make_test_reports.py` | `python evaluation/extraction_accuracy.py` |
| 3 Rules + trace + red flags + tests | `backend/reasoning/*`, `tests/` | `pytest -q` |
| 4 ML, calibration, SHAP, hybrid experiment | `backend/ml/*` | `python -m backend.ml.train [--full]`; plots in `backend/ml/models/plots/`, metrics in `metrics_*.json` |
| 5 RAG + configuration comparison | `backend/rag/*` | `python -m backend.rag.ingest`; `python evaluation/run_eval.py` |
| 6 API + frontend | `backend/main.py`, `frontend/app.py` | open `/docs` and the Streamlit app |
| 7 Evaluation + ablation | `evaluation/*`, `data/eval_profiles.json` | `python evaluation/run_eval.py` |
| 8 Safety, report, demo | `backend/safety.py`, `report/REPORT_TEMPLATE.md` | - |

## IMPORTANT: what you must still do before submitting
This project is a complete working base, but parts need **your** real data and judgement. Be honest about them in the report.

1. **Guideline corpus.** `data/guidelines/*.txt` are short *study notes I paraphrased* so the system runs out of the box. They are
   **not** the official documents. Download the real WHO / AHA-ACC / ESC / ADA PDFs, put them in `data/guidelines/` (or upload in the Learning section) with the same
   names, re-index, and **verify every fact and page number** in `backend/knowledge/build_triples.py` against the official text (edit the `section` field with the true page).
2. **Datasets.** No real dataset is bundled (the build environment had no internet). `data/datasets/synthetic_heart_DEMO.csv` is SYNTHETIC. Download UCI Cleveland and
   the Kaggle Heart Failure dataset (see `data/datasets/README.md`), delete the demo file, run `python -m backend.ml.train --full`, and report the real metrics, dataset sizes, class balance and licences.
3. **Run with Ollama + a real embedding model.** Ablation, faithfulness and latency numbers in `evaluation/results/` were produced in *extractive fallback mode* and only prove the pipeline runs.
   Re-run `python evaluation/run_eval.py`, then **annotate** `evaluation/results/faithfulness_sheet.csv` by hand (1/0 per statement) and run `python evaluation/score_faithfulness.py`.
4. **Extraction accuracy** is 100 % on the 6 bundled synthetic reports, but the parser was tuned on them, so that number is optimistic. Create harder reports (other layouts, worse scans) and report honestly.
5. **Chunk-size comparison.** On the tiny sample corpus all chunk sizes give identical results (every page is one chunk). With real PDFs the comparison becomes meaningful.
6. **Not implemented (optional bonus):** Bayesian-network / fuzzy module, Urdu input. Everything else in the brief is implemented.
7. **Report, demo video, AI-use declaration** - see `report/REPORT_TEMPLATE.md`. You must be able to explain and modify any file in the viva.
8. State your **hardware and LLM** in the report (response time is evaluated), and fill in your name, roll number and the zip name `KRL_A1_YourRollNumber_YourName.zip`.

## Design notes (useful for the viva)
- **Why rules AND ML?** Rules are transparent and follow guidelines exactly; ML captures patterns in data and gives a probability. The hybrid experiment (rule features added to the model) measures whether symbolic knowledge helps; report the result even if it does not.
- **Calibration:** CalibratedClassifierCV (sigmoid for < 1500 training rows, isotonic otherwise) so a "71 %" output behaves like a probability. SHAP is computed on the calibrated model, per original feature.
- **No data leakage:** imputation and scaling live inside the sklearn Pipeline, fitted only on training folds.
- **Hybrid retrieval:** FAISS cosine top-2k -> re-rank by keyword overlap and guideline-source agreement with fired rules -> top-k, plus knowledge-graph facts for the inferred conditions.
- **Safety order in `/chat`:** red-flag bypass -> refuse medicines/doses -> refuse out-of-scope -> retrieve -> generate -> verify citations -> append disclaimer.
- **Ontology reasoning:** `classify_patient()` mirrors the OWL equivalence axioms (e.g. HighLDL = LDL AND hasValue >= 160) without needing Java. To use a real reasoner install Java and call `owlready2.sync_reasoner_hermit()`.
- **Offline guarantee:** `backend/config.py` refuses any non-localhost `OLLAMA_URL`; Streamlit telemetry is disabled in `frontend/.streamlit/config.toml`.
