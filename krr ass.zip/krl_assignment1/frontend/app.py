"""Streamlit frontend (Task 6). Talks to the FastAPI backend over HTTP on localhost only.

Run:  streamlit run frontend/app.py --server.port 8501
Sidebar = navigation + patient intake + session controls. Main area = the selected section."""
import json
import os
import time

import networkx as nx
import pandas as pd
import plotly.graph_objects as go
import requests
import streamlit as st

BACKEND = os.getenv("KRL_BACKEND", "http://localhost:8000")
DISCLAIMER = ("Educational prototype - NOT a medical diagnosis or medical advice. "
              "Please discuss any result with a qualified physician. In an emergency call your local emergency number.")

SECTIONS = ["Overview", "Chat", "Extracted values", "Risk dashboard", "Rules & trace", "Retrieved sources",
            "Knowledge graph", "Learning", "Evaluation", "Safety & ethics", "System & API"]

DEMOS = {
    "Low risk": "I am a 29 year old woman. I do not smoke, I exercise regularly, I eat plenty of vegetables and sleep 8 hours. "
                "My LDL is 88 mg/dL, HDL 62, total cholesterol 165, triglycerides 95, fasting glucose 89 mg/dL, blood pressure 112/70. Height 165 cm, weight 58 kg.",
    "High risk": "I am a 52 year old male. I smoke about 10 cigarettes a day, I rarely exercise, I sleep 5 hours and eat a lot of fried food. "
                 "I am under high stress. My father had a heart attack. LDL 172 mg/dL, HDL 38, total cholesterol 248, triglycerides 190, "
                 "fasting glucose 112 mg/dL, blood pressure 142/90. Height 172 cm, weight 87 kg.",
    "Emergency": "I am a 58 year old male and I have crushing chest pain at rest right now that spreads to my left arm.",
}

st.set_page_config(page_title="Heart-Risk RAG Chatbot", page_icon="🫀", layout="wide")
st.markdown("""
<style>
 h1, h2, h3 { font-family: Georgia, 'Times New Roman', serif; letter-spacing: -0.01em; }
 [data-testid="stSidebar"] { border-right: 1px solid #cfdad6; }
 .krl-disclaimer { border-left: 4px solid #B7791F; background: #FBF3E1; padding: .55rem .8rem; font-size: .85rem; border-radius: 2px; }
 .krl-urgent { border-left: 6px solid #B3261E; background: #FCE8E6; padding: 1rem 1.2rem; font-size: 1.05rem; border-radius: 2px; }
 .krl-chip { display:inline-block; padding:1px 9px; border-radius:10px; font-size:.78rem; background:#dbe8e4; margin-right:4px; }
</style>""", unsafe_allow_html=True)


# --------------------------------------------------------------------------------------------- helpers
def api(method: str, path: str, timeout: float = 120, **kw):
    """Call the backend. Returns (ok, json_or_error_message)."""
    try:
        r = requests.request(method, f"{BACKEND}{path}", timeout=timeout, **kw)
        if r.status_code >= 400:
            try:
                msg = r.json().get("detail", r.text)
            except Exception:  # noqa: BLE001
                msg = r.text
            return False, f"{r.status_code}: {msg}"
        return True, r.json()
    except requests.exceptions.ConnectionError:
        return False, f"Cannot reach the backend at {BACKEND}. Start it with: uvicorn backend.main:app --port 8000"
    except requests.exceptions.Timeout:
        return False, "The backend took too long to answer (the local LLM may still be loading)."


def init_state():
    for k, v in dict(sid=None, record=None, risk=None, chat=[], last_chat=None, uploader_key=0, graph=None, nav="Overview").items():
        st.session_state.setdefault(k, v)


def refresh_analysis():
    ok, risk = api("POST", "/risk", json={"session_id": st.session_state.sid})
    st.session_state.risk = risk if ok else None
    ok, g = api("GET", f"/graph/{st.session_state.sid}")
    st.session_state.graph = g if ok else None


def analyse(files, text, use_llm):
    data = {"lifestyle_text": text, "use_llm": str(use_llm).lower()}
    if st.session_state.sid:
        data["session_id"] = st.session_state.sid
    multi = [("files", (f.name, f.getvalue())) for f in files]
    ok, out = api("POST", "/upload", data=data, files=multi or None, timeout=300)
    if not ok and "Unknown or expired session" in str(out):          # session timed out on the server
        st.session_state.sid = None; data.pop("session_id", None)
        ok, out = api("POST", "/upload", data=data, files=multi or None, timeout=300)
    if not ok:
        st.sidebar.error(out); return False
    st.session_state.sid, st.session_state.record = out["session_id"], out["record"]
    for e in out["errors"]:
        st.sidebar.warning(e)
    refresh_analysis()
    return True


def clear_session():
    if st.session_state.sid:
        api("DELETE", f"/session/{st.session_state.sid}")
    for k in ("sid", "record", "risk", "last_chat", "graph"):
        st.session_state[k] = None
    st.session_state.chat = []
    st.session_state.uploader_key += 1


def need_data() -> bool:
    if not st.session_state.sid or not st.session_state.record:
        st.info("No patient data yet. Use **New analysis** in the sidebar: upload a lab report and/or describe your lifestyle, or load a demo scenario on the Overview page.")
        return False
    return True


def urgent_banner():
    r = st.session_state.risk
    if r and r.get("red_flag"):
        st.markdown(f"<div class='krl-urgent'><b>{r['urgent_message']}</b></div>", unsafe_allow_html=True)
        return True
    return False


# --------------------------------------------------------------------------------------------- sidebar
def sidebar():
    with st.sidebar:
        st.markdown("## 🫀 Heart-Risk RAG")
        st.caption("Offline educational chatbot · ontology + rules + ML + RAG")
        st.session_state.nav = st.radio("Sections", SECTIONS, index=SECTIONS.index(st.session_state.nav), label_visibility="collapsed")
        st.divider()
        with st.expander("New analysis", expanded=not st.session_state.record):
            files = st.file_uploader("Lab reports (PDF, scan, CSV)", type=["pdf", "png", "jpg", "jpeg", "csv", "xlsx", "txt"],
                                     accept_multiple_files=True, key=f"up{st.session_state.uploader_key}")
            text = st.text_area("Lifestyle description", height=130, key=f"txt{st.session_state.uploader_key}",
                                placeholder="e.g. I'm 52, male, smoke 10 cigarettes a day, rarely exercise, sleep 5 hours...")
            use_llm = st.checkbox("Use local LLM to parse text (falls back to regex)", value=True)
            if st.button("Analyse", type="primary", width="stretch"):
                if not files and not text.strip():
                    st.warning("Add a file or some text first.")
                else:
                    with st.spinner("Extracting, reasoning and scoring..."):
                        if analyse(files, text, use_llm):
                            st.session_state.uploader_key += 1
                            st.session_state.nav = "Extracted values"; st.rerun()
        if st.session_state.sid:
            st.markdown(f"<span class='krl-chip'>session {st.session_state.sid[-6:]}</span>", unsafe_allow_html=True)
        if st.button("Clear session (delete all data)", width="stretch"):
            clear_session(); st.rerun()
        st.divider()
        st.markdown(f"<div class='krl-disclaimer'>{DISCLAIMER}</div>", unsafe_allow_html=True)


# --------------------------------------------------------------------------------------------- pages
def page_overview():
    st.title("Heart-disease risk chatbot")
    st.write("Describe your lifestyle and upload lab reports. The system extracts values, applies clinical rules, estimates risk with a calibrated "
             "model, retrieves guideline passages and answers with citations. Everything runs on this computer.")
    ok, h = api("GET", "/health", timeout=15)
    if not ok:
        st.error(h); return
    c = st.columns(4)
    c[0].metric("Backend", h["status"])
    c[1].metric("Risk model", h["model"].get("best_model", "training..." if h["model"].get("training") else "none"))
    c[2].metric("Guideline chunks", h["index"].get("n_chunks", 0))
    c[3].metric("Local LLM", "ready" if h["llm"].get("model_pulled") else "extractive mode")
    if not h["llm"].get("model_pulled"):
        st.info(f"Ollama model `{h['llm'].get('model')}` was not found, so answers are built directly from the retrieved evidence. "
                f"Install it with `ollama pull {h['llm'].get('model')}` for generated answers.")
    st.subheader("Try a demo scenario")
    cols = st.columns(3)
    for col, (name, text) in zip(cols, DEMOS.items()):
        with col:
            st.caption(text[:110] + "...")
            if st.button(f"Load: {name}", key=f"demo{name}", width="stretch"):
                with st.spinner("Analysing..."):
                    if analyse([], text, False):
                        st.session_state.chat = []
                        st.session_state.nav = "Chat"; st.rerun()
    st.subheader("How it works")
    st.graphviz_chart("""digraph G { rankdir=LR; node [shape=box, style="rounded,filled", fillcolor="#E8EFEC", color="#0F5C5C", fontname="Helvetica"];
      A [label="1 Input\\nPDF / scan / CSV / text"]; B [label="2 Extraction\\nunits + validation"]; C [label="3 Ontology +\\nknowledge graph"];
      D [label="4 Rule engine\\n+ trace"]; E [label="5 ML risk\\ncalibrated + SHAP"]; F [label="6 Hybrid RAG\\nFAISS + graph"]; G [label="7 Local LLM\\ncited answer"];
      A->B->C->D->G; B->E->G; C->F; D->F; F->G; }""")


def page_chat():
    st.header("Chat")
    urgent_banner()
    with st.expander("Retrieval settings"):
        c = st.columns(3)
        cfg = c[0].selectbox("Configuration", ["full", "rag_rules", "rag", "llm_only"], help="Used for the ablation study: full = RAG + rules + ML risk")
        k = c[1].slider("Passages (top-k)", 1, 8, 4)
        mode = c[2].selectbox("Retrieval", ["hybrid", "vector"])
    if not st.session_state.sid:
        st.info("Questions about your results work best after an analysis, but you can also ask general heart-health questions.")
    for m in st.session_state.chat:
        with st.chat_message(m["role"]):
            if m.get("urgent"):
                st.markdown(f"<div class='krl-urgent'>{m['content']}</div>", unsafe_allow_html=True)
            else:
                st.markdown(m["content"])
            for w in m.get("warnings", []):
                st.caption(f"⚠ {w}")
            if m.get("citations"):
                with st.expander(f"Sources ({len(m['citations'])})"):
                    for c in m["citations"]:
                        st.markdown(f"**[{c['label']}]** · {c.get('section', '')}\n\n> {c['text'][:260]}...")
    q = st.chat_input("Ask about your results, risk factors, foods, exercise...")
    if q:
        if not st.session_state.sid:                                  # create an empty session on demand
            ok, out = api("POST", "/upload", data={"lifestyle_text": q, "use_llm": "false"})
            if ok:
                st.session_state.sid, st.session_state.record = out["session_id"], out["record"]; refresh_analysis()
        st.session_state.chat.append({"role": "user", "content": q})
        with st.chat_message("user"):
            st.markdown(q)
        with st.chat_message("assistant"), st.spinner("Retrieving evidence and generating an answer..."):
            ok, out = api("POST", "/chat", json={"session_id": st.session_state.sid, "question": q, "config": cfg, "top_k": k, "retrieval_mode": mode}, timeout=300)
        if ok:
            urgent = "red_flag_bypass" in out["safety_flags"]
            st.session_state.chat.append({"role": "assistant", "content": out["answer"], "citations": out["citations"], "warnings": out["warnings"],
                                          "urgent": urgent})
            st.session_state.last_chat = out
            if urgent or "red_flag" in str(out["safety_flags"]):
                refresh_analysis()
        else:
            st.session_state.chat.append({"role": "assistant", "content": f"Error: {out}"})
        st.rerun()


def page_values():
    st.header("Extracted values")
    if not need_data(): return
    urgent_banner()
    rec = st.session_state.record
    st.caption("Review what was extracted. Edit any value, then press **Apply corrections** to re-run rules and risk scoring. Missing values are never invented.")
    labs = pd.DataFrame([{"test": k, "value": v["value"], "unit": v["unit"], "confidence": v["confidence"], "source": v["source"]} for k, v in rec["labs"].items()])
    st.subheader("Laboratory values")
    labs_ed = st.data_editor(labs if len(labs) else pd.DataFrame(columns=["test", "value", "unit", "confidence", "source"]), num_rows="dynamic", width="stretch",
                             disabled=["unit", "confidence", "source"], key="labs_editor",
                             column_config={"test": st.column_config.SelectboxColumn(options=["ldl", "hdl", "total_chol", "triglycerides", "fasting_glucose", "hba1c", "systolic_bp", "diastolic_bp"])})
    c = st.columns(4)
    age = c[0].number_input("Age", 0, 120, int(rec["age"]) if rec["age"] else 0, help="0 = unknown")
    sex = c[1].selectbox("Sex", ["unknown", "male", "female"], index=["unknown", "male", "female"].index(rec["sex"] or "unknown"))
    height = c[2].number_input("Height (cm)", 0.0, 250.0, float(rec["height_cm"] or 0))
    weight = c[3].number_input("Weight (kg)", 0.0, 400.0, float(rec["weight_kg"] or 0))
    ls, hs = rec["lifestyle"], rec["history"]
    c = st.columns(4)
    smoker = c[0].selectbox("Smoker", ["unknown", "yes", "no"], index={None: 0, True: 1, False: 2}[ls["smoker"]])
    cpd = c[1].number_input("Cigarettes/day", 0, 100, int(ls["cigarettes_per_day"] or 0))
    act = c[2].selectbox("Activity", ["unknown", "sedentary", "moderate", "active"], index=["unknown", "sedentary", "moderate", "active"].index(ls["activity"] or "unknown"))
    sleep = c[3].number_input("Sleep (h)", 0.0, 24.0, float(ls["sleep_hours"] or 0))
    c = st.columns(4)
    diet = c[0].selectbox("Diet", ["unknown", "healthy", "mixed", "high_fried_food", "high_salt"], index=["unknown", "healthy", "mixed", "high_fried_food", "high_salt"].index(ls["diet"] or "unknown"))
    stress = c[1].selectbox("Stress", ["unknown", "low", "moderate", "high"], index=["unknown", "low", "moderate", "high"].index(ls["stress"] or "unknown"))
    tri = lambda v: {None: "unknown", True: "yes", False: "no"}[v]  # noqa: E731
    dia = c[2].selectbox("Diabetes", ["unknown", "yes", "no"], index=["unknown", "yes", "no"].index(tri(hs["diabetes"])))
    htn = c[3].selectbox("Hypertension", ["unknown", "yes", "no"], index=["unknown", "yes", "no"].index(tri(hs["hypertension"])))
    fam = st.selectbox("Family history of heart disease", ["unknown", "yes", "no"], index=["unknown", "yes", "no"].index(tri(hs["family_heart_disease"])))
    if st.button("Apply corrections", type="primary"):
        unit = {"ldl": "mg/dL", "hdl": "mg/dL", "total_chol": "mg/dL", "triglycerides": "mg/dL", "fasting_glucose": "mg/dL", "hba1c": "%", "systolic_bp": "mmHg", "diastolic_bp": "mmHg"}
        new = json.loads(json.dumps(rec)); new["labs"] = {}
        for _, r in labs_ed.dropna(subset=["test", "value"]).iterrows():
            old = rec["labs"].get(r["test"])
            edited = old is None or float(old["value"]) != float(r["value"])
            new["labs"][r["test"]] = {"value": float(r["value"]), "unit": unit[r["test"]], "source": "manual correction" if edited else old["source"],
                                      "confidence": 1.0 if edited else old["confidence"]}
        new["age"] = age or None; new["sex"] = None if sex == "unknown" else sex
        new["height_cm"] = height or None; new["weight_kg"] = weight or None
        if height and weight: new["bmi"] = round(weight / (height / 100) ** 2, 1)
        yn = {"unknown": None, "yes": True, "no": False}
        new["lifestyle"].update(smoker=yn[smoker], cigarettes_per_day=cpd or None, activity=None if act == "unknown" else act, sleep_hours=sleep or None,
                                diet=None if diet == "unknown" else diet, stress=None if stress == "unknown" else stress)
        new["history"].update(diabetes=yn[dia], hypertension=yn[htn], family_heart_disease=yn[fam])
        ok, out = api("PUT", "/record", json={"session_id": st.session_state.sid, "record": new})
        if ok:
            st.session_state.record = out["record"]; refresh_analysis(); st.success("Updated."); st.rerun()
        else:
            st.error(out)
    if rec["missing_fields"]:
        st.warning("Missing: " + ", ".join(rec["missing_fields"]))
    for w in rec["warnings"]:
        st.caption(f"⚠ {w}")
    with st.expander("Provenance (where each non-lab value came from)"):
        st.dataframe(pd.DataFrame([{"field": k, "source": v["source"], "confidence": v["confidence"]} for k, v in rec["provenance"].items()]), width="stretch")


RANGES = {"ldl": ("LDL", 0, 100, 250, "mg/dL"), "hdl": ("HDL", 40, 100, 100, "mg/dL"), "total_chol": ("Total chol.", 0, 200, 320, "mg/dL"),
          "triglycerides": ("Triglycerides", 0, 150, 400, "mg/dL"), "fasting_glucose": ("Fasting glucose", 70, 99, 200, "mg/dL"),
          "systolic_bp": ("Systolic BP", 90, 119, 200, "mmHg"), "diastolic_bp": ("Diastolic BP", 60, 79, 130, "mmHg"), "hba1c": ("HbA1c", 4, 5.6, 10, "%")}


def page_risk():
    st.header("Risk dashboard")
    if not need_data(): return
    if urgent_banner(): return
    r = st.session_state.risk
    if not r:
        st.error("Risk could not be computed."); return
    c = st.columns([1.2, 1])
    with c[0]:
        p = r.get("probability")
        if p is not None:
            fig = go.Figure(go.Indicator(mode="gauge+number", value=round(p * 100, 1), number={"suffix": "%"},
                title={"text": "Calibrated probability of heart disease"},
                gauge={"axis": {"range": [0, 100]}, "bar": {"color": "#15221F"},
                       "steps": [{"range": [0, 20], "color": "#CFE7DB"}, {"range": [20, 50], "color": "#F4E3B1"}, {"range": [50, 100], "color": "#F1B9B3"}]}))
            fig.update_layout(height=290, margin=dict(l=20, r=20, t=60, b=10))
            st.plotly_chart(fig, width="stretch")
        else:
            st.warning("No ML risk model is loaded yet (see Learning > Training datasets).")
    with c[1]:
        st.metric("Model risk band", r["risk_band"])
        st.metric("Rule-based risk category", r["rule_risk_category"])
        mi = r.get("model_info", {})
        if mi:
            st.caption(f"Model: {mi.get('best_model')} trained on {mi.get('dataset')} · test ROC-AUC {mi.get('roc_auc', 0):.2f} · recall {mi.get('recall', 0):.2f}"
                       + (" · uses rule features" if mi.get("hybrid") else ""))
    for w in r["warnings"]:
        st.warning(w)
    if r["shap"]:
        st.subheader("Why this estimate? (SHAP)")
        s = sorted(r["shap"], key=lambda x: abs(x["shap"]))
        fig = go.Figure(go.Bar(x=[x["shap"] for x in s], orientation="h", y=[f"{x['feature']} = {x['value']:.3g}" if x["value"] is not None else f"{x['feature']} (missing)" for x in s],
                               marker_color=["#B3261E" if x["shap"] > 0 else "#0F5C5C" for x in s]))
        fig.update_layout(height=60 + 34 * len(s), margin=dict(l=10, r=10, t=10, b=10), xaxis_title="effect on probability (red raises risk)")
        st.plotly_chart(fig, width="stretch")
    labs = st.session_state.record["labs"]
    rows = [(k, v) for k, v in labs.items() if k in RANGES]
    if rows:
        st.subheader("Your values vs. reference ranges")
        fig = go.Figure()
        for i, (k, v) in enumerate(rows):
            name, lo, hi, mx, unit = RANGES[k]
            pct = lambda x: 100 * x / mx  # noqa: E731
            fig.add_trace(go.Bar(y=[name], x=[pct(hi - lo)], base=[pct(lo)], orientation="h", marker_color="#CFE7DB", showlegend=False, hoverinfo="skip"))
            fig.add_trace(go.Scatter(y=[name], x=[min(pct(v["value"]), 100)], mode="markers+text", text=[f"{v['value']:g} {unit}"], textposition="top center",
                                     marker=dict(size=13, color="#B3261E" if not (lo <= v["value"] <= hi or (k in ("ldl", "total_chol", "triglycerides", "systolic_bp", "diastolic_bp") and v["value"] < hi)) else "#0F5C5C"), showlegend=False))
        fig.update_layout(barmode="overlay", height=60 + 52 * len(rows), xaxis=dict(visible=False), margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig, width="stretch")
        st.caption("Green band = typical target range. Dots outside it are red. Ranges are simplified for display.")


def page_rules():
    st.header("Fired rules and explanation trace")
    if not need_data(): return
    urgent_banner()
    r = st.session_state.risk or {}
    fired = r.get("fired_rules", [])
    if not fired:
        st.info("No rules fired. This usually means the needed values are missing.")
    else:
        st.dataframe(pd.DataFrame([{"rule": f["id"], "name": f["name"], "conclusion": f["conclusion"], "severity": f["severity"], "source": f["source"]} for f in fired]),
                     width="stretch", hide_index=True)
        st.subheader("Trace")
        st.code("\n".join(r["trace"]), language="text")
        st.caption("Conditions inferred: " + ", ".join(r["conditions"]))
    ok, ex = api("POST", "/explain", json={"session_id": st.session_state.sid})
    if ok and ex["ontology_inferred_classes"]:
        st.caption("Ontology classes satisfied by your values: " + ", ".join(ex["ontology_inferred_classes"]))
    with st.expander("Full rule base"):
        ok, rules = api("GET", "/rules")
        if ok:
            st.dataframe(pd.DataFrame(rules), width="stretch", hide_index=True)


def page_sources():
    st.header("Retrieved sources")
    lc = st.session_state.last_chat
    if not lc or not (lc["passages"] or lc["graph_facts"]):
        st.info("Ask a question in Chat first. The passages and graph facts used for the last answer appear here."); return
    st.caption(f"Answer generated by: {lc['generator']} · {lc['latency_s']} s")
    st.subheader("Guideline passages (vector search" + (" + re-rank)" if lc["graph_facts"] else ")"))
    for p in lc["passages"]:
        with st.container(border=True):
            st.markdown(f"**{p['doc']}** · page {p['page']} · *{p['section']}* · score {p['score']}")
            st.write(p["text"])
    if lc["graph_facts"]:
        st.subheader("Knowledge-graph facts")
        st.dataframe(pd.DataFrame(lc["graph_facts"]), width="stretch", hide_index=True)


def page_graph():
    st.header("Knowledge graph")
    t1, t2 = st.tabs(["Patient graph", "Guideline graph (SPARQL)"])
    with t1:
        if not need_data(): pass
        elif not st.session_state.graph:
            st.info("Graph not available.")
        else:
            g = st.session_state.graph
            G = nx.Graph()
            for n in g["nodes"]: G.add_node(n["id"], **n)
            for e in g["edges"]: G.add_edge(e["source"], e["target"], label=e["label"])
            pos = nx.spring_layout(G, seed=3, k=0.9)
            colors = {"patient": "#15221F", "lab": "#0F5C5C", "lifestyle": "#6C8EA4", "condition": "#B3261E", "symptom": "#B7791F", "inferred": "#7A5C99", "guideline": "#999999"}
            fig = go.Figure()
            for e in g["edges"]:
                (x0, y0), (x1, y1) = pos[e["source"]], pos[e["target"]]
                fig.add_trace(go.Scatter(x=[x0, x1], y=[y0, y1], mode="lines", line=dict(width=1, color="#b8c4c0"), hoverinfo="text", text=e["label"], showlegend=False))
            for typ in colors:
                ns = [n for n in g["nodes"] if n["type"] == typ]
                if ns:
                    fig.add_trace(go.Scatter(x=[pos[n["id"]][0] for n in ns], y=[pos[n["id"]][1] for n in ns], mode="markers+text", name=typ,
                                             text=[n["label"].replace("\n", " ") for n in ns], textposition="bottom center", marker=dict(size=18, color=colors[typ])))
            fig.update_layout(height=560, xaxis=dict(visible=False), yaxis=dict(visible=False), margin=dict(l=5, r=5, t=5, b=5), legend=dict(orientation="h"))
            st.plotly_chart(fig, width="stretch")
    with t2:
        ok, names = api("GET", "/kg/queries")
        if ok:
            q = st.selectbox("Predefined SPARQL query", names)
            ok, res = api("POST", f"/kg/query?name={requests.utils.quote(q)}")
            if ok:
                st.code(res["query"], language="sparql")
                st.dataframe(pd.DataFrame(res["rows"]), width="stretch", hide_index=True)


# ---- Learning ------------------------------------------------------------------------------------
def page_learning():
    st.header("Learning")
    st.caption("Teach the chatbot new knowledge: add guideline documents to the retrieval index, add datasets to train risk models, or add facts to the knowledge graph. "
               "Use public or synthetic material only - never real patient records.")
    ok, status = api("GET", "/learn/status", timeout=30)
    if not ok:
        st.error(status); return
    c = st.columns(5)
    c[0].metric("Documents", len(status["documents"])); c[1].metric("Indexed chunks", status["index"].get("n_chunks", 0))
    c[2].metric("KG facts", status["kg_facts"]); c[3].metric("Datasets", len(status["datasets"])); c[4].metric("Models", len(status["models"]))
    tabs = st.tabs(["Guideline documents", "Training datasets", "Knowledge-graph facts", "Where to get data"])

    with tabs[0]:
        st.write("Upload guideline PDFs/text (WHO, AHA/ACC, ESC, ADA...). They are split into chunks, embedded locally and added to the FAISS index used by the chat.")
        files = st.file_uploader("Guideline files", type=["pdf", "txt", "md"], accept_multiple_files=True, key="learn_docs")
        c = st.columns(2)
        chunk = c[0].slider("Chunk size (tokens)", 300, 500, status["index"].get("chunk_tokens", 300), 20)
        ov = c[1].slider("Overlap (tokens)", 50, 80, min(max(status["index"].get("overlap_tokens", 60), 50), 80), 5)
        if st.button("Add to knowledge base and re-index", type="primary", disabled=not files):
            with st.spinner("Extracting text, chunking and embedding..."):
                ok, out = api("POST", "/learn/documents", files=[("files", (f.name, f.getvalue())) for f in files], data={"reindex": "true", "chunk_tokens": chunk, "overlap_tokens": ov}, timeout=900)
            st.success(f"Saved {out['saved']}. Index now has {out['index']['n_chunks']} chunks from {out['index']['n_docs']} documents.") if ok else st.error(out)
        st.subheader("Documents in the knowledge base")
        for d in status["documents"]:
            cols = st.columns([4, 1, 1, 1])
            cols[0].write(f"📄 {d['name']}"); cols[1].caption(f"{d['size_kb']} KB"); cols[2].caption(f"{d['chunks']} chunks" if d["indexed"] else "not indexed")
            if cols[3].button("Remove", key=f"rm{d['name']}"):
                api("DELETE", f"/learn/documents/{d['name']}"); api("POST", "/learn/reindex", params={"chunk_tokens": chunk, "overlap_tokens": ov}, timeout=600); st.rerun()
        if st.button("Rebuild index with the settings above"):
            with st.spinner("Re-indexing..."):
                ok, out = api("POST", "/learn/reindex", params={"chunk_tokens": chunk, "overlap_tokens": ov}, timeout=600)
            st.success(f"{out['n_chunks']} chunks · embedder: {out['embedder']}") if ok else st.error(out)
        if status["index"].get("embedder") == "tfidf":
            st.info("Embedding backend: TF-IDF fallback. For semantic search save a sentence-transformers model to `models/embedding/` (see README) and re-index.")

    with tabs[1]:
        st.write("Upload a CSV dataset (e.g. UCI Cleveland, Kaggle Heart Failure Prediction, Framingham) to train, tune, calibrate and explain three models. "
                 "Columns are mapped automatically to patient-record features (age, sex, blood pressure, cholesterol, glucose, BMI, smoking...).")
        up = st.file_uploader("Dataset (.csv)", type=["csv"], key="learn_ds")
        if up and st.button("Upload dataset"):
            ok, out = api("POST", "/learn/datasets", files={"file": (up.name, up.getvalue())})
            st.success(f"Uploaded {up.name}") if ok else st.error(out)
            st.rerun() if ok else None
        names = [d["name"] for d in status["datasets"]]
        if not names:
            st.info("No dataset yet. Upload one above, or run `python scripts/bootstrap.py` to create a synthetic demo dataset.")
        else:
            ds = st.selectbox("Dataset to use", names)
            ok, pv = api("GET", f"/learn/datasets/{ds}")
            if ok:
                st.caption(f"{pv['rows']} rows · {len(pv['columns'])} columns")
                st.dataframe(pd.DataFrame(pv["head"]), width="stretch", hide_index=True)
                st.write("**Auto-mapped features:** " + (", ".join(f"`{k}` ← {v}" for k, v in pv["mapped_features"].items()) or "none"))
                if pv["unmapped_columns"]:
                    st.caption("Ignored columns (no matching patient-record feature): " + ", ".join(map(str, pv["unmapped_columns"])))
                tgt = st.selectbox("Target column (1 = heart disease)", pv["columns"], index=pv["columns"].index(pv["guessed_target"]) if pv["guessed_target"] in pv["columns"] else 0)
                c = st.columns(4)
                mname = c[0].text_input("Model name", value=ds.rsplit(".", 1)[0])
                rules_f = c[1].checkbox("Add rule features (hybrid)", help="Adds rule-derived features to the inputs. If unticked, the better of plain vs hybrid is deployed automatically.")
                fast = c[2].checkbox("Fast mode (small grids)", value=True)
                act = c[3].checkbox("Activate after training", value=True)
                if st.button("Train, tune, calibrate and explain", type="primary"):
                    with st.spinner("Training 3 models with grid search, calibrating and computing SHAP... (about 1-5 minutes)"):
                        ok, info = api("POST", "/learn/train", json={"dataset": ds, "target": tgt, "name": mname, "use_rule_features": rules_f, "fast": fast, "activate": act}, timeout=3600)
                    if not ok:
                        st.error(info)
                    else:
                        st.session_state["train_info"] = info
                        st.success(f"Trained. Best model: {info['best_model']} · hybrid deployed: {info['deployed_hybrid']}"); st.rerun()
        info = st.session_state.get("train_info")
        if info:
            show_training(info)
        st.subheader("Trained models")
        for m in status["models"]:
            cols = st.columns([3, 1, 1, 1, 1])
            cols[0].write(f"**{m['name']}** ({m['best_model']}{', hybrid' if m['hybrid'] else ''}) · {m['dataset']}")
            cols[1].caption(f"AUC {m['roc_auc']:.3f}"); cols[2].caption(f"recall {m['recall']:.3f}")
            if m["file"] == status["active_model"]:
                cols[3].success("active")
            elif cols[3].button("Activate", key=f"act{m['file']}"):
                api("POST", "/learn/models/activate", params={"file": m["file"]}); st.rerun()
            if cols[4].button("Details", key=f"det{m['file']}"):
                ok, d = api("GET", f"/learn/metrics/{m['file']}")
                if ok: st.session_state["train_info"] = d; st.rerun()

    with tabs[2]:
        st.write("Add facts to the knowledge graph. **Every fact must name its source document.** CSV columns: `subject, predicate, object, text, source, section`.")
        sample = "subject,predicate,object,text,source,section\nHighLDL,recommends,SaturatedFatReduction,Reducing saturated fat lowers LDL.,AHA-Diet-2021,Fats\n"
        st.download_button("Download CSV template", sample, "kg_facts_template.csv", "text/csv")
        f = st.file_uploader("Facts file (.csv or .ttl)", type=["csv", "ttl"], key="learn_kg")
        if f and st.button("Add facts"):
            ok, out = api("POST", "/learn/triples", files={"file": (f.name, f.getvalue())})
            st.success(f"Added {out['added']} facts. The graph now holds {out['total_facts']}.") if ok else st.error(out)

    with tabs[3]:
        st.markdown("""
**Datasets to download in advance (public, free):**
- UCI Heart Disease (Cleveland) - UCI Machine Learning Repository (CC BY 4.0). Save as CSV with a header row, target column `target` or `num`.
- Heart Failure Prediction Dataset - Kaggle (free account). Target column `HeartDisease`.
- Framingham - Kaggle. Target column `TenYearCHD`.

**Guideline documents:** WHO CVD fact sheet, ACC/AHA 2017 blood pressure and 2018 cholesterol guidelines, ESC 2021 prevention guidelines, ADA Standards of Care, AHA dietary guidance, WHO physical-activity guidelines.
Name each file like the citation you want to see in answers (for example `WHO-CVD-FactSheet.pdf`), because the file name becomes the citation label.

Document the **source, licence and download date** of everything you add - the assignment report requires it.""")


def show_training(info):
    st.subheader(f"Results: {info['name']}")
    cb = info["class_balance"]
    st.caption(f"{info['n_rows']} rows · features: {', '.join(info['features'])} · positives {cb['positive']} / negatives {cb['negative']} (prevalence {cb['prevalence']})")
    rows = []
    for variant, key in (("without rules", "models_without_rules"), ("with rule features", "models_with_rules")):
        for model, m in (info.get(key) or {}).items():
            rows.append({"variant": variant, "model": model, "accuracy": m["accuracy"], "precision": m["precision"], "recall": m["recall"], "f1": m["f1"], "roc_auc": m["roc_auc"], "cv_auc": m["cv_roc_auc"],
                         "confusion [[TN,FP],[FN,TP]]": str(m["confusion_matrix"]), "best params": str(m["best_params"])})
    st.dataframe(pd.DataFrame(rows).round(3), width="stretch", hide_index=True)
    hc = info.get("hybrid_comparison")
    if hc:
        st.write(f"**Hybrid experiment:** best without rules = {hc['best_without_rules']['model']} (AUC {hc['best_without_rules']['roc_auc']:.3f}, recall {hc['best_without_rules']['recall']:.3f}); "
                 f"with rules = {hc['best_with_rules']['model']} (AUC {hc['best_with_rules']['roc_auc']:.3f}, recall {hc['best_with_rules']['recall']:.3f}); "
                 f"ΔAUC = {hc['delta_roc_auc']:+.3f}, Δrecall = {hc['delta_recall']:+.3f}. Report this honestly even when the change is small.")
    cal = info["calibration"]
    st.write(f"**Calibration ({info['calibration_method']}):** Brier score {cal['brier_before']:.3f} → {cal['brier_after']:.3f}. "
             f"At a screening threshold of 0.3 recall is {info['screening_threshold_0.3']['recall']:.3f} (precision {info['screening_threshold_0.3']['precision']:.3f}).")
    slug = "".join(ch if ch.isalnum() else "_" for ch in info["name"])
    cols = st.columns(3)
    for col, fn in zip(cols, (f"calibration_{slug}.png", f"shap_global_{slug}.png", f"shap_local_high_{slug}.png")):
        r = requests.get(f"{BACKEND}/learn/plot/{fn}", timeout=20)
        if r.ok: col.image(r.content, width="stretch")


# ---- Evaluation / safety / system -----------------------------------------------------------------
def page_eval():
    st.header("Evaluation")
    ok, res = api("GET", "/eval/results")
    if not ok:
        st.error(res); return
    if not res:
        st.info("No results yet. Run `python evaluation/extraction_accuracy.py` and `python evaluation/run_eval.py`."); return
    if "extraction_accuracy" in res:
        st.subheader("Extraction accuracy by file type")
        st.dataframe(pd.DataFrame(res["extraction_accuracy"]["summary"]).T, width="stretch")
    if "rule_eval" in res:
        r = res["rule_eval"]
        st.subheader("Rule engine on evaluation profiles")
        c = st.columns(4); c[0].metric("Exact rule-set matches", f"{r['exact_rule_set_match']}/{r['profiles']}"); c[1].metric("Risk category correct", f"{r['risk_category_match']}/{r['profiles']}")
        c[2].metric("Rule precision", r["rule_precision"]); c[3].metric("Rule recall", r["rule_recall"])
    if "retrieval_eval" in res:
        st.subheader("Retrieval: precision@k and recall@k by configuration")
        rows = [{"configuration": k, "chunks": v["n_chunks"], **{f"{kk} {m}": vv[m] for kk, vv in v.items() if kk.startswith("k=") for m in ("precision", "recall")}} for k, v in res["retrieval_eval"].items()]
        st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)
    if "ablation" in res:
        st.subheader("Ablation study")
        st.caption(res["ablation"]["note"])
        st.dataframe(pd.DataFrame(res["ablation"]["configs"]).T, width="stretch")
    if "emergency_eval" in res:
        st.metric("Emergency text detection accuracy", res["emergency_eval"]["accuracy"])
    if "faithfulness" in res:
        st.subheader("Faithfulness (manual annotation)"); st.json(res["faithfulness"])


def page_safety():
    st.header("Safety, privacy and limitations")
    st.markdown("""
**Implemented safety behaviours**
1. A medical disclaimer is shown permanently and appended to every answer.
2. Red-flag symptoms (chest pain at rest, pain spreading to arm or jaw, sudden breathlessness, fainting, stroke signs) trigger an urgent-care message and **bypass the chatbot**.
3. Requests for medicines or doses are refused.
4. Questions unrelated to cardiovascular health are refused.
5. A warning appears when too many key values are missing for a reliable estimate.
6. Citations that do not match retrieved evidence are flagged.
7. Implausible extracted values are rejected, and missing values are never invented.

**Privacy.** Everything runs on this computer. Uploaded reports are parsed from a temporary folder that is deleted immediately; extracted data lives in memory only
and is erased by *Clear session* (or after 2 hours). No online services are called.

**Limitations.** Public heart-disease datasets are small and skewed in age, sex, ethnicity and geography (for example Cleveland is a single US hospital cohort), so a model trained on them may be less reliable for other populations,
including South Asian patients. Lab values and lifestyle answers alone cannot diagnose heart disease. Probabilities are screening-style estimates. Over-reliance is a real risk - always consult a physician.""")


def page_system():
    st.header("System and API")
    ok, h = api("GET", "/health", timeout=15)
    st.json(h) if ok else st.error(h)
    st.markdown(f"Interactive API documentation: [{BACKEND}/docs]({BACKEND}/docs)")


init_state()
sidebar()
{"Overview": page_overview, "Chat": page_chat, "Extracted values": page_values, "Risk dashboard": page_risk, "Rules & trace": page_rules,
 "Retrieved sources": page_sources, "Knowledge graph": page_graph, "Learning": page_learning, "Evaluation": page_eval,
 "Safety & ethics": page_safety, "System & API": page_system}[st.session_state.nav]()
st.markdown(f"<div class='krl-disclaimer' style='margin-top:2rem'>{DISCLAIMER}</div>", unsafe_allow_html=True)
